declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/aiPromotionSuggestions.defs" {
    export const aiPromotionSuggestionsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "aiPromotionSuggestions";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "aiPromotionSuggestions";
            readonly controllerName: "AiPromotionSuggestionsController";
            readonly handlers: readonly [];
            readonly routes: readonly [];
        };
    };
    export default aiPromotionSuggestionsController;
    export const pipeline: readonly [{
        readonly id: "aiPromotionSuggestions__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/aiPromotionSuggestions.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/aiPromotionSuggestions.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_2.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/aiSalesSummary.defs" {
    export const aiSalesSummaryController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "aiSalesSummary";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "aiSalesSummary";
            readonly controllerName: "AiSalesSummaryController";
            readonly handlers: readonly [];
            readonly routes: readonly [];
        };
    };
    export default aiSalesSummaryController;
    export const pipeline: readonly [{
        readonly id: "aiSalesSummary__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/aiSalesSummary.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/aiSalesSummary.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_2.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseMenuForPos.defs" {
    export const browseMenuForPosController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "browseMenuForPos";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "browseMenuForPos";
            readonly controllerName: "BrowseMenuForPosController";
            readonly handlers: readonly [];
            readonly routes: readonly [];
        };
    };
    export default browseMenuForPosController;
    export const pipeline: readonly [{
        readonly id: "browseMenuForPos__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseMenuForPos.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseMenuForPos.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_2.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/closeDailyShift.defs" {
    export const closeDailyShiftController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "closeDailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "closeDailyShift";
            readonly controllerName: "CloseDailyShiftController";
            readonly handlers: readonly [];
            readonly routes: readonly [];
        };
    };
    export default closeDailyShiftController;
    export const pipeline: readonly [{
        readonly id: "closeDailyShift__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/closeDailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/closeDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/closeDailyShift.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_2.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/consumeIngredientsOnConfirmation.defs" {
    export const consumeIngredientsOnConfirmationController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "consumeIngredientsOnConfirmation";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "consumeIngredientsOnConfirmation";
            readonly controllerName: "ConsumeIngredientsOnConfirmationController";
            readonly handlers: readonly [];
            readonly routes: readonly [];
        };
    };
    export default consumeIngredientsOnConfirmationController;
    export const pipeline: readonly [{
        readonly id: "consumeIngredientsOnConfirmation__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/consumeIngredientsOnConfirmation.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/consumeIngredientsOnConfirmation.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_2.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/dineInOrderLifecycle.defs" {
    export const dineInOrderLifecycleController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "dineInOrderLifecycle";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "dineInOrderLifecycle";
            readonly controllerName: "DineInOrderLifecycleController";
            readonly handlers: readonly [];
            readonly routes: readonly [];
        };
    };
    export default dineInOrderLifecycleController;
    export const pipeline: readonly [{
        readonly id: "dineInOrderLifecycle__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/dineInOrderLifecycle.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/dineInOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_2.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/generateShiftCloseReport.defs" {
    export const generateShiftCloseReportController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "generateShiftCloseReport";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "generateShiftCloseReport";
            readonly controllerName: "GenerateShiftCloseReportController";
            readonly handlers: readonly [];
            readonly routes: readonly [];
        };
    };
    export default generateShiftCloseReportController;
    export const pipeline: readonly [{
        readonly id: "generateShiftCloseReport__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/generateShiftCloseReport.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/generateShiftCloseReport.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_2.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/kitchenProductionFlow.defs" {
    export const kitchenProductionFlowController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "kitchenProductionFlow";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "kitchenProductionFlow";
            readonly controllerName: "KitchenProductionFlowController";
            readonly handlers: readonly [];
            readonly routes: readonly [];
        };
    };
    export default kitchenProductionFlowController;
    export const pipeline: readonly [{
        readonly id: "kitchenProductionFlow__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/kitchenProductionFlow.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/kitchenProductionFlow.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_2.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageInventoryItems.defs" {
    export const manageInventoryItemsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "manageInventoryItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "manageInventoryItems";
            readonly controllerName: "ManageInventoryItemsController";
            readonly handlers: readonly [];
            readonly routes: readonly [];
        };
    };
    export default manageInventoryItemsController;
    export const pipeline: readonly [{
        readonly id: "manageInventoryItems__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageInventoryItems.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageInventoryItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_2.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuCategories.defs" {
    export const manageMenuCategoriesController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "manageMenuCategories";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "manageMenuCategories";
            readonly controllerName: "ManageMenuCategoriesController";
            readonly handlers: readonly [];
            readonly routes: readonly [];
        };
    };
    export default manageMenuCategoriesController;
    export const pipeline: readonly [{
        readonly id: "manageMenuCategories__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuCategories.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuCategories.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_2.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuItems.defs" {
    export const manageMenuItemsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "manageMenuItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "manageMenuItems";
            readonly controllerName: "ManageMenuItemsController";
            readonly handlers: readonly [];
            readonly routes: readonly [];
        };
    };
    export default manageMenuItemsController;
    export const pipeline: readonly [{
        readonly id: "manageMenuItems__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuItems.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/manageMenuItems.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_2.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageTables.defs" {
    export const manageTablesController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "manageTables";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "manageTables";
            readonly controllerName: "ManageTablesController";
            readonly handlers: readonly [];
            readonly routes: readonly [];
        };
    };
    export default manageTablesController;
    export const pipeline: readonly [{
        readonly id: "manageTables__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageTables.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageTables.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/manageTables.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_2.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/openDailyShift.defs" {
    export const openDailyShiftController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "openDailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "openDailyShift";
            readonly controllerName: "OpenDailyShiftController";
            readonly handlers: readonly [];
            readonly routes: readonly [];
        };
    };
    export default openDailyShiftController;
    export const pipeline: readonly [{
        readonly id: "openDailyShift__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/openDailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/openDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/openDailyShift.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_2.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/recordPayment.defs" {
    export const recordPaymentController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "recordPayment";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "recordPayment";
            readonly controllerName: "RecordPaymentController";
            readonly handlers: readonly [];
            readonly routes: readonly [];
        };
    };
    export default recordPaymentController;
    export const pipeline: readonly [{
        readonly id: "recordPayment__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/recordPayment.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/recordPayment.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/recordPayment.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_2.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/takeoutOrderLifecycle.defs" {
    export const takeoutOrderLifecycleController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "takeoutOrderLifecycle";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "takeoutOrderLifecycle";
            readonly controllerName: "TakeoutOrderLifecycleController";
            readonly handlers: readonly [];
            readonly routes: readonly [];
        };
    };
    export default takeoutOrderLifecycleController;
    export const pipeline: readonly [{
        readonly id: "takeoutOrderLifecycle__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/takeoutOrderLifecycle.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/takeoutOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_2.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewOperationalDashboard.defs" {
    export const viewOperationalDashboardController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "viewOperationalDashboard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "viewOperationalDashboard";
            readonly controllerName: "ViewOperationalDashboardController";
            readonly handlers: readonly [];
            readonly routes: readonly [];
        };
    };
    export default viewOperationalDashboardController;
    export const pipeline: readonly [{
        readonly id: "viewOperationalDashboard__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewOperationalDashboard.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewOperationalDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_2.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShift.defs" {
    export const dailyShiftTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "DailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "DailyShift";
            readonly tableName: "daily_shift";
            readonly columns: readonly [{
                readonly name: "daily_shift_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "shiftDate, openedAt, closedAt, openingCashBalance, closingCashBalance, totalSales, totalPayments, closingNotes, updatedAt";
            }];
            readonly primaryKey: readonly ["daily_shift_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_daily_shift_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_daily_shift_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly ["CashMovement"];
            };
        };
    };
    export default dailyShiftTableDefinition;
    export const pipeline: readonly [{
        readonly id: "dailyShift__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_1.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShiftRepositoryAdapter.defs" {
    export const dailyShiftRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "DailyShiftRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "DailyShiftRepositoryAdapter";
            readonly entityId: "DailyShift";
            readonly portRef: "IDailyShiftRepository";
            readonly tableRef: "daily_shifts";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Maps aggregate root scalars to real columns; non-indexed fields and CashMovement[] to details JSONB", "No MDM refs", "ctx.data available for persistence context"];
        };
    };
    export default dailyShiftRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "dailyShiftRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShiftRepositoryAdapter.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShiftRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShift.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_4.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItem.defs" {
    export const inventoryItemTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "InventoryItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "InventoryItem";
            readonly tableName: "inventory_item";
            readonly columns: readonly [{
                readonly name: "inventory_item_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "name, description, unit, currentQuantity, minimumLevel, updatedAt";
            }];
            readonly primaryKey: readonly ["inventory_item_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_inventory_item_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_inventory_item_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
        };
    };
    export default inventoryItemTableDefinition;
    export const pipeline: readonly [{
        readonly id: "inventoryItem__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItem.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItem.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_1.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItemRepositoryAdapter.defs" {
    export const inventoryItemRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "InventoryItemRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "InventoryItemRepositoryAdapter";
            readonly entityId: "InventoryItem";
            readonly portRef: "IInventoryItemRepository";
            readonly tableRef: "inventory_items";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Maps aggregate root scalars to real columns; non-indexed fields to details JSONB", "No MDM refs or embedded members", "ctx.data available for persistence context"];
        };
    };
    export default inventoryItemRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "inventoryItemRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItemRepositoryAdapter.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItemRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItem.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_4.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItem.defs" {
    export const menuItemTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "MenuItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "MenuItem";
            readonly tableName: "menu_item";
            readonly columns: readonly [{
                readonly name: "menu_item_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "menu_category_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "name, description, price, updatedAt";
            }];
            readonly primaryKey: readonly ["menu_item_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_menu_item_menu_category_id";
                readonly columns: readonly ["menu_category_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_menu_item_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_menu_item_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly ["RecipeComponent"];
            };
        };
    };
    export default menuItemTableDefinition;
    export const pipeline: readonly [{
        readonly id: "menuItem__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItem.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItem.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_1.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemRepositoryAdapter.defs" {
    export const menuItemRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "MenuItemRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "MenuItemRepositoryAdapter";
            readonly entityId: "MenuItem";
            readonly portRef: "IMenuItemRepository";
            readonly tableRef: "menu_items";
            readonly mdmReads: readonly ["MenuCategory"];
            readonly notes: readonly ["Maps aggregate root scalars to real columns; non-indexed fields and RecipeComponent[] to details JSONB", "Resolves MenuCategory mdmRef through shared 102034 MDM runtime (no local MDM table)", "ctx.data available for persistence context"];
        };
    };
    export default menuItemRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "menuItemRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemRepositoryAdapter.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItem.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_4.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/order.defs" {
    export const orderTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Order";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Order";
            readonly tableName: "order";
            readonly columns: readonly [{
                readonly name: "order_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "daily_shift_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "table_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "kitchen_ticket_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "order_type";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "status";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "totalAmount, notes, customerName, customerPhone, numberOfGuests, closedAt, cancelledAt, cancellationReason, updatedAt";
            }];
            readonly primaryKey: readonly ["order_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_order_daily_shift_id";
                readonly columns: readonly ["daily_shift_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_table_id";
                readonly columns: readonly ["table_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_kitchen_ticket_id";
                readonly columns: readonly ["kitchen_ticket_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_order_type";
                readonly columns: readonly ["order_type"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly ["OrderItem", "KitchenTicket"];
            };
        };
    };
    export default orderTableDefinition;
    export const pipeline: readonly [{
        readonly id: "order__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/order.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/order.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_1.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter.defs" {
    export const orderRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "OrderRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "OrderRepositoryAdapter";
            readonly entityId: "Order";
            readonly portRef: "IOrderRepository";
            readonly tableRef: "orders";
            readonly mdmReads: readonly ["Table"];
            readonly notes: readonly ["Maps aggregate root scalars to real columns; non-indexed fields, OrderItem[] and KitchenTicket[] to details JSONB", "Resolves Table mdmRef through shared 102034 MDM runtime (no local MDM table)", "ctx.data available for persistence context"];
        };
    };
    export default orderRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "orderRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_4.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/payment.defs" {
    export const paymentTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Payment";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Payment";
            readonly tableName: "payment";
            readonly columns: readonly [{
                readonly name: "payment_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "order_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "daily_shift_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "method, amount, updatedAt";
            }];
            readonly primaryKey: readonly ["payment_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_payment_order_id";
                readonly columns: readonly ["order_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_payment_daily_shift_id";
                readonly columns: readonly ["daily_shift_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_payment_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_payment_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
        };
    };
    export default paymentTableDefinition;
    export const pipeline: readonly [{
        readonly id: "payment__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/payment.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/payment.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_1.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/paymentRepositoryAdapter.defs" {
    export const paymentRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "PaymentRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "PaymentRepositoryAdapter";
            readonly entityId: "Payment";
            readonly portRef: "IPaymentRepository";
            readonly tableRef: "payments";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Maps aggregate root scalars to real columns; non-indexed fields to details JSONB", "No MDM refs or embedded members", "ctx.data available for persistence context"];
        };
    };
    export default paymentRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "paymentRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/paymentRepositoryAdapter.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/paymentRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.d.ts", "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/payment.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_4.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.defs" {
    export const dailyShiftRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "DailyShiftRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "DailyShift";
            readonly interfaceName: "IDailyShiftRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: DailyShiftId"];
                readonly returns: "DailyShift";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: DailyShiftFilter"];
                readonly returns: "DailyShift[]";
            }, {
                readonly name: "save";
                readonly params: readonly ["dailyShift: DailyShift"];
                readonly returns: "void";
            }, {
                readonly name: "findByDate";
                readonly params: readonly ["shiftDate: ShiftDate"];
                readonly returns: "DailyShift | null";
            }, {
                readonly name: "findOpenShift";
                readonly params: readonly [];
                readonly returns: "DailyShift | null";
            }, {
                readonly name: "findByCashier";
                readonly params: readonly ["cashierId: EmployeeId"];
                readonly returns: "DailyShift[]";
            }];
        };
    };
    export default dailyShiftRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "dailyShiftRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.defs" {
    export const inventoryItemRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "InventoryItemRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "InventoryItem";
            readonly interfaceName: "IInventoryItemRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: InventoryItemId"];
                readonly returns: "InventoryItem";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: InventoryItemFilter"];
                readonly returns: "InventoryItem[]";
            }, {
                readonly name: "save";
                readonly params: readonly ["inventoryItem: InventoryItem"];
                readonly returns: "void";
            }, {
                readonly name: "findLowStock";
                readonly params: readonly [];
                readonly returns: "InventoryItem[]";
            }, {
                readonly name: "findBySku";
                readonly params: readonly ["sku: Sku"];
                readonly returns: "InventoryItem | null";
            }, {
                readonly name: "findBySupplier";
                readonly params: readonly ["supplierId: SupplierId"];
                readonly returns: "InventoryItem[]";
            }];
        };
    };
    export default inventoryItemRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "inventoryItemRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.defs" {
    export const menuItemRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "MenuItemRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "MenuItem";
            readonly interfaceName: "IMenuItemRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: MenuItemId"];
                readonly returns: "MenuItem";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: MenuItemFilter"];
                readonly returns: "MenuItem[]";
            }, {
                readonly name: "save";
                readonly params: readonly ["menuItem: MenuItem"];
                readonly returns: "void";
            }, {
                readonly name: "findByCategory";
                readonly params: readonly ["category: Category"];
                readonly returns: "MenuItem[]";
            }, {
                readonly name: "findAvailable";
                readonly params: readonly [];
                readonly returns: "MenuItem[]";
            }, {
                readonly name: "findByName";
                readonly params: readonly ["name: MenuItemName"];
                readonly returns: "MenuItem | null";
            }];
        };
    };
    export default menuItemRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "menuItemRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.defs" {
    export const orderRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "OrderRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Order";
            readonly interfaceName: "IOrderRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: OrderId"];
                readonly returns: "Order";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: OrderFilter"];
                readonly returns: "Order[]";
            }, {
                readonly name: "save";
                readonly params: readonly ["order: Order"];
                readonly returns: "void";
            }, {
                readonly name: "findActiveByTable";
                readonly params: readonly ["tableId: TableId"];
                readonly returns: "Order[]";
            }, {
                readonly name: "findByDateRange";
                readonly params: readonly ["start: OrderDate", "end: OrderDate"];
                readonly returns: "Order[]";
            }, {
                readonly name: "findWithPendingKitchenTickets";
                readonly params: readonly [];
                readonly returns: "Order[]";
            }];
        };
    };
    export default orderRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "orderRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.defs" {
    export const paymentRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "PaymentRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Payment";
            readonly interfaceName: "IPaymentRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: PaymentId"];
                readonly returns: "Payment";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: PaymentFilter"];
                readonly returns: "Payment[]";
            }, {
                readonly name: "save";
                readonly params: readonly ["payment: Payment"];
                readonly returns: "void";
            }, {
                readonly name: "findByOrder";
                readonly params: readonly ["orderId: OrderId"];
                readonly returns: "Payment[]";
            }, {
                readonly name: "findByDateRange";
                readonly params: readonly ["start: PaymentDate", "end: PaymentDate"];
                readonly returns: "Payment[]";
            }, {
                readonly name: "findPending";
                readonly params: readonly [];
                readonly returns: "Payment[]";
            }];
        };
    };
    export default paymentRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "paymentRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/addOrderItem.defs" {
    export const addOrderItemUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "addOrderItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "addOrderItem";
            readonly functionName: "addOrderItem";
            readonly inputTypeName: "AddOrderItemInput";
            readonly outputTypeName: "AddOrderItemOutput";
            readonly ports: readonly ["MenuItem", "Order"];
            readonly rulesApplied: readonly ["orderStatusTransitions", "ingredientConsumptionTrigger"];
            readonly transactional: true;
            readonly steps: readonly ["Validate order exists and is in an editable status (OPEN or SENT) per orderStatusTransitions", "Fetch MenuItem by id to validate availability and current price", "Create OrderItem with quantity, notes, and unit price snapshot from MenuItem", "Add OrderItem to Order aggregate and recompute Order.totalAmount", "Persist Order with new OrderItem via Order port", "If order status triggers ingredient consumption, enqueue stock consumption for the new item"];
        };
    };
    export default addOrderItemUsecase;
    export const pipeline: readonly [{
        readonly id: "addOrderItem__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/addOrderItem.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/addOrderItem.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "ingredientConsumptionTrigger"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/aiPromotionSuggestions.defs" {
    export const aiPromotionSuggestionsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "aiPromotionSuggestions";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "aiPromotionSuggestions";
            readonly functionName: "aiPromotionSuggestions";
            readonly inputTypeName: "AiPromotionSuggestionsInput";
            readonly outputTypeName: "AiPromotionSuggestionsOutput";
            readonly ports: readonly ["Order", "MenuItem"];
            readonly rulesApplied: readonly [];
            readonly transactional: false;
            readonly steps: readonly ["Read recent OrderItem history via Order port to identify top-selling and slow-moving items", "Read MenuItem catalog via MenuItem port for pricing and category context", "Aggregate sales volume and revenue per MenuItem", "Call AI service with aggregated data to generate promotion suggestions", "Return structured promotion recommendations"];
        };
    };
    export default aiPromotionSuggestionsUsecase;
    export const pipeline: readonly [{
        readonly id: "aiPromotionSuggestions__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/aiPromotionSuggestions.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/aiPromotionSuggestions.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/aiSalesSummary.defs" {
    export const aiSalesSummaryUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "aiSalesSummary";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "aiSalesSummary";
            readonly functionName: "aiSalesSummary";
            readonly inputTypeName: "AiSalesSummaryInput";
            readonly outputTypeName: "AiSalesSummaryOutput";
            readonly ports: readonly ["Order", "DailyShift", "MenuItem"];
            readonly rulesApplied: readonly ["aiOutputLanguageSelection"];
            readonly transactional: false;
            readonly steps: readonly ["Determine target language via aiOutputLanguageSelection rule", "Read Orders filtered by date range and dailyShiftId via Order port", "Read DailyShift summary data via DailyShift port", "Read MenuItem metadata via MenuItem port for item-level breakdown", "Aggregate totalAmount, status distribution, and closedAt timestamps", "Call AI service with aggregated data and selected language to produce sales summary", "Return formatted summary text and structured metrics"];
        };
    };
    export default aiSalesSummaryUsecase;
    export const pipeline: readonly [{
        readonly id: "aiSalesSummary__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/aiSalesSummary.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/aiSalesSummary.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/browseMenuForPos.defs" {
    export const browseMenuForPosUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "browseMenuForPos";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "browseMenuForPos";
            readonly functionName: "browseMenuForPos";
            readonly inputTypeName: "BrowseMenuForPosInput";
            readonly outputTypeName: "BrowseMenuForPosOutput";
            readonly ports: readonly ["MenuItem"];
            readonly rulesApplied: readonly ["aiOutputLanguageSelection"];
            readonly transactional: false;
            readonly steps: readonly ["Determine display language via aiOutputLanguageSelection rule", "Read all active MenuItems grouped by MenuCategory via MenuItem port", "Filter out unavailable or discontinued items", "Format items with localized names, prices, and category labels for POS display", "Return categorized menu tree"];
        };
    };
    export default browseMenuForPosUsecase;
    export const pipeline: readonly [{
        readonly id: "browseMenuForPos__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/browseMenuForPos.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/browseMenuForPos.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/closeDailyShift.defs" {
    export const closeDailyShiftUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "closeDailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "closeDailyShift";
            readonly functionName: "closeDailyShift";
            readonly inputTypeName: "CloseDailyShiftInput";
            readonly outputTypeName: "CloseDailyShiftOutput";
            readonly ports: readonly ["DailyShift", "Order", "Payment"];
            readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
            readonly transactional: true;
            readonly steps: readonly ["Fetch DailyShift via DailyShift port and validate status is OPEN", "Verify all Orders for the shift are CLOSED or CANCELLED via Order port", "Reconcile all Payments via Payment port against order totals", "Apply paymentTimingByOrderType to validate payment completeness per order type", "Calculate closingCashBalance from openingCashBalance + cash payments + cash movements", "Select language via aiOutputLanguageSelection for closing notes", "Update DailyShift: status=CLOSED, closedAt=now, closingCashBalance, closingNotes, totalSales, totalPayments", "Persist DailyShift via DailyShift port", "Return closed shift summary"];
        };
    };
    export default closeDailyShiftUsecase;
    export const pipeline: readonly [{
        readonly id: "closeDailyShift__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/closeDailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/closeDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/consumeIngredientsOnConfirmation.defs" {
    export const consumeIngredientsOnConfirmationUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "consumeIngredientsOnConfirmation";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "consumeIngredientsOnConfirmation";
            readonly functionName: "consumeIngredientsOnConfirmation";
            readonly inputTypeName: "ConsumeIngredientsOnConfirmationInput";
            readonly outputTypeName: "ConsumeIngredientsOnConfirmationOutput";
            readonly ports: readonly ["Order", "MenuItem", "InventoryItem"];
            readonly rulesApplied: readonly ["ingredientConsumptionTrigger"];
            readonly transactional: true;
            readonly steps: readonly ["Fetch Order and all OrderItems via Order port upon order confirmation event", "For each OrderItem, fetch MenuItem and resolve RecipeComponent to InventoryItem mappings via MenuItem port", "Calculate total consumption quantity per InventoryItem across all OrderItems", "Deduct quantities from InventoryItem aggregates via InventoryItem port", "Create StockConsumption records for each consumed ingredient", "Flag any InventoryItem falling below minimumLevel", "Persist all InventoryItem updates and StockConsumption records atomically", "Return consumption summary with any low-stock alerts"];
        };
    };
    export default consumeIngredientsOnConfirmationUsecase;
    export const pipeline: readonly [{
        readonly id: "consumeIngredientsOnConfirmation__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/consumeIngredientsOnConfirmation.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/consumeIngredientsOnConfirmation.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["ingredientConsumptionTrigger"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/createDailyShift.defs" {
    export const createDailyShiftUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createDailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createDailyShift";
            readonly functionName: "createDailyShift";
            readonly inputTypeName: "CreateDailyShiftInput";
            readonly outputTypeName: "CreateDailyShiftOutput";
            readonly ports: readonly ["DailyShift"];
            readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
            readonly transactional: true;
            readonly steps: readonly ["Check via DailyShift port that no shift is already OPEN for the target date", "Validate openingCashBalance is non-negative", "Create DailyShift with shiftDate, status=OPEN, openedAt=now, openingCashBalance", "Apply paymentTimingByOrderType defaults for the shift context", "Select language via aiOutputLanguageSelection for shift locale", "Persist DailyShift via DailyShift port", "Return created shift with generated dailyShiftId"];
        };
    };
    export default createDailyShiftUsecase;
    export const pipeline: readonly [{
        readonly id: "createDailyShift__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createDailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/createKitchenTicket.defs" {
    export const createKitchenTicketUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createKitchenTicket";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createKitchenTicket";
            readonly functionName: "createKitchenTicket";
            readonly inputTypeName: "CreateKitchenTicketInput";
            readonly outputTypeName: "CreateKitchenTicketOutput";
            readonly ports: readonly ["Order"];
            readonly rulesApplied: readonly ["orderStatusTransitions"];
            readonly transactional: true;
            readonly steps: readonly ["Fetch Order and its OrderItems via Order port", "Validate order status allows kitchen ticket creation per orderStatusTransitions (must be SENT or beyond)", "Filter OrderItems that require kitchen preparation", "Create KitchenTicket with line items mapped from OrderItems", "Set KitchenTicket status to PENDING", "Persist KitchenTicket", "Return created ticket"];
        };
    };
    export default createKitchenTicketUsecase;
    export const pipeline: readonly [{
        readonly id: "createKitchenTicket__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createKitchenTicket.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createKitchenTicket.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/createOrder.defs" {
    export const createOrderUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createOrder";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createOrder";
            readonly functionName: "createOrder";
            readonly inputTypeName: "CreateOrderInput";
            readonly outputTypeName: "CreateOrderOutput";
            readonly ports: readonly ["Order", "DailyShift"];
            readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "aiOutputLanguageSelection", "tableOccupancyConsistency"];
            readonly transactional: true;
            readonly steps: readonly ["Validate DailyShift is OPEN via DailyShift port", "If orderType is DINE_IN, validate table availability per tableOccupancyConsistency and assign tableId", "Determine payment timing per paymentTimingByOrderType rule (prepaid for takeout/delivery, postpaid for dine-in)", "Create Order with status=OPEN, dailyShiftId, orderType, tableId (if applicable)", "Apply aiOutputLanguageSelection for order locale", "Set initial orderStatusTransitions state", "Persist Order via Order port", "Return created order with generated orderId"];
        };
    };
    export default createOrderUsecase;
    export const pipeline: readonly [{
        readonly id: "createOrder__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createOrder.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createOrder.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "aiOutputLanguageSelection", "tableOccupancyConsistency"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/createStockConsumption.defs" {
    export const createStockConsumptionUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createStockConsumption";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createStockConsumption";
            readonly functionName: "createStockConsumption";
            readonly inputTypeName: "CreateStockConsumptionInput";
            readonly outputTypeName: "CreateStockConsumptionOutput";
            readonly ports: readonly ["Order", "MenuItem", "InventoryItem"];
            readonly rulesApplied: readonly ["ingredientConsumptionTrigger"];
            readonly transactional: true;
            readonly steps: readonly ["Fetch Order and its OrderItems via Order port", "For each OrderItem, fetch MenuItem and resolve RecipeComponent ingredients via MenuItem port", "Calculate required quantity per InventoryItem based on recipe and item quantity", "Check current InventoryItem quantities via InventoryItem port", "Deduct consumed quantities from InventoryItem aggregates", "Create StockConsumption records linking OrderItem to InventoryItem with consumed amounts", "Persist updated InventoryItems and StockConsumption records", "Flag any InventoryItem that falls below minimumLevel"];
        };
    };
    export default createStockConsumptionUsecase;
    export const pipeline: readonly [{
        readonly id: "createStockConsumption__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createStockConsumption.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createStockConsumption.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["ingredientConsumptionTrigger"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/dineInOrderLifecycle.defs" {
    export const dineInOrderLifecycleUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "dineInOrderLifecycle";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "dineInOrderLifecycle";
            readonly functionName: "dineInOrderLifecycle";
            readonly inputTypeName: "DineInOrderLifecycleInput";
            readonly outputTypeName: "DineInOrderLifecycleOutput";
            readonly ports: readonly ["Order", "DailyShift"];
            readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "tableOccupancyConsistency"];
            readonly transactional: true;
            readonly steps: readonly ["Validate DailyShift is OPEN via DailyShift port", "Validate and reserve Table per tableOccupancyConsistency (set OCCUPIED)", "Create Order with orderType=DINE_IN, status=OPEN, tableId via Order port", "Add OrderItems to the order (delegates to addOrderItem logic)", "Transition order to SENT and create KitchenTicket", "On kitchen readiness, transition items to READY then SERVED", "Process payment post-meal per paymentTimingByOrderType (dine-in = postpaid)", "Transition order to CLOSED, release Table per tableOccupancyConsistency", "Return completed order lifecycle result"];
        };
    };
    export default dineInOrderLifecycleUsecase;
    export const pipeline: readonly [{
        readonly id: "dineInOrderLifecycle__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/dineInOrderLifecycle.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/dineInOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "tableOccupancyConsistency"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/generateShiftCloseReport.defs" {
    export const generateShiftCloseReportUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "generateShiftCloseReport";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "generateShiftCloseReport";
            readonly functionName: "generateShiftCloseReport";
            readonly inputTypeName: "GenerateShiftCloseReportInput";
            readonly outputTypeName: "GenerateShiftCloseReportOutput";
            readonly ports: readonly ["DailyShift", "Payment", "Order"];
            readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
            readonly transactional: false;
            readonly steps: readonly ["Fetch DailyShift by id via DailyShift port including openingCashBalance, closingCashBalance, openedAt, closedAt, status", "Read all Payments for the shift via Payment port", "Read all Orders and OrderItems for the shift via Order port", "Apply paymentTimingByOrderType to categorize payments by order type", "Select report language via aiOutputLanguageSelection", "Calculate totalSales, totalPayments, cash reconciliation, and variance", "Compile closingNotes and summary metrics", "Return structured shift close report"];
        };
    };
    export default generateShiftCloseReportUsecase;
    export const pipeline: readonly [{
        readonly id: "generateShiftCloseReport__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/generateShiftCloseReport.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/generateShiftCloseReport.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/kitchenProductionFlow.defs" {
    export const kitchenProductionFlowUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "kitchenProductionFlow";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "kitchenProductionFlow";
            readonly functionName: "kitchenProductionFlow";
            readonly inputTypeName: "KitchenProductionFlowInput";
            readonly outputTypeName: "KitchenProductionFlowOutput";
            readonly ports: readonly ["Order"];
            readonly rulesApplied: readonly ["orderStatusTransitions"];
            readonly transactional: true;
            readonly steps: readonly ["Receive KitchenTicket created from Order via Order port", "Transition ticket items through PENDING -> PREPARING per orderStatusTransitions", "As each item completes, transition to READY and notify service staff", "When all items are READY, mark KitchenTicket as COMPLETED", "Trigger order status update to READY if all kitchen tickets for the order are completed", "Return production flow result with ticket and item statuses"];
        };
    };
    export default kitchenProductionFlowUsecase;
    export const pipeline: readonly [{
        readonly id: "kitchenProductionFlow__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/kitchenProductionFlow.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/kitchenProductionFlow.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/manageInventoryItems.defs" {
    export const manageInventoryItemsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "manageInventoryItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "manageInventoryItems";
            readonly functionName: "manageInventoryItems";
            readonly inputTypeName: "ManageInventoryItemsInput";
            readonly outputTypeName: "ManageInventoryItemsOutput";
            readonly ports: readonly ["InventoryItem"];
            readonly rulesApplied: readonly ["inventoryLowStockThreshold", "ingredientConsumptionTrigger"];
            readonly transactional: true;
            readonly steps: readonly ["Perform CRUD operation (create/update/delete) on InventoryItem via InventoryItem port", "Validate name, unit, currentQuantity, and minimumLevel fields", "After update, evaluate inventoryLowStockThreshold: if currentQuantity <= minimumLevel, set status to LOW_STOCK", "Check ingredientConsumptionTrigger dependencies to ensure item is not referenced in pending consumptions before deletion", "Persist changes and return updated InventoryItem(s)"];
        };
    };
    export default manageInventoryItemsUsecase;
    export const pipeline: readonly [{
        readonly id: "manageInventoryItems__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageInventoryItems.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageInventoryItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["inventoryLowStockThreshold", "ingredientConsumptionTrigger"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuCategories.defs" {
    export const manageMenuCategoriesUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "manageMenuCategories";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "manageMenuCategories";
            readonly functionName: "manageMenuCategories";
            readonly inputTypeName: "ManageMenuCategoriesInput";
            readonly outputTypeName: "ManageMenuCategoriesOutput";
            readonly ports: readonly [];
            readonly transactional: true;
            readonly steps: readonly ["Perform CRUD operation on MenuCategory (create/update/delete)", "Validate category name uniqueness and display order", "Persist changes and return updated MenuCategory(ies)"];
        };
    };
    export default manageMenuCategoriesUsecase;
    export const pipeline: readonly [{
        readonly id: "manageMenuCategories__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuCategories.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuCategories.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuItems.defs" {
    export const manageMenuItemsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "manageMenuItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "manageMenuItems";
            readonly functionName: "manageMenuItems";
            readonly inputTypeName: "ManageMenuItemsInput";
            readonly outputTypeName: "ManageMenuItemsOutput";
            readonly ports: readonly ["MenuItem"];
            readonly rulesApplied: readonly ["aiOutputLanguageSelection"];
            readonly transactional: true;
            readonly steps: readonly ["Perform CRUD operation on MenuItem via MenuItem port", "Validate name, price, category assignment, and availability fields", "Apply aiOutputLanguageSelection for localized name/description fields", "Persist changes and return updated MenuItem(s)"];
        };
    };
    export default manageMenuItemsUsecase;
    export const pipeline: readonly [{
        readonly id: "manageMenuItems__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuItems.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/manageTables.defs" {
    export const manageTablesUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "manageTables";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "manageTables";
            readonly functionName: "manageTables";
            readonly inputTypeName: "ManageTablesInput";
            readonly outputTypeName: "ManageTablesOutput";
            readonly ports: readonly [];
            readonly transactional: true;
            readonly steps: readonly ["Perform CRUD operation on Table (create/update/delete)", "Validate table number uniqueness and capacity fields", "Apply tableOccupancyConsistency: prevent deletion or status change if table has active orders", "Persist changes and return updated Table(s)"];
        };
    };
    export default manageTablesUsecase;
    export const pipeline: readonly [{
        readonly id: "manageTables__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageTables.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageTables.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/openDailyShift.defs" {
    export const openDailyShiftUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "openDailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "openDailyShift";
            readonly functionName: "openDailyShift";
            readonly inputTypeName: "OpenDailyShiftInput";
            readonly outputTypeName: "OpenDailyShiftOutput";
            readonly ports: readonly ["DailyShift"];
            readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
            readonly transactional: true;
            readonly steps: readonly ["Validate no DailyShift is currently OPEN via DailyShift port", "Create DailyShift with shiftDate=today, status=OPEN, openedAt=now, openingCashBalance via DailyShift port", "Apply paymentTimingByOrderType defaults for the new shift", "Select language via aiOutputLanguageSelection for shift locale", "Record opening CashMovement (movementType=OPENING) linked to the new shift", "Persist DailyShift and CashMovement atomically", "Return opened shift with dailyShiftId"];
        };
    };
    export default openDailyShiftUsecase;
    export const pipeline: readonly [{
        readonly id: "openDailyShift__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/openDailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/openDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/recordOpeningCashMovement.defs" {
    export const recordOpeningCashMovementUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "recordOpeningCashMovement";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "recordOpeningCashMovement";
            readonly functionName: "recordOpeningCashMovement";
            readonly inputTypeName: "RecordOpeningCashMovementInput";
            readonly outputTypeName: "RecordOpeningCashMovementOutput";
            readonly ports: readonly ["DailyShift"];
            readonly transactional: true;
            readonly steps: readonly ["Validate DailyShift exists and is OPEN via DailyShift port", "Create CashMovement with dailyShiftId, movementType=OPENING, amount, reason", "Set createdAt and updatedAt timestamps", "Persist CashMovement linked to DailyShift", "Return created cash movement"];
        };
    };
    export default recordOpeningCashMovementUsecase;
    export const pipeline: readonly [{
        readonly id: "recordOpeningCashMovement__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/recordOpeningCashMovement.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/recordOpeningCashMovement.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/recordPayment.defs" {
    export const recordPaymentUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "recordPayment";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "recordPayment";
            readonly functionName: "recordPayment";
            readonly inputTypeName: "RecordPaymentInput";
            readonly outputTypeName: "RecordPaymentOutput";
            readonly ports: readonly ["Payment", "Order", "DailyShift"];
            readonly rulesApplied: readonly ["paymentTimingByOrderType"];
            readonly transactional: true;
            readonly steps: readonly ["Fetch Order via Order port to validate it exists and is in a payable status", "Fetch DailyShift via DailyShift port to validate shift is OPEN", "Apply paymentTimingByOrderType: validate payment timing matches order type rules (e.g., takeout must be prepaid)", "Create Payment with orderId, amount, method, and shift reference", "Persist Payment via Payment port", "Update Order payment status if fully paid", "Return recorded payment"];
        };
    };
    export default recordPaymentUsecase;
    export const pipeline: readonly [{
        readonly id: "recordPayment__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/recordPayment.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/recordPayment.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/takeoutOrderLifecycle.defs" {
    export const takeoutOrderLifecycleUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "takeoutOrderLifecycle";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "takeoutOrderLifecycle";
            readonly functionName: "takeoutOrderLifecycle";
            readonly inputTypeName: "TakeoutOrderLifecycleInput";
            readonly outputTypeName: "TakeoutOrderLifecycleOutput";
            readonly ports: readonly ["Order", "DailyShift"];
            readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType"];
            readonly transactional: true;
            readonly steps: readonly ["Validate DailyShift is OPEN via DailyShift port", "Create Order with orderType=TAKEOUT, status=OPEN via Order port (no table assignment needed)", "Add OrderItems to the order (delegates to addOrderItem logic)", "Process payment upfront per paymentTimingByOrderType (takeout = prepaid)", "Transition order to SENT and create KitchenTicket", "On kitchen readiness, transition items to READY", "Customer picks up; transition order to CLOSED", "Return completed order lifecycle result"];
        };
    };
    export default takeoutOrderLifecycleUsecase;
    export const pipeline: readonly [{
        readonly id: "takeoutOrderLifecycle__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/takeoutOrderLifecycle.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/takeoutOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/updateKitchenTicketStatus.defs" {
    export const updateKitchenTicketStatusUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateKitchenTicketStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateKitchenTicketStatus";
            readonly functionName: "updateKitchenTicketStatus";
            readonly inputTypeName: "UpdateKitchenTicketStatusInput";
            readonly outputTypeName: "UpdateKitchenTicketStatusOutput";
            readonly ports: readonly [];
            readonly transactional: true;
            readonly steps: readonly ["Fetch KitchenTicket by id", "Validate current status allows transition to target status per orderStatusTransitions", "Update KitchenTicket.status and set updatedAt", "Persist updated KitchenTicket", "Return updated ticket"];
        };
    };
    export default updateKitchenTicketStatusUsecase;
    export const pipeline: readonly [{
        readonly id: "updateKitchenTicketStatus__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateKitchenTicketStatus.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateKitchenTicketStatus.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderItemStatus.defs" {
    export const updateOrderItemStatusUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateOrderItemStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateOrderItemStatus";
            readonly functionName: "updateOrderItemStatus";
            readonly inputTypeName: "UpdateOrderItemStatusInput";
            readonly outputTypeName: "UpdateOrderItemStatusOutput";
            readonly ports: readonly [];
            readonly transactional: true;
            readonly steps: readonly ["Fetch OrderItem by id including current status", "Validate status transition per orderStatusTransitions (e.g., PENDING -> PREPARING -> READY -> SERVED)", "Update OrderItem.status and set updatedAt", "If transition to READY or SERVED, evaluate ingredientConsumptionTrigger to ensure stock consumption has been recorded", "Persist updated OrderItem", "Return updated order item"];
        };
    };
    export default updateOrderItemStatusUsecase;
    export const pipeline: readonly [{
        readonly id: "updateOrderItemStatus__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderItemStatus.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderItemStatus.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.defs" {
    export const updateOrderStatusUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateOrderStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateOrderStatus";
            readonly functionName: "updateOrderStatus";
            readonly inputTypeName: "UpdateOrderStatusInput";
            readonly outputTypeName: "UpdateOrderStatusOutput";
            readonly ports: readonly ["Order", "Payment", "InventoryItem"];
            readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "aiOutputLanguageSelection", "tableOccupancyConsistency"];
            readonly transactional: true;
            readonly steps: readonly ["Fetch Order with OrderItems, KitchenTickets, and Table via Order port", "Validate status transition per orderStatusTransitions (OPEN -> SENT -> PREPARING -> READY -> SERVED -> CLOSED or CANCELLED)", "If transitioning to CLOSED: validate all Payments are settled per paymentTimingByOrderType, set closedAt", "If transitioning to CANCELLED: set cancelledAt and cancellationReason, release table per tableOccupancyConsistency", "If transitioning to confirmation status: trigger ingredientConsumptionTrigger to deduct InventoryItem stock via InventoryItem port", "If dine-in and closing: release Table per tableOccupancyConsistency", "Apply aiOutputLanguageSelection for any localized notifications", "Update Order.status and updatedAt, persist via Order port", "Return updated order"];
        };
    };
    export default updateOrderStatusUsecase;
    export const pipeline: readonly [{
        readonly id: "updateOrderStatus__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "aiOutputLanguageSelection", "tableOccupancyConsistency"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/updateTableStatus.defs" {
    export const updateTableStatusUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateTableStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateTableStatus";
            readonly functionName: "updateTableStatus";
            readonly inputTypeName: "UpdateTableStatusInput";
            readonly outputTypeName: "UpdateTableStatusOutput";
            readonly ports: readonly [];
            readonly transactional: true;
            readonly steps: readonly ["Fetch Table by id", "Validate tableOccupancyConsistency: cannot set AVAILABLE if active orders exist; cannot set OCCUPIED without linked order", "Update Table.status and set updatedAt", "Persist updated Table", "Return updated table"];
        };
    };
    export default updateTableStatusUsecase;
    export const pipeline: readonly [{
        readonly id: "updateTableStatus__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateTableStatus.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateTableStatus.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/viewKitchenTickets.defs" {
    export const viewKitchenTicketsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "viewKitchenTickets";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "viewKitchenTickets";
            readonly functionName: "viewKitchenTickets";
            readonly inputTypeName: "ViewKitchenTicketsInput";
            readonly outputTypeName: "ViewKitchenTicketsOutput";
            readonly ports: readonly [];
            readonly transactional: false;
            readonly steps: readonly ["Query KitchenTickets with optional status filter", "Sort by creation time (oldest first for FIFO production)", "Return list of kitchen tickets with line items"];
        };
    };
    export default viewKitchenTicketsUsecase;
    export const pipeline: readonly [{
        readonly id: "viewKitchenTickets__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/viewKitchenTickets.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/viewKitchenTickets.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/viewOperationalDashboard.defs" {
    export const viewOperationalDashboardUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "viewOperationalDashboard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "viewOperationalDashboard";
            readonly functionName: "viewOperationalDashboard";
            readonly inputTypeName: "ViewOperationalDashboardInput";
            readonly outputTypeName: "ViewOperationalDashboardOutput";
            readonly ports: readonly ["DailyShift", "Order", "Payment"];
            readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
            readonly transactional: false;
            readonly steps: readonly ["Fetch current DailyShift via DailyShift port", "Read active and recent Orders via Order port for the current shift", "Read Payments via Payment port for the current shift", "Apply paymentTimingByOrderType to categorize revenue by order type", "Select dashboard language via aiOutputLanguageSelection", "Aggregate KPIs: total sales, open orders, kitchen load, payment breakdown", "Return structured dashboard data"];
        };
    };
    export default viewOperationalDashboardUsecase;
    export const pipeline: readonly [{
        readonly id: "viewOperationalDashboard__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/viewOperationalDashboard.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/viewOperationalDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.defs" {
    export const dailyShiftDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "DailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "DailyShift";
            readonly fields: readonly [{
                readonly fieldId: "dailyShiftId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do turno diário.";
            }, {
                readonly fieldId: "shiftDate";
                readonly type: "date";
                readonly required: true;
                readonly description: "Data operacional do turno.";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Estado atual do turno.";
                readonly enum: readonly ["open", "closed"];
            }, {
                readonly fieldId: "openedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de abertura do turno.";
            }, {
                readonly fieldId: "closedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora de fechamento do turno.";
            }, {
                readonly fieldId: "openingCashBalance";
                readonly type: "money";
                readonly required: false;
                readonly description: "Valor inicial em caixa ao abrir o turno.";
            }, {
                readonly fieldId: "closingCashBalance";
                readonly type: "money";
                readonly required: false;
                readonly description: "Valor final em caixa ao fechar o turno.";
            }, {
                readonly fieldId: "totalSales";
                readonly type: "money";
                readonly required: false;
                readonly description: "Total consolidado de vendas no turno.";
            }, {
                readonly fieldId: "totalPayments";
                readonly type: "money";
                readonly required: false;
                readonly description: "Total consolidado de pagamentos recebidos no turno.";
            }, {
                readonly fieldId: "closingNotes";
                readonly type: "text";
                readonly required: false;
                readonly description: "Observações e relatório de fechamento do turno.";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro.";
            }];
            readonly statusEnum: readonly ["open", "closed"];
            readonly invariants: readonly ["only one DailyShift per shiftDate may be open at a time", "when status is closed, closedAt and closingCashBalance must be set", "status can only transition from open to closed", "cash movements cannot be added to a closed shift", "openingCashBalance must be set when the shift is opened", "totalSales and totalPayments are computed from associated orders and payments during the shift"];
            readonly valueObjects: readonly [{
                readonly name: "CashMovement";
                readonly fields: readonly [{
                    readonly fieldId: "cashMovementId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do movimento de caixa";
                }, {
                    readonly fieldId: "dailyShiftId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao turno (DailyShift) ao qual o movimento pertence";
                }, {
                    readonly fieldId: "movementType";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Tipo do movimento: entrada ou saída de caixa";
                    readonly enum: readonly ["entrada", "saída"];
                }, {
                    readonly fieldId: "amount";
                    readonly type: "money";
                    readonly required: true;
                    readonly description: "Valor do movimento";
                }, {
                    readonly fieldId: "reason";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Motivo do movimento (ex.: sangria, reforço, estorno)";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data/hora de criação do registro";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data/hora da última atualização do registro";
                }];
                readonly collection: true;
            }];
        };
    };
    export default dailyShiftDomainEntity;
    export const pipeline: readonly [{
        readonly id: "dailyShift__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_4.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.defs" {
    export const inventoryItemDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "InventoryItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "InventoryItem";
            readonly fields: readonly [{
                readonly fieldId: "inventoryItemId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do item de estoque";
            }, {
                readonly fieldId: "name";
                readonly type: "string";
                readonly required: true;
                readonly description: "Nome do ingrediente ou insumo";
            }, {
                readonly fieldId: "description";
                readonly type: "text";
                readonly required: false;
                readonly description: "Descrição detalhada do item";
            }, {
                readonly fieldId: "unit";
                readonly type: "string";
                readonly required: true;
                readonly description: "Unidade de medida (ex.: kg, L, unidade, gramas)";
            }, {
                readonly fieldId: "currentQuantity";
                readonly type: "number";
                readonly required: true;
                readonly description: "Quantidade atual disponível em estoque";
            }, {
                readonly fieldId: "minimumLevel";
                readonly type: "number";
                readonly required: true;
                readonly description: "Nível mínimo para geração de alerta de baixo estoque";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Estado do ciclo de vida do item";
                readonly enum: readonly ["active", "inactive"];
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro";
            }];
            readonly statusEnum: readonly ["active", "inactive"];
            readonly invariants: readonly ["currentQuantity must be greater than or equal to zero", "minimumLevel must be greater than or equal to zero", "name must not be empty", "unit must not be empty", "status can transition from active to inactive and inactive to active", "when currentQuantity falls below minimumLevel a low-stock alert condition is triggered"];
            readonly valueObjects: readonly [];
        };
    };
    export default inventoryItemDomainEntity;
    export const pipeline: readonly [{
        readonly id: "inventoryItem__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_4.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.defs" {
    export const menuItemDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "MenuItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "MenuItem";
            readonly fields: readonly [{
                readonly fieldId: "menuItemId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do item do cardápio";
            }, {
                readonly fieldId: "menuCategoryId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência à categoria do cardápio à qual o item pertence";
            }, {
                readonly fieldId: "name";
                readonly type: "string";
                readonly required: true;
                readonly description: "Nome do item (ex.: cappuccino, pão de queijo)";
            }, {
                readonly fieldId: "description";
                readonly type: "text";
                readonly required: false;
                readonly description: "Descrição detalhada do item";
            }, {
                readonly fieldId: "price";
                readonly type: "money";
                readonly required: true;
                readonly description: "Preço de venda do item";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Estado do ciclo de vida do item";
                readonly enum: readonly ["draft", "active", "inactive"];
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro";
            }];
            readonly statusEnum: readonly ["draft", "active", "inactive"];
            readonly invariants: readonly ["price must be greater than or equal to zero", "name must not be empty", "status can transition from draft to active, active to inactive, and inactive back to active", "at least one RecipeComponent should exist for an active MenuItem"];
            readonly valueObjects: readonly [{
                readonly name: "RecipeComponent";
                readonly fields: readonly [{
                    readonly fieldId: "recipeComponentId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do componente de receita";
                }, {
                    readonly fieldId: "menuItemId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao item de menu ao qual este componente pertence";
                }, {
                    readonly fieldId: "inventoryItemId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao item de inventário utilizado como ingrediente";
                }, {
                    readonly fieldId: "quantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade consumida do item de inventário por unidade vendida do menu item";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do registro";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do registro";
                }];
                readonly collection: true;
            }];
        };
    };
    export default menuItemDomainEntity;
    export const pipeline: readonly [{
        readonly id: "menuItem__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_4.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_3_domain/entities/order.defs" {
    export const orderDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Order";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Order";
            readonly fields: readonly [{
                readonly fieldId: "orderId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do pedido";
            }, {
                readonly fieldId: "dailyShiftId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Turno diário em que o pedido foi registrado";
            }, {
                readonly fieldId: "tableId";
                readonly type: "uuid";
                readonly required: false;
                readonly description: "Referência à mesa associada (para pedidos do tipo mesa)";
            }, {
                readonly fieldId: "kitchenTicketId";
                readonly type: "uuid";
                readonly required: false;
                readonly description: "Ticket de cozinha gerado para fila de preparo";
            }, {
                readonly fieldId: "orderType";
                readonly type: "string";
                readonly required: true;
                readonly description: "Tipo do pedido: mesa ou takeout";
                readonly enum: readonly ["mesa", "takeout"];
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Status atual do pedido na coordenação com a cozinha";
                readonly enum: readonly ["draft", "sentToKitchen", "inPreparation", "ready", "served", "closed", "cancelled"];
            }, {
                readonly fieldId: "totalAmount";
                readonly type: "money";
                readonly required: true;
                readonly description: "Valor total do pedido com preços no momento da venda";
            }, {
                readonly fieldId: "notes";
                readonly type: "text";
                readonly required: false;
                readonly description: "Observações gerais do pedido";
            }, {
                readonly fieldId: "customerName";
                readonly type: "string";
                readonly required: false;
                readonly description: "Nome do cliente para identificação do pedido";
            }, {
                readonly fieldId: "customerPhone";
                readonly type: "string";
                readonly required: false;
                readonly description: "Telefone de contato do cliente";
            }, {
                readonly fieldId: "numberOfGuests";
                readonly type: "number";
                readonly required: false;
                readonly description: "Número de pessoas na mesa";
            }, {
                readonly fieldId: "closedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora do fechamento do pedido";
            }, {
                readonly fieldId: "cancelledAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora do cancelamento do pedido";
            }, {
                readonly fieldId: "cancellationReason";
                readonly type: "text";
                readonly required: false;
                readonly description: "Motivo do cancelamento";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro";
            }];
            readonly statusEnum: readonly ["draft", "sentToKitchen", "inPreparation", "ready", "served", "closed", "cancelled"];
            readonly invariants: readonly ["totalAmount must equal the sum of all OrderItem.totalPrice", "when orderType is mesa, tableId is required", "when orderType is mesa, numberOfGuests should be greater than zero", "status transitions must follow: draft -> sentToKitchen -> inPreparation -> ready -> served -> closed; cancelled can occur from any state before closed", "when status is closed, closedAt must be set", "when status is cancelled, cancelledAt and cancellationReason must be set", "an order cannot be modified after it is closed or cancelled", "at least one OrderItem is required before sending to kitchen"];
            readonly valueObjects: readonly [{
                readonly name: "OrderItem";
                readonly fields: readonly [{
                    readonly fieldId: "id";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do item do pedido";
                }, {
                    readonly fieldId: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao pedido (Order) ao qual este item pertence";
                }, {
                    readonly fieldId: "menuItemId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao item do cardápio (MenuItem) solicitado";
                }, {
                    readonly fieldId: "kitchenTicketId";
                    readonly type: "uuid";
                    readonly required: false;
                    readonly description: "Referência ao ticket de cozinha (KitchenTicket) quando o item exige preparo";
                }, {
                    readonly fieldId: "quantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade solicitada do item";
                }, {
                    readonly fieldId: "unitPrice";
                    readonly type: "money";
                    readonly required: true;
                    readonly description: "Preço unitário do item no momento do pedido";
                }, {
                    readonly fieldId: "totalPrice";
                    readonly type: "money";
                    readonly required: true;
                    readonly description: "Preço total do item (quantidade × preço unitário)";
                }, {
                    readonly fieldId: "observations";
                    readonly type: "text";
                    readonly required: false;
                    readonly description: "Observações ou instruções especiais para o item";
                }, {
                    readonly fieldId: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Status de produção/atendimento do item";
                    readonly enum: readonly ["new", "sentToKitchen", "inPreparation", "ready", "served", "cancelled"];
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do registro";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do registro";
                }];
                readonly collection: true;
            }, {
                readonly name: "KitchenTicket";
                readonly fields: readonly [{
                    readonly fieldId: "kitchenTicketId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do ticket de cozinha";
                }, {
                    readonly fieldId: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao pedido que gerou este ticket para a fila de preparo";
                }, {
                    readonly fieldId: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Status atual do ticket na fila de preparo da cozinha";
                    readonly enum: readonly ["open", "inProgress", "done", "void"];
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do ticket";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do ticket";
                }];
                readonly collection: true;
            }];
        };
    };
    export default orderDomainEntity;
    export const pipeline: readonly [{
        readonly id: "order__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/order.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/order.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_4.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.defs" {
    export const paymentDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Payment";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Payment";
            readonly fields: readonly [{
                readonly fieldId: "paymentId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do pagamento.";
            }, {
                readonly fieldId: "orderId";
                readonly type: "uuid";
                readonly required: false;
                readonly description: "Referência ao pedido associado ao pagamento, quando aplicável.";
            }, {
                readonly fieldId: "dailyShiftId";
                readonly type: "uuid";
                readonly required: false;
                readonly description: "Referência ao turno diário de fechamento ao qual o pagamento será consolidado.";
            }, {
                readonly fieldId: "method";
                readonly type: "string";
                readonly required: true;
                readonly description: "Método de pagamento utilizado (ex.: dinheiro, cartão de crédito, PIX).";
            }, {
                readonly fieldId: "amount";
                readonly type: "money";
                readonly required: true;
                readonly description: "Valor recebido/pago.";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Situação atual do pagamento no ciclo de vida.";
                readonly enum: readonly ["authorized", "captured", "voided", "refunded"];
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro.";
            }];
            readonly statusEnum: readonly ["authorized", "captured", "voided", "refunded"];
            readonly invariants: readonly ["amount must be greater than zero", "method must not be empty", "status transitions: authorized -> captured; authorized -> voided; captured -> refunded", "voided can only occur from authorized status", "refunded can only occur from captured status", "once voided or refunded no further status transitions are allowed", "dailyShiftId must reference an open shift at the time of payment creation"];
            readonly valueObjects: readonly [];
        };
    };
    export default paymentDomainEntity;
    export const pipeline: readonly [{
        readonly id: "payment__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_4.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: any[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "aiPromotionSuggestions__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: any[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "aiSalesSummary__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: any[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "browseMenuForPos__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "closeDailyShift__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "consumeIngredientsOnConfirmation__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "dineInOrderLifecycle__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: any[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "generateShiftCloseReport__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "kitchenProductionFlow__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "manageInventoryItems__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: any[];
    }[];
    export const pipeline: readonly [{
        readonly id: "manageMenuCategories__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageMenuItems.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "manageMenuItems__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/manageMenuItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/manageMenuItems.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageTables.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "manageTables__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/manageTables.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/manageTables.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/openDailyShift.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "openDailyShift__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/openDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/openDailyShift.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/recordPayment.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "recordPayment__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/recordPayment.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/recordPayment.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "takeoutOrderLifecycle__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: any[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "viewOperationalDashboard__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/aiPromotionSuggestions.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: any[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "aiPromotionSuggestions__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/aiPromotionSuggestions.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/aiPromotionSuggestions.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/aiPromotionSuggestions.ts", "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/aiSalesSummary.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "aiSalesSummary__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/aiSalesSummary.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/aiSalesSummary.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/aiSalesSummary.ts", "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/browseMenuForPos.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                molecules: ({
                    id: string;
                    type: string;
                    order: number;
                    titleKey: string;
                    submitAction: string;
                    fields: {
                        id: string;
                        field: string;
                        labelKey: string;
                        order: number;
                        required: boolean;
                        inputType: string;
                        source: string;
                    }[];
                    columns: any[];
                    filters: any[];
                    toolbar: any[];
                    rowActions: any[];
                    actions: any[];
                    source?: undefined;
                } | {
                    id: string;
                    type: string;
                    order: number;
                    titleKey: string;
                    source: string;
                    fields: any[];
                    columns: ({
                        id: string;
                        field: string;
                        labelKey: string;
                        order: number;
                        required: boolean;
                        format?: undefined;
                    } | {
                        id: string;
                        field: string;
                        labelKey: string;
                        order: number;
                        required: boolean;
                        format: string;
                    })[];
                    filters: any[];
                    toolbar: {
                        id: string;
                        action: string;
                        labelKey: string;
                        order: number;
                        displayHint: string;
                    }[];
                    rowActions: any[];
                    actions: any[];
                    submitAction?: undefined;
                })[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    molecules: ({
                        id: string;
                        type: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        source?: undefined;
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                        })[];
                        filters: any[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                        submitAction?: undefined;
                    })[];
                }[];
            }[];
        };
        i18n: {
            "browseMenuForPos.section.title": string;
            "browseMenuForPos.organism.title": string;
            "browseMenuForPos.filterForm.title": string;
            "browseMenuForPos.field.menuCategoryId": string;
            "browseMenuForPos.field.name": string;
            "browseMenuForPos.field.status": string;
            "browseMenuForPos.resultsTable.title": string;
            "browseMenuForPos.col.menuItemId": string;
            "browseMenuForPos.col.menuCategoryId": string;
            "browseMenuForPos.col.name": string;
            "browseMenuForPos.col.description": string;
            "browseMenuForPos.col.price": string;
            "browseMenuForPos.col.status": string;
            "browseMenuForPos.col.createdAt": string;
            "browseMenuForPos.col.updatedAt": string;
            "browseMenuForPos.action.refresh": string;
        };
        dataBindings: {
            id: string;
            source: string;
            command: string;
            description: string;
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "browseMenuForPos__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/browseMenuForPos.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/browseMenuForPos.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/browseMenuForPos.ts", "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/closeDailyShift.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: any[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "closeDailyShift__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/closeDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/closeDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/closeDailyShift.ts", "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/consumeIngredientsOnConfirmation.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: string[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "consumeIngredientsOnConfirmation__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/consumeIngredientsOnConfirmation.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/consumeIngredientsOnConfirmation.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/consumeIngredientsOnConfirmation.ts", "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/dineInOrderLifecycle.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                molecules: ({
                    id: string;
                    type: string;
                    order: number;
                    titleKey: string;
                    fields: {
                        id: string;
                        field: string;
                        labelKey: string;
                        order: number;
                        required: boolean;
                    }[];
                    columns: any[];
                    filters: any[];
                    toolbar: any[];
                    rowActions: any[];
                    actions: any[];
                } | {
                    id: string;
                    type: string;
                    order: number;
                    titleKey: string;
                    fields: {
                        id: string;
                        field: string;
                        labelKey: string;
                        order: number;
                        required: boolean;
                        inputType: string;
                    }[];
                    columns: any[];
                    filters: any[];
                    toolbar: any[];
                    rowActions: any[];
                    actions: any[];
                } | {
                    id: string;
                    type: string;
                    order: number;
                    titleKey: string;
                    fields: any[];
                    columns: any[];
                    filters: any[];
                    toolbar: any[];
                    rowActions: any[];
                    actions: {
                        id: string;
                        action: string;
                        labelKey: string;
                        order: number;
                        displayHint: string;
                    }[];
                })[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    molecules: ({
                        id: string;
                        type: string;
                        order: number;
                        titleKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        titleKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        titleKey: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                        }[];
                    })[];
                }[];
            }[];
        };
        i18n: {
            "dineInOrderLifecycle.section.title": string;
            "dineInOrderLifecycle.createOrder.title": string;
            "dineInOrderLifecycle.createOrder.form.title": string;
            "dineInOrderLifecycle.createOrder.actions.title": string;
            "dineInOrderLifecycle.addOrderItem.title": string;
            "dineInOrderLifecycle.addOrderItem.form.title": string;
            "dineInOrderLifecycle.addOrderItem.actions.title": string;
            "dineInOrderLifecycle.createKitchenTicket.title": string;
            "dineInOrderLifecycle.createKitchenTicket.form.title": string;
            "dineInOrderLifecycle.createKitchenTicket.actions.title": string;
            "dineInOrderLifecycle.updateOrderStatus.title": string;
            "dineInOrderLifecycle.updateOrderStatus.summary.title": string;
            "dineInOrderLifecycle.updateOrderStatus.form.title": string;
            "dineInOrderLifecycle.updateOrderStatus.actions.title": string;
            "dineInOrderLifecycle.updateTableStatus.title": string;
            "dineInOrderLifecycle.updateTableStatus.form.title": string;
            "dineInOrderLifecycle.updateTableStatus.actions.title": string;
            "dineInOrderLifecycle.fields.orderType": string;
            "dineInOrderLifecycle.fields.status": string;
            "dineInOrderLifecycle.fields.totalAmount": string;
            "dineInOrderLifecycle.fields.notes": string;
            "dineInOrderLifecycle.fields.customerName": string;
            "dineInOrderLifecycle.fields.customerPhone": string;
            "dineInOrderLifecycle.fields.numberOfGuests": string;
            "dineInOrderLifecycle.fields.closedAt": string;
            "dineInOrderLifecycle.fields.cancelledAt": string;
            "dineInOrderLifecycle.fields.cancellationReason": string;
            "dineInOrderLifecycle.fields.quantity": string;
            "dineInOrderLifecycle.fields.unitPrice": string;
            "dineInOrderLifecycle.fields.totalPrice": string;
            "dineInOrderLifecycle.fields.observations": string;
            "dineInOrderLifecycle.fields.itemStatus": string;
            "dineInOrderLifecycle.fields.kitchenTicketStatus": string;
            "dineInOrderLifecycle.fields.tableId": string;
            "dineInOrderLifecycle.fields.tableStatus": string;
            "dineInOrderLifecycle.actions.createOrder": string;
            "dineInOrderLifecycle.actions.addOrderItem": string;
            "dineInOrderLifecycle.actions.createKitchenTicket": string;
            "dineInOrderLifecycle.actions.updateOrderStatus": string;
            "dineInOrderLifecycle.actions.updateTableStatus": string;
        };
        dataBindings: {
            id: string;
            source: string;
            command: string;
            description: string;
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "dineInOrderLifecycle__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/dineInOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/dineInOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/dineInOrderLifecycle.ts", "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/generateShiftCloseReport.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "generateShiftCloseReport__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/generateShiftCloseReport.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/generateShiftCloseReport.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/generateShiftCloseReport.ts", "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/kitchenProductionFlow.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "kitchenProductionFlow__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/kitchenProductionFlow.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/kitchenProductionFlow.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/kitchenProductionFlow.ts", "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/manageInventoryItems.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: string[];
                rulesApplied: string[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "manageInventoryItems__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageInventoryItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageInventoryItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/manageInventoryItems.ts", "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuCategories.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: any[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "manageMenuCategories__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuCategories.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuCategories.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/manageMenuCategories.ts", "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuItems.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: string[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "manageMenuItems__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/manageMenuItems.ts", "_102050_/l2/cafeFlow/web/contracts/manageMenuItems.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/manageTables.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: string[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "manageTables__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageTables.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageTables.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/manageTables.ts", "_102050_/l2/cafeFlow/web/contracts/manageTables.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/openDailyShift.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: string[];
                rulesApplied: string[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "openDailyShift__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/openDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/openDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/openDailyShift.ts", "_102050_/l2/cafeFlow/web/contracts/openDailyShift.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/recordPayment.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: string[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "recordPayment__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/recordPayment.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/recordPayment.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/recordPayment.ts", "_102050_/l2/cafeFlow/web/contracts/recordPayment.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/takeoutOrderLifecycle.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "takeoutOrderLifecycle__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/takeoutOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/takeoutOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/takeoutOrderLifecycle.ts", "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/viewOperationalDashboard.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: string[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "viewOperationalDashboard__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/viewOperationalDashboard.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/viewOperationalDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/viewOperationalDashboard.ts", "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/aiPromotionSuggestions.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: any[];
            readsTables: any[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        }[];
        navigationRefs: any[];
    };
    export const pipeline: readonly [{
        readonly id: "aiPromotionSuggestions__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/aiPromotionSuggestions.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/aiPromotionSuggestions.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "ingredientConsumptionTrigger"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/aiSalesSummary.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: any[];
            readsTables: any[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        }[];
        navigationRefs: any[];
    };
    export const pipeline: readonly [{
        readonly id: "aiSalesSummary__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/aiSalesSummary.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/aiSalesSummary.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["aiOutputLanguageSelection", "orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "tableOccupancyConsistency"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/browseMenuForPos.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: any[];
            readsTables: any[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        }[];
        navigationRefs: any[];
    };
    export const pipeline: readonly [{
        readonly id: "browseMenuForPos__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/browseMenuForPos.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/browseMenuForPos.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/closeDailyShift.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: string[];
            readsTables: any[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        }[];
        navigationRefs: any[];
    };
    export const pipeline: readonly [{
        readonly id: "closeDailyShift__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/closeDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/closeDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/closeDailyShift.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/consumeIngredientsOnConfirmation.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: string[];
            readsTables: any[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        }[];
        navigationRefs: any[];
    };
    export const pipeline: readonly [{
        readonly id: "consumeIngredientsOnConfirmation__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/consumeIngredientsOnConfirmation.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/consumeIngredientsOnConfirmation.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["ingredientConsumptionTrigger"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/dineInOrderLifecycle.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: string[];
            readsTables: any[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        }[];
        navigationRefs: any[];
    };
    export const pipeline: readonly [{
        readonly id: "dineInOrderLifecycle__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/dineInOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/dineInOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "aiOutputLanguageSelection", "tableOccupancyConsistency"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/generateShiftCloseReport.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: any[];
            readsTables: any[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        }[];
        navigationRefs: any[];
    };
    export const pipeline: readonly [{
        readonly id: "generateShiftCloseReport__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/generateShiftCloseReport.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/generateShiftCloseReport.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/kitchenProductionFlow.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: string[];
            readsTables: any[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        }[];
        navigationRefs: any[];
    };
    export const pipeline: readonly [{
        readonly id: "kitchenProductionFlow__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/kitchenProductionFlow.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/kitchenProductionFlow.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "ingredientConsumptionTrigger"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/manageInventoryItems.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: string[];
            readsTables: any[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        }[];
        navigationRefs: any[];
    };
    export const pipeline: readonly [{
        readonly id: "manageInventoryItems__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/manageInventoryItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/manageInventoryItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["inventoryLowStockThreshold", "ingredientConsumptionTrigger"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/manageMenuCategories.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: string[];
            readsTables: any[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: any[];
        }[];
        navigationRefs: any[];
    };
    export const pipeline: readonly [{
        readonly id: "manageMenuCategories__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/manageMenuCategories.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/manageMenuCategories.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/manageMenuItems.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: string[];
            readsTables: any[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        }[];
        navigationRefs: any[];
    };
    export const pipeline: readonly [{
        readonly id: "manageMenuItems__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/manageMenuItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/manageMenuItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/manageMenuItems.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/manageTables.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: string[];
            readsTables: any[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        }[];
        navigationRefs: any[];
    };
    export const pipeline: readonly [{
        readonly id: "manageTables__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/manageTables.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/manageTables.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/manageTables.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["tableOccupancyConsistency"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/openDailyShift.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: string[];
            readsTables: any[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        }[];
        navigationRefs: any[];
    };
    export const pipeline: readonly [{
        readonly id: "openDailyShift__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/openDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/openDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/openDailyShift.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/recordPayment.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: string[];
            readsTables: any[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        }[];
        navigationRefs: any[];
    };
    export const pipeline: readonly [{
        readonly id: "recordPayment__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/recordPayment.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/recordPayment.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/recordPayment.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/takeoutOrderLifecycle.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: string[];
            readsTables: any[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        }[];
        navigationRefs: any[];
    };
    export const pipeline: readonly [{
        readonly id: "takeoutOrderLifecycle__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/takeoutOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/takeoutOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "aiOutputLanguageSelection", "tableOccupancyConsistency"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/viewOperationalDashboard.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: any[];
            readsTables: any[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        }[];
        navigationRefs: any[];
    };
    export const pipeline: readonly [{
        readonly id: "viewOperationalDashboard__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/viewOperationalDashboard.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/viewOperationalDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
