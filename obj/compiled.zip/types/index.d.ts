declare module "_102050_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: any[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "aiPromotionSuggestions__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: any[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "aiSalesSummary__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: any[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "browseMenuForPos__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "closeDailyShift__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "consumeIngredientsOnConfirmation__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "dineInOrderLifecycle__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: any[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "generateShiftCloseReport__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "kitchenProductionFlow__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "manageInventoryItems__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: any[];
    }[];
    export const pipeline: readonly [{
        readonly id: "manageMenuCategories__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageMenuItems.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "manageMenuItems__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/manageMenuItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/manageMenuItems.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageTables.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "manageTables__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/manageTables.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/manageTables.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/openDailyShift.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "openDailyShift__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/openDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/openDailyShift.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/recordPayment.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "recordPayment__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/recordPayment.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/recordPayment.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "takeoutOrderLifecycle__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: any[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "viewOperationalDashboard__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/aiPromotionSuggestions.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: any[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "aiPromotionSuggestions__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/aiPromotionSuggestions.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/aiPromotionSuggestions.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/aiPromotionSuggestions.ts", "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/aiSalesSummary.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "aiSalesSummary__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/aiSalesSummary.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/aiSalesSummary.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/aiSalesSummary.ts", "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/browseMenuForPos.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: string[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "browseMenuForPos__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/browseMenuForPos.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/browseMenuForPos.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/browseMenuForPos.ts", "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/closeDailyShift.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: any[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "closeDailyShift__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/closeDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/closeDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/closeDailyShift.ts", "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/consumeIngredientsOnConfirmation.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: string[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "consumeIngredientsOnConfirmation__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/consumeIngredientsOnConfirmation.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/consumeIngredientsOnConfirmation.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/consumeIngredientsOnConfirmation.ts", "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/dineInOrderLifecycle.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "dineInOrderLifecycle__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/dineInOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/dineInOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/dineInOrderLifecycle.ts", "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/generateShiftCloseReport.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "generateShiftCloseReport__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/generateShiftCloseReport.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/generateShiftCloseReport.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/generateShiftCloseReport.ts", "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/kitchenProductionFlow.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "kitchenProductionFlow__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/kitchenProductionFlow.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/kitchenProductionFlow.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/kitchenProductionFlow.ts", "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/manageInventoryItems.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: string[];
                rulesApplied: string[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "manageInventoryItems__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageInventoryItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageInventoryItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/manageInventoryItems.ts", "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuCategories.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: any[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "manageMenuCategories__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuCategories.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuCategories.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/manageMenuCategories.ts", "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuItems.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: string[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "manageMenuItems__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/manageMenuItems.ts", "_102050_/l2/cafeFlow/web/contracts/manageMenuItems.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/manageTables.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: string[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "manageTables__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageTables.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageTables.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/manageTables.ts", "_102050_/l2/cafeFlow/web/contracts/manageTables.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/openDailyShift.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: string[];
                rulesApplied: string[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "openDailyShift__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/openDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/openDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/openDailyShift.ts", "_102050_/l2/cafeFlow/web/contracts/openDailyShift.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/recordPayment.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: string[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "recordPayment__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/recordPayment.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/recordPayment.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/recordPayment.ts", "_102050_/l2/cafeFlow/web/contracts/recordPayment.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/takeoutOrderLifecycle.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "takeoutOrderLifecycle__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/takeoutOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/takeoutOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/takeoutOrderLifecycle.ts", "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/viewOperationalDashboard.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: string[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "viewOperationalDashboard__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/viewOperationalDashboard.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/viewOperationalDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/viewOperationalDashboard.ts", "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/aiPromotionSuggestions.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: any[];
            readsTables: any[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        }[];
        navigationRefs: any[];
    };
    export const pipeline: readonly [{
        readonly id: "aiPromotionSuggestions__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/aiPromotionSuggestions.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/aiPromotionSuggestions.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "ingredientConsumptionTrigger"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/aiSalesSummary.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: any[];
            readsTables: any[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        }[];
        navigationRefs: any[];
    };
    export const pipeline: readonly [{
        readonly id: "aiSalesSummary__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/aiSalesSummary.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/aiSalesSummary.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["aiOutputLanguageSelection", "orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "tableOccupancyConsistency"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/browseMenuForPos.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: any[];
            readsTables: any[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        }[];
        navigationRefs: any[];
    };
    export const pipeline: readonly [{
        readonly id: "browseMenuForPos__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/browseMenuForPos.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/browseMenuForPos.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/closeDailyShift.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: string[];
            readsTables: any[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        }[];
        navigationRefs: any[];
    };
    export const pipeline: readonly [{
        readonly id: "closeDailyShift__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/closeDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/closeDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/closeDailyShift.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/consumeIngredientsOnConfirmation.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: string[];
            readsTables: any[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        }[];
        navigationRefs: any[];
    };
    export const pipeline: readonly [{
        readonly id: "consumeIngredientsOnConfirmation__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/consumeIngredientsOnConfirmation.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/consumeIngredientsOnConfirmation.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["ingredientConsumptionTrigger"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/dineInOrderLifecycle.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: string[];
            readsTables: any[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        }[];
        navigationRefs: any[];
    };
    export const pipeline: readonly [{
        readonly id: "dineInOrderLifecycle__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/dineInOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/dineInOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "aiOutputLanguageSelection", "tableOccupancyConsistency"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/generateShiftCloseReport.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: any[];
            readsTables: any[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        }[];
        navigationRefs: any[];
    };
    export const pipeline: readonly [{
        readonly id: "generateShiftCloseReport__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/generateShiftCloseReport.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/generateShiftCloseReport.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/kitchenProductionFlow.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: string[];
            readsTables: any[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        }[];
        navigationRefs: any[];
    };
    export const pipeline: readonly [{
        readonly id: "kitchenProductionFlow__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/kitchenProductionFlow.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/kitchenProductionFlow.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "ingredientConsumptionTrigger"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/manageInventoryItems.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: string[];
            readsTables: any[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        }[];
        navigationRefs: any[];
    };
    export const pipeline: readonly [{
        readonly id: "manageInventoryItems__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/manageInventoryItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/manageInventoryItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["inventoryLowStockThreshold", "ingredientConsumptionTrigger"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/manageMenuCategories.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: string[];
            readsTables: any[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: any[];
        }[];
        navigationRefs: any[];
    };
    export const pipeline: readonly [{
        readonly id: "manageMenuCategories__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/manageMenuCategories.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/manageMenuCategories.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/manageMenuItems.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: string[];
            readsTables: any[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        }[];
        navigationRefs: any[];
    };
    export const pipeline: readonly [{
        readonly id: "manageMenuItems__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/manageMenuItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/manageMenuItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/manageMenuItems.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/manageTables.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: string[];
            readsTables: any[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        }[];
        navigationRefs: any[];
    };
    export const pipeline: readonly [{
        readonly id: "manageTables__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/manageTables.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/manageTables.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/manageTables.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["tableOccupancyConsistency"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/openDailyShift.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: string[];
            readsTables: any[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        }[];
        navigationRefs: any[];
    };
    export const pipeline: readonly [{
        readonly id: "openDailyShift__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/openDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/openDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/openDailyShift.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/recordPayment.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: string[];
            readsTables: any[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        }[];
        navigationRefs: any[];
    };
    export const pipeline: readonly [{
        readonly id: "recordPayment__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/recordPayment.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/recordPayment.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/recordPayment.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/takeoutOrderLifecycle.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: string[];
            readsTables: any[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        }[];
        navigationRefs: any[];
    };
    export const pipeline: readonly [{
        readonly id: "takeoutOrderLifecycle__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/takeoutOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/takeoutOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "aiOutputLanguageSelection", "tableOccupancyConsistency"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/viewOperationalDashboard.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: any[];
            readsTables: any[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        }[];
        navigationRefs: any[];
    };
    export const pipeline: readonly [{
        readonly id: "viewOperationalDashboard__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/viewOperationalDashboard.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/viewOperationalDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
