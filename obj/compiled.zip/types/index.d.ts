declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShiftRepositoryAdapter.defs" {
    export const dailyShiftRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "DailyShiftRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "DailyShiftRepositoryAdapter";
            readonly entityId: "DailyShift";
            readonly portRef: "IDailyShiftRepository";
            readonly tableRef: "daily_shifts";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Real columns: daily_shift_id, status, created_at", "Details JSONB holds shiftDate, openedAt, closedAt, openingCashBalance, closingCashBalance, totalSales, totalPayments, closingNotes, updatedAt, cashMovements (embedded)"];
        };
    };
    export default dailyShiftRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "dailyShiftRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShiftRepositoryAdapter.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShiftRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShift.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShiftRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IDailyShiftRepository } from '_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository';
    export function createDailyShiftRepositoryAdapter(ctx: RequestContext): IDailyShiftRepository;
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItemRepositoryAdapter.defs" {
    export const inventoryItemRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "InventoryItemRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "InventoryItemRepositoryAdapter";
            readonly entityId: "InventoryItem";
            readonly portRef: "IInventoryItemRepository";
            readonly tableRef: "inventory_items";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Real columns: inventory_item_id, status, created_at", "Details JSONB holds name, description, unit, current_quantity, minimum_level, updated_at"];
        };
    };
    export default inventoryItemRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "inventoryItemRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItemRepositoryAdapter.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItemRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItem.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItemRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IInventoryItemRepository } from '_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository';
    export function createInventoryItemRepositoryAdapter(ctx: RequestContext): IInventoryItemRepository;
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemRepositoryAdapter.defs" {
    export const menuItemRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "MenuItemRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "MenuItemRepositoryAdapter";
            readonly entityId: "MenuItem";
            readonly portRef: "IMenuItemRepository";
            readonly tableRef: "menu_items";
            readonly mdmReads: readonly ["MenuCategory"];
            readonly notes: readonly ["Real columns: menu_item_id, menu_category_id, status, created_at", "Details JSONB holds name, description, price, updated_at, recipeComponents (embedded)", "Resolves MenuCategory via ctx.data.mdm(102034) — no local MDM table"];
        };
    };
    export default menuItemRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "menuItemRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemRepositoryAdapter.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItem.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IMenuItemRepository } from '_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository';
    export function createMenuItemRepositoryAdapter(ctx: RequestContext): IMenuItemRepository;
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter.defs" {
    export const orderRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "OrderRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "OrderRepositoryAdapter";
            readonly entityId: "Order";
            readonly portRef: "IOrderRepository";
            readonly tableRef: "orders";
            readonly mdmReads: readonly ["Table"];
            readonly notes: readonly ["Real columns: order_id, daily_shift_id, table_id, kitchen_ticket_id, order_type, status, created_at", "Details JSONB holds totalAmount, notes, customerName, customerPhone, numberOfGuests, closedAt, cancelledAt, cancellationReason, updatedAt, orderItems (embedded), kitchenTickets (embedded)", "Resolves Table via ctx.data.mdm(102034) — no local MDM table"];
        };
    };
    export default orderRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "orderRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IOrderRepository } from '_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository';
    export function createOrderRepositoryAdapter(ctx: RequestContext): IOrderRepository;
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/paymentRepositoryAdapter.defs" {
    export const paymentRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "PaymentRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "PaymentRepositoryAdapter";
            readonly entityId: "Payment";
            readonly portRef: "IPaymentRepository";
            readonly tableRef: "payments";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Real columns: payment_id, order_id, daily_shift_id, status, created_at", "Details JSONB holds method, amount, updatedAt"];
        };
    };
    export default paymentRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "paymentRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/paymentRepositoryAdapter.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/paymentRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.d.ts", "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/payment.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/paymentRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IPaymentRepository } from '_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository';
    export function createPaymentRepositoryAdapter(ctx: RequestContext): IPaymentRepository;
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/addOrderItem.defs" {
    export const addOrderItemUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "addOrderItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "addOrderItem";
            readonly ports: readonly ["Order", "MenuItem"];
            readonly functions: readonly [{
                readonly functionName: "addOrderItem";
                readonly inputTypeName: "AddOrderItemInput";
                readonly outputTypeName: "AddOrderItemOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "ID of the parent Order to which the item will be added";
                }, {
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "ID of the MenuItem to add to the order";
                }, {
                    readonly name: "quantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "OrderItem";
                    readonly description: "Quantity of the menu item ordered";
                }, {
                    readonly name: "observations";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "OrderItem";
                    readonly description: "Optional preparation notes or customer requests";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "ID of the parent Order";
                }, {
                    readonly name: "orderItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "OrderItem";
                    readonly description: "ID of the newly created OrderItem";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "OrderItem";
                    readonly description: "Initial status of the order item (new)";
                }];
                readonly ports: readonly ["Order", "MenuItem"];
                readonly rulesApplied: readonly ["orderStatusTransitions", "ingredientConsumptionTrigger"];
                readonly transactional: true;
                readonly steps: readonly ["Load Order by orderId via Order port", "Validate Order status is not closed or cancelled (orderStatusTransitions rule)", "Load MenuItem by menuItemId via MenuItem port", "Validate MenuItem status is active", "Compute unitPrice from MenuItem.price and totalPrice = unitPrice * quantity", "Create new OrderItem with status 'new', computed prices, and provided observations", "Add OrderItem to Order's items collection", "Recalculate Order.totalAmount from all order items", "Apply ingredientConsumptionTrigger: generate StockConsumption entries for the menu item's ingredients", "Save Order (with embedded OrderItem and StockConsumption) via Order port", "Return orderId, orderItemId, and status"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default addOrderItemUsecase;
    export const pipeline: readonly [{
        readonly id: "addOrderItem__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/addOrderItem.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/addOrderItem.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/addOrderItem" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface AddOrderItemInput {
        orderId: string;
        menuItemId: string;
        quantity: number;
        observations?: string;
    }
    export interface AddOrderItemOutput {
        orderId: string;
        orderItemId: string;
        status: string;
    }
    export function addOrderItem(ctx: RequestContext, input: AddOrderItemInput): Promise<AddOrderItemOutput>;
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/aiPromotionSuggestions.defs" {
    export const aiPromotionSuggestionsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "aiPromotionSuggestions";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "aiPromotionSuggestions";
            readonly ports: readonly ["Order", "MenuItem"];
            readonly functions: readonly [{
                readonly functionName: "aiPromotionSuggestions";
                readonly inputTypeName: "AiPromotionSuggestionsInput";
                readonly outputTypeName: "AiPromotionSuggestionsOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "The order to analyze for promotion suggestions";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "The analyzed order id";
                }, {
                    readonly name: "suggestions";
                    readonly type: "array";
                    readonly required: true;
                    readonly description: "List of AI-generated promotion suggestions based on the order items and available menu items";
                    readonly ofEntity: "OrderItem";
                }];
                readonly ports: readonly ["Order", "MenuItem"];
                readonly rulesApplied: readonly [];
                readonly transactional: false;
                readonly steps: readonly ["Load the Order aggregate by orderId via OrderPort (includes embedded OrderItems)", "Collect all menuItemIds from the order items", "Load referenced MenuItems via MenuItemPort to obtain names, prices, categories and status", "Filter MenuItems to only active ones for suggestion candidates", "Analyze current order items: quantities, categories, total amount, and item combinations", "Generate promotion suggestions (upsell, cross-sell, bundle, discount) based on order composition and available active menu items", "Return the orderId and the list of suggestions with suggested menu item, suggestion type, description, suggested price and discount percentage"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default aiPromotionSuggestionsUsecase;
    export const pipeline: readonly [{
        readonly id: "aiPromotionSuggestions__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/aiPromotionSuggestions.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/aiPromotionSuggestions.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/aiPromotionSuggestions" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export type PromotionSuggestionType = 'upsell' | 'crossSell' | 'bundle' | 'discount';
    export interface PromotionSuggestion {
        menuItemId: string;
        menuItemName: string;
        suggestionType: PromotionSuggestionType;
        description: string;
        originalPrice: number;
        suggestedPrice: number;
        discountPercentage: number;
    }
    export interface AiPromotionSuggestionsInput {
        orderId: string;
    }
    export interface AiPromotionSuggestionsOutput {
        orderId: string;
        suggestions: PromotionSuggestion[];
    }
    export function aiPromotionSuggestions(ctx: RequestContext, input: AiPromotionSuggestionsInput): Promise<AiPromotionSuggestionsOutput>;
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/aiSalesSummary.defs" {
    export const aiSalesSummaryUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "aiSalesSummary";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "aiSalesSummary";
            readonly ports: readonly ["Order", "DailyShift", "MenuItem"];
            readonly functions: readonly [{
                readonly functionName: "aiSalesSummary";
                readonly inputTypeName: "AiSalesSummaryInput";
                readonly outputTypeName: "AiSalesSummaryOutput";
                readonly input: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Filter summary to a specific daily shift";
                }, {
                    readonly name: "startDate";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Start date for the summary period (ISO date)";
                }, {
                    readonly name: "endDate";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "End date for the summary period (ISO date)";
                }, {
                    readonly name: "language";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Preferred output language for the AI-generated summary text (e.g. pt-BR, en-US)";
                }];
                readonly output: readonly [{
                    readonly name: "totalSales";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Sum of totalAmount across all closed orders in the period";
                }, {
                    readonly name: "totalOrders";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Count of orders included in the summary";
                }, {
                    readonly name: "totalCancelledOrders";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Count of cancelled orders in the period";
                }, {
                    readonly name: "averageOrderValue";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Average totalAmount per closed order";
                }, {
                    readonly name: "topSellingItems";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "JSON string listing top-selling menu items by quantity and revenue";
                }, {
                    readonly name: "salesByOrderType";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "JSON string with sales breakdown by order type (mesa vs takeout)";
                }, {
                    readonly name: "summaryText";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "AI-generated natural-language sales summary in the selected language";
                }, {
                    readonly name: "language";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "The language used for the AI summary text";
                }];
                readonly ports: readonly ["Order", "DailyShift", "MenuItem"];
                readonly rulesApplied: readonly ["aiOutputLanguageSelection"];
                readonly transactional: false;
                readonly steps: readonly ["1. Resolve the target period: if dailyShiftId is provided, load the DailyShift via DailyShiftPort to obtain shiftDate; otherwise use startDate/endDate (defaulting to today if both absent).", "2. Query all Order aggregates within the period via OrderPort, including embedded OrderItem children.", "3. Separate closed orders (status=closed) from cancelled orders (status=cancelled) for metric computation.", "4. Compute totalSales (sum of totalAmount on closed orders), totalOrders, totalCancelledOrders, and averageOrderValue.", "5. Aggregate OrderItem quantities grouped by menuItemId; load MenuItem names via MenuItemPort to build topSellingItems ranking.", "6. Break down sales by orderType (mesa vs takeout) into salesByOrderType.", "7. Apply rule aiOutputLanguageSelection: determine the output language from the language input field (default to pt-BR if not provided), and generate summaryText in that language.", "8. Return the assembled AiSalesSummaryOutput."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default aiSalesSummaryUsecase;
    export const pipeline: readonly [{
        readonly id: "aiSalesSummary__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/aiSalesSummary.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/aiSalesSummary.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/aiSalesSummary" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface AiSalesSummaryInput {
        dailyShiftId?: string;
        startDate?: string;
        endDate?: string;
        language?: string;
    }
    export interface AiSalesSummaryOutput {
        totalSales: number;
        totalOrders: number;
        totalCancelledOrders: number;
        averageOrderValue: number;
        topSellingItems: string;
        salesByOrderType: string;
        summaryText: string;
        language: string;
    }
    export function aiSalesSummary(ctx: RequestContext, input: AiSalesSummaryInput): Promise<AiSalesSummaryOutput>;
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/browseMenuForPos.defs" {
    export const browseMenuForPosUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "browseMenuForPos";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "browseMenuForPos";
            readonly ports: readonly ["MenuItem"];
            readonly functions: readonly [{
                readonly functionName: "browseMenuForPos";
                readonly inputTypeName: "BrowseMenuForPosInput";
                readonly outputTypeName: "BrowseMenuForPosOutput";
                readonly input: readonly [{
                    readonly name: "menuCategoryId";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Filter menu items by category id (optional)";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Filter by menu item status (e.g. 'active' for POS display)";
                }];
                readonly output: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "menuCategoryId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "categoryName";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuCategory";
                    readonly description: "Category name resolved from MDM MenuCategory";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                }];
                readonly ports: readonly ["MenuItem"];
                readonly rulesApplied: readonly ["aiOutputLanguageSelection"];
                readonly transactional: false;
                readonly steps: readonly ["1. Query MenuItem entities via MenuItem port, optionally filtered by menuCategoryId and status", "2. Collect distinct menuCategoryIds from the returned items", "3. For each distinct menuCategoryId, resolve MenuCategory from MDM via ctx.data.mdmDocument.get({ mdmId: menuCategoryId }) to obtain the category name", "4. Apply aiOutputLanguageSelection rule to select the appropriate language for display fields (name, description, categoryName)", "5. Return the enriched list of menu items with categoryName included"];
            }];
            readonly mdmRefs: readonly ["MenuCategory"];
        };
    };
    export default browseMenuForPosUsecase;
    export const pipeline: readonly [{
        readonly id: "browseMenuForPos__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/browseMenuForPos.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/browseMenuForPos.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/browseMenuForPos" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface BrowseMenuForPosInput {
        menuCategoryId?: string;
        status?: string;
    }
    export interface BrowseMenuForPosItem {
        menuItemId: string;
        menuCategoryId: string;
        categoryName: string;
        name: string;
        description?: string | null;
        price: number;
        status: string;
    }
    export interface BrowseMenuForPosOutput {
        items: BrowseMenuForPosItem[];
    }
    export function browseMenuForPos(ctx: RequestContext, input: BrowseMenuForPosInput): Promise<BrowseMenuForPosOutput>;
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/closeDailyShift.defs" {
    export const closeDailyShiftUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "closeDailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "closeDailyShift";
            readonly ports: readonly ["DailyShift"];
            readonly functions: readonly [{
                readonly functionName: "closeDailyShift";
                readonly inputTypeName: "CloseDailyShiftInput";
                readonly outputTypeName: "CloseDailyShiftOutput";
                readonly input: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "closingNotes";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "DailyShift";
                }];
                readonly output: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "closedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "openingCashBalance";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "closingCashBalance";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "totalSales";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "totalPayments";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "closingNotes";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "DailyShift";
                }];
                readonly ports: readonly ["DailyShift"];
                readonly rulesApplied: readonly ["SHIFT_MUST_BE_OPEN", "CLOSING_BALANCE_CALCULATED_FROM_CASH_MOVEMENTS", "CLOSED_AT_SET_TO_CURRENT_TIMESTAMP"];
                readonly transactional: true;
                readonly steps: readonly ["Load DailyShift by dailyShiftId via DailyShiftPort.findById", "Validate shift.status === 'open' (SHIFT_MUST_BE_OPEN)", "Load all CashMovements embedded in the DailyShift aggregate for dailyShiftId", "Calculate totalCashIn = sum of CashMovement.amount where movementType === 'entrada'", "Calculate totalCashOut = sum of CashMovement.amount where movementType === 'saída'", "Calculate closingCashBalance = openingCashBalance + totalCashIn - totalCashOut (CLOSING_BALANCE_CALCULATED_FROM_CASH_MOVEMENTS)", "Set shift.status = 'closed'", "Set shift.closedAt = current timestamp (CLOSED_AT_SET_TO_CURRENT_TIMESTAMP)", "Set shift.closingCashBalance = calculated value", "Set shift.closingNotes = provided closingNotes if present", "Save DailyShift via DailyShiftPort.save", "Return updated shift summary"];
            }, {
                readonly functionName: "previewDailyShiftClosure";
                readonly inputTypeName: "PreviewDailyShiftClosureInput";
                readonly outputTypeName: "PreviewDailyShiftClosureOutput";
                readonly input: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }];
                readonly output: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "shiftDate";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "openingCashBalance";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "totalCashIn";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "CashMovement";
                }, {
                    readonly name: "totalCashOut";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "CashMovement";
                }, {
                    readonly name: "projectedClosingBalance";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "totalSales";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "totalPayments";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }];
                readonly ports: readonly ["DailyShift"];
                readonly rulesApplied: readonly ["SHIFT_MUST_BE_OPEN", "CLOSING_BALANCE_CALCULATED_FROM_CASH_MOVEMENTS"];
                readonly transactional: false;
                readonly steps: readonly ["Load DailyShift by dailyShiftId via DailyShiftPort.findById", "Validate shift.status === 'open' (SHIFT_MUST_BE_OPEN)", "Load all CashMovements embedded in the DailyShift aggregate for dailyShiftId", "Calculate totalCashIn = sum of CashMovement.amount where movementType === 'entrada'", "Calculate totalCashOut = sum of CashMovement.amount where movementType === 'saída'", "Calculate projectedClosingBalance = openingCashBalance + totalCashIn - totalCashOut (CLOSING_BALANCE_CALCULATED_FROM_CASH_MOVEMENTS)", "Return preview summary without mutating the shift"];
            }];
            readonly rulesApplied: readonly ["SHIFT_MUST_BE_OPEN", "CLOSING_BALANCE_CALCULATED_FROM_CASH_MOVEMENTS", "CLOSED_AT_SET_TO_CURRENT_TIMESTAMP"];
            readonly mdmRefs: readonly [];
        };
    };
    export default closeDailyShiftUsecase;
    export const pipeline: readonly [{
        readonly id: "closeDailyShift__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/closeDailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/closeDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["SHIFT_MUST_BE_OPEN", "CLOSING_BALANCE_CALCULATED_FROM_CASH_MOVEMENTS", "CLOSED_AT_SET_TO_CURRENT_TIMESTAMP"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/closeDailyShift" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CloseDailyShiftInput {
        dailyShiftId: string;
        closingNotes?: string;
    }
    export interface CloseDailyShiftOutput {
        dailyShiftId: string;
        status: string;
        closedAt: string;
        openingCashBalance: number;
        closingCashBalance: number;
        totalSales: number;
        totalPayments: number;
        closingNotes?: string;
    }
    export interface PreviewDailyShiftClosureInput {
        dailyShiftId: string;
    }
    export interface PreviewDailyShiftClosureOutput {
        dailyShiftId: string;
        shiftDate: string;
        status: string;
        openingCashBalance: number;
        totalCashIn: number;
        totalCashOut: number;
        projectedClosingBalance: number;
        totalSales: number;
        totalPayments: number;
    }
    export function closeDailyShift(ctx: RequestContext, input: CloseDailyShiftInput): Promise<CloseDailyShiftOutput>;
    export function previewDailyShiftClosure(ctx: RequestContext, input: PreviewDailyShiftClosureInput): Promise<PreviewDailyShiftClosureOutput>;
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/createOrder.defs" {
    export const createOrderUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createOrder";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createOrder";
            readonly ports: readonly ["Order", "DailyShift"];
            readonly functions: readonly [{
                readonly functionName: "createOrder";
                readonly inputTypeName: "CreateOrderInput";
                readonly outputTypeName: "CreateOrderOutput";
                readonly input: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                    readonly description: "The open daily shift under which the order is created";
                }, {
                    readonly name: "tableId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Table";
                    readonly description: "Required when orderType is 'mesa'; references the Table master-data document";
                }, {
                    readonly name: "orderType";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Order type: 'mesa' (dine-in) or 'takeout'";
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Free-text notes for the order";
                }, {
                    readonly name: "customerName";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Customer name (optional, used mainly for takeout)";
                }, {
                    readonly name: "customerPhone";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Customer phone (optional, used mainly for takeout)";
                }, {
                    readonly name: "numberOfGuests";
                    readonly type: "number";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Number of guests at the table (optional, used mainly for mesa)";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "The newly created order identifier";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Initial status of the order, always 'draft' on creation";
                }, {
                    readonly name: "totalAmount";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Initial total amount, always 0 on creation";
                }, {
                    readonly name: "tableStatus";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Table";
                    readonly description: "Updated table status ('occupied') when orderType is 'mesa'";
                }];
                readonly ports: readonly ["Order", "DailyShift"];
                readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "aiOutputLanguageSelection", "tableOccupancyConsistency"];
                readonly transactional: true;
                readonly steps: readonly ["1. Load DailyShift via DailyShift port by dailyShiftId; validate that shift status is 'open' — reject if closed or not found.", "2. If orderType is 'mesa': require tableId (reject if missing); read Table master-data document via ctx.data.mdmDocument.get({ mdmId: tableId }); validate table status is 'available' (tableOccupancyConsistency) — reject if 'occupied' or 'disabled'.", "3. If orderType is 'takeout': tableId must be null; skip table validation.", "4. Create new Order aggregate with status='draft' (orderStatusTransitions initial state), totalAmount=0, kitchenTicketId=null, closedAt=null, cancelledAt=null; set createdAt/updatedAt to server timestamp.", "5. Apply paymentTimingByOrderType: for 'takeout' payment is expected immediately; for 'mesa' payment is deferred until close — store this expectation as order metadata.", "6. Apply aiOutputLanguageSelection: determine the language for AI-generated kitchen ticket output based on shift or tenant configuration.", "7. ingredientConsumptionTrigger is registered but not fired on create — it fires when status transitions to 'sentToKitchen'.", "8. Save Order via Order port.", "9. If orderType is 'mesa': update Table master-data document status to 'occupied' (tableOccupancyConsistency) and persist via ctx.data.mdmDocument update.", "10. Return orderId, status, totalAmount, and tableStatus (if applicable)."];
            }];
            readonly mdmRefs: readonly ["Table"];
        };
    };
    export default createOrderUsecase;
    export const pipeline: readonly [{
        readonly id: "createOrder__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createOrder.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createOrder.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/createOrder" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CreateOrderInput {
        dailyShiftId: string;
        tableId?: string;
        orderType: string;
        notes?: string;
        customerName?: string;
        customerPhone?: string;
        numberOfGuests?: number;
    }
    export interface CreateOrderOutput {
        orderId: string;
        status: string;
        totalAmount: number;
        tableStatus?: string;
    }
    export function createOrder(ctx: RequestContext, input: CreateOrderInput): Promise<CreateOrderOutput>;
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/createStockConsumption.defs" {
    export const createStockConsumptionUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createStockConsumption";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createStockConsumption";
            readonly ports: readonly ["Order", "MenuItem", "InventoryItem"];
            readonly functions: readonly [{
                readonly functionName: "createStockConsumption";
                readonly inputTypeName: "CreateStockConsumptionInput";
                readonly outputTypeName: "CreateStockConsumptionOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "The order containing the item that triggered stock consumption";
                }, {
                    readonly name: "orderItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "OrderItem";
                    readonly description: "The order item whose menu item recipe components will be consumed";
                }];
                readonly output: readonly [{
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Overall result status: 'posted' when all consumption records are created successfully";
                }, {
                    readonly name: "stockConsumptionCount";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Number of StockConsumption records created (one per recipe component)";
                }, {
                    readonly name: "inventoryItemIds";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "InventoryItem";
                    readonly description: "Comma-separated list of InventoryItem ids whose stock was decremented";
                }];
                readonly ports: readonly ["Order", "MenuItem", "InventoryItem"];
                readonly rulesApplied: readonly ["ingredientConsumptionTrigger"];
                readonly transactional: true;
                readonly steps: readonly ["1. Load Order by orderId via Order port; validate order exists and status is not 'cancelled'", "2. Find the OrderItem by orderItemId within the Order's items collection; validate it exists and status is 'served' or 'ready'", "3. Load MenuItem by orderItem.menuItemId via MenuItem port; validate menuItem status is 'active'", "4. Retrieve RecipeComponents from the MenuItem aggregate (each has inventoryItemId and quantity per unit)", "5. For each RecipeComponent calculate consumedQuantity = recipeComponent.quantity * orderItem.quantity", "6. Load InventoryItem by recipeComponent.inventoryItemId via InventoryItem port; validate status is 'active' and currentQuantity >= consumedQuantity", "7. Decrement InventoryItem.currentQuantity by consumedQuantity; save InventoryItem via InventoryItem port", "8. Create StockConsumption record: inventoryItemId, orderItemId, quantity=consumedQuantity, status='posted', consumedAt=now; save via StockConsumption port", "9. Repeat steps 6-8 for every recipe component", "10. Return status='posted', stockConsumptionCount, and affected inventoryItemIds"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default createStockConsumptionUsecase;
    export const pipeline: readonly [{
        readonly id: "createStockConsumption__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createStockConsumption.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createStockConsumption.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/createStockConsumption" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CreateStockConsumptionInput {
        orderId: string;
        orderItemId: string;
    }
    export interface CreateStockConsumptionOutput {
        status: string;
        stockConsumptionCount: number;
        inventoryItemIds: string;
    }
    export function createStockConsumption(ctx: RequestContext, input: CreateStockConsumptionInput): Promise<CreateStockConsumptionOutput>;
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/dineInOrderLifecycle.defs" {
    export const dineInOrderLifecycleUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "dineInOrderLifecycle";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "dineInOrderLifecycle";
            readonly ports: readonly ["Order"];
            readonly functions: readonly [{
                readonly functionName: "sendToKitchen";
                readonly inputTypeName: "SendToKitchenInput";
                readonly outputTypeName: "SendToKitchenOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "tableId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Table";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "kitchenTicketId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "KitchenTicket";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }];
                readonly ports: readonly ["Order"];
                readonly rulesApplied: readonly ["order-status-transition-draft-to-sentToKitchen", "kitchen-ticket-created-on-send", "order-items-status-synced-on-send", "table-marked-occupied-on-send"];
                readonly transactional: true;
                readonly steps: readonly ["Load Order aggregate by orderId via Order port", "Validate order.status === 'draft'", "Validate order.orderType === 'mesa' and tableId is present for dine-in", "Read Table master data via ctx.data.mdmDocument.get({ mdmId: tableId }) and validate table.status === 'available'", "Create KitchenTicket embedded in Order aggregate with status 'open'", "Set order.kitchenTicketId to new ticket id", "Set order.status to 'sentToKitchen'", "Set all OrderItem.status to 'sentToKitchen' and link each to kitchenTicketId", "Update Table master data status to 'occupied' via ctx.data.mdmDocument", "Save Order aggregate via Order port"];
            }, {
                readonly functionName: "markOrderReady";
                readonly inputTypeName: "MarkOrderReadyInput";
                readonly outputTypeName: "MarkOrderReadyOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "kitchenTicketStatus";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "KitchenTicket";
                }];
                readonly ports: readonly ["Order"];
                readonly rulesApplied: readonly ["order-status-transition-sentToKitchen-or-inPreparation-to-ready", "kitchen-ticket-status-to-done", "order-items-status-synced-to-ready"];
                readonly transactional: true;
                readonly steps: readonly ["Load Order aggregate by orderId via Order port", "Validate order.status is 'sentToKitchen' or 'inPreparation'", "Set KitchenTicket.status to 'done'", "Set order.status to 'ready'", "Set all OrderItem.status to 'ready'", "Save Order aggregate via Order port"];
            }, {
                readonly functionName: "serveOrder";
                readonly inputTypeName: "ServeOrderInput";
                readonly outputTypeName: "ServeOrderOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }];
                readonly ports: readonly ["Order"];
                readonly rulesApplied: readonly ["order-status-transition-ready-to-served", "order-items-status-synced-to-served"];
                readonly transactional: true;
                readonly steps: readonly ["Load Order aggregate by orderId via Order port", "Validate order.status === 'ready'", "Set order.status to 'served'", "Set all OrderItem.status to 'served'", "Save Order aggregate via Order port"];
            }, {
                readonly functionName: "closeOrder";
                readonly inputTypeName: "CloseOrderInput";
                readonly outputTypeName: "CloseOrderOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "tableId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Table";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "closedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }];
                readonly ports: readonly ["Order"];
                readonly rulesApplied: readonly ["order-status-transition-served-to-closed", "table-freed-on-close", "closedAt-set-on-close"];
                readonly transactional: true;
                readonly steps: readonly ["Load Order aggregate by orderId via Order port", "Validate order.status === 'served'", "Set order.status to 'closed'", "Set order.closedAt to current datetime", "If order.orderType === 'mesa' and tableId present, update Table master data status to 'available' via ctx.data.mdmDocument", "Save Order aggregate via Order port"];
            }, {
                readonly functionName: "cancelOrder";
                readonly inputTypeName: "CancelOrderInput";
                readonly outputTypeName: "CancelOrderOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "cancellationReason";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "tableId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Table";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "cancelledAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }];
                readonly ports: readonly ["Order"];
                readonly rulesApplied: readonly ["order-cancel-not-allowed-if-closed-or-cancelled", "kitchen-ticket-voided-on-cancel", "order-items-cancelled-on-cancel", "table-freed-on-cancel"];
                readonly transactional: true;
                readonly steps: readonly ["Load Order aggregate by orderId via Order port", "Validate order.status is not 'closed' and not 'cancelled'", "Set order.status to 'cancelled'", "Set order.cancelledAt to current datetime", "Set order.cancellationReason if provided", "If KitchenTicket exists, set KitchenTicket.status to 'void'", "Set all OrderItem.status to 'cancelled'", "If order.orderType === 'mesa' and tableId present, update Table master data status to 'available' via ctx.data.mdmDocument", "Save Order aggregate via Order port"];
            }];
            readonly mdmRefs: readonly ["Table"];
        };
    };
    export default dineInOrderLifecycleUsecase;
    export const pipeline: readonly [{
        readonly id: "dineInOrderLifecycle__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/dineInOrderLifecycle.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/dineInOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/dineInOrderLifecycle" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface SendToKitchenInput {
        orderId: string;
        tableId?: string;
    }
    export interface SendToKitchenOutput {
        orderId: string;
        kitchenTicketId: string;
        status: string;
    }
    export function sendToKitchen(ctx: RequestContext, input: SendToKitchenInput): Promise<SendToKitchenOutput>;
    export interface MarkOrderReadyInput {
        orderId: string;
    }
    export interface MarkOrderReadyOutput {
        orderId: string;
        status: string;
        kitchenTicketStatus: string;
    }
    export function markOrderReady(ctx: RequestContext, input: MarkOrderReadyInput): Promise<MarkOrderReadyOutput>;
    export interface ServeOrderInput {
        orderId: string;
    }
    export interface ServeOrderOutput {
        orderId: string;
        status: string;
    }
    export function serveOrder(ctx: RequestContext, input: ServeOrderInput): Promise<ServeOrderOutput>;
    export interface CloseOrderInput {
        orderId: string;
        tableId?: string;
    }
    export interface CloseOrderOutput {
        orderId: string;
        status: string;
        closedAt: string;
    }
    export function closeOrder(ctx: RequestContext, input: CloseOrderInput): Promise<CloseOrderOutput>;
    export interface CancelOrderInput {
        orderId: string;
        cancellationReason?: string;
        tableId?: string;
    }
    export interface CancelOrderOutput {
        orderId: string;
        status: string;
        cancelledAt: string;
    }
    export function cancelOrder(ctx: RequestContext, input: CancelOrderInput): Promise<CancelOrderOutput>;
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuCategories.defs" {
    export const manageMenuCategoriesUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "manageMenuCategories";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "manageMenuCategories";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "updateMenuCategory";
                readonly inputTypeName: "UpdateMenuCategoryInput";
                readonly outputTypeName: "UpdateMenuCategoryOutput";
                readonly input: readonly [{
                    readonly name: "menuCategoryId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuCategory";
                    readonly description: "Identifier of the MenuCategory to update";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuCategory";
                    readonly description: "Updated category name";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "MenuCategory";
                    readonly description: "Updated category description";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuCategory";
                    readonly description: "Updated status (active or inactive)";
                }];
                readonly output: readonly [{
                    readonly name: "menuCategoryId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuCategory";
                    readonly description: "Identifier of the updated MenuCategory";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuCategory";
                    readonly description: "Confirmed status after update";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuCategory";
                    readonly description: "Timestamp of the update";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly [];
                readonly transactional: true;
                readonly steps: readonly ["Load MenuCategory by menuCategoryId via MenuCategory port", "Validate that the MenuCategory exists; throw not-found if absent", "Validate status is one of 'active' or 'inactive'", "Apply updated fields (name, description, status) to the MenuCategory aggregate", "Set updatedAt to the current server timestamp", "Save the MenuCategory aggregate via MenuCategory port", "Return menuCategoryId, status, and updatedAt"];
            }];
            readonly mdmRefs: readonly ["MenuCategory"];
        };
    };
    export default manageMenuCategoriesUsecase;
    export const pipeline: readonly [{
        readonly id: "manageMenuCategories__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuCategories.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuCategories.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuCategories" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface UpdateMenuCategoryInput {
        menuCategoryId: string;
        name: string;
        description?: string;
        status: string;
    }
    export interface UpdateMenuCategoryOutput {
        menuCategoryId: string;
        status: string;
        updatedAt: string;
    }
    export function updateMenuCategory(ctx: RequestContext, input: UpdateMenuCategoryInput): Promise<UpdateMenuCategoryOutput>;
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.defs" {
    export const updateOrderStatusUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateOrderStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateOrderStatus";
            readonly ports: readonly ["Order", "Payment", "InventoryItem", "MenuItem"];
            readonly functions: readonly [{
                readonly functionName: "updateOrderStatus";
                readonly inputTypeName: "UpdateOrderStatusInput";
                readonly outputTypeName: "UpdateOrderStatusOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "ID of the order whose status is being updated";
                }, {
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Daily shift context for the operation";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Target status: draft, sentToKitchen, inPreparation, ready, served, closed, cancelled";
                }, {
                    readonly name: "cancellationReason";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Reason required when status is cancelled";
                }, {
                    readonly name: "tableId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Table ID for table-occupancy consistency check (mdmRef)";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "ID of the updated order";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "New status of the order";
                }, {
                    readonly name: "previousStatus";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Previous status before the transition";
                }, {
                    readonly name: "closedAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Timestamp set when order is closed";
                }, {
                    readonly name: "cancelledAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Timestamp set when order is cancelled";
                }, {
                    readonly name: "tableReleased";
                    readonly type: "boolean";
                    readonly required: false;
                    readonly description: "Whether the associated table was released to available";
                }, {
                    readonly name: "stockConsumptionIds";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "StockConsumption";
                    readonly description: "IDs of stock consumption records created when ingredients were consumed";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Timestamp of the update";
                }];
                readonly ports: readonly ["Order", "Payment", "InventoryItem", "MenuItem"];
                readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "aiOutputLanguageSelection", "tableOccupancyConsistency"];
                readonly transactional: true;
                readonly steps: readonly ["1. Load Order by orderId via Order port (includes embedded OrderItem collection and KitchenTicket reference)", "2. Validate the requested status transition against the current status using orderStatusTransitions rule — reject illegal transitions", "3. If target status is 'closed' or 'cancelled', verify payment requirements per paymentTimingByOrderType rule: for 'mesa' type check that a captured Payment exists via Payment port; for 'takeout' type check payment was authorized before preparation", "4. If target status is 'served' or 'closed', trigger ingredientConsumptionTrigger: for each OrderItem load its MenuItem via MenuItem port to obtain RecipeComponent list; for each RecipeComponent deduct quantity * orderItem.quantity from the corresponding InventoryItem via InventoryItem port and create StockConsumption records", "5. Apply aiOutputLanguageSelection to determine the language for any kitchen-ticket or notification output associated with the status change", "6. If target status is 'closed' or 'cancelled' and order has a tableId, enforce tableOccupancyConsistency: read Table via ctx.data.mdmDocument.get({ mdmId: tableId }), verify it is currently 'occupied', and update it to 'available'", "7. If target status is 'cancelled', set cancelledAt and require cancellationReason; if 'closed', set closedAt", "8. Update Order.status and updatedAt, then save the Order aggregate via Order port", "9. Return orderId, status, previousStatus, closedAt/cancelledAt if set, tableReleased flag, stockConsumptionIds if created, and updatedAt"];
            }];
            readonly mdmRefs: readonly ["Table"];
        };
    };
    export default updateOrderStatusUsecase;
    export const pipeline: readonly [{
        readonly id: "updateOrderStatus__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface UpdateOrderStatusInput {
        orderId: string;
        dailyShiftId: string;
        status: string;
        cancellationReason?: string;
        tableId?: string;
    }
    export interface UpdateOrderStatusOutput {
        orderId: string;
        status: string;
        previousStatus: string;
        closedAt?: string;
        cancelledAt?: string;
        tableReleased?: boolean;
        stockConsumptionIds?: string[];
        updatedAt: string;
    }
    export function updateOrderStatus(ctx: RequestContext, input: UpdateOrderStatusInput): Promise<UpdateOrderStatusOutput>;
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/updateTableStatus.defs" {
    export const updateTableStatusUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateTableStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateTableStatus";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "updateTableStatus";
                readonly inputTypeName: "UpdateTableStatusInput";
                readonly outputTypeName: "UpdateTableStatusOutput";
                readonly input: readonly [{
                    readonly name: "tableId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Unique identifier of the table whose status is being updated";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "New status for the table: available, occupied, or disabled";
                }];
                readonly output: readonly [{
                    readonly name: "tableId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Identifier of the updated table";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Confirmed status after update";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Timestamp of the status update";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["tableOccupancyConsistency"];
                readonly transactional: true;
                readonly steps: readonly ["Load Table master-data document by id via ctx.data.mdmDocument.get({ mdmId: tableId })", "Validate that the requested status is one of available, occupied, disabled", "Apply tableOccupancyConsistency rule: if transitioning to 'occupied' ensure no conflicting active occupancy; if transitioning to 'available' ensure no active orders/reservations tied to the table", "Update the Table document status field and set updatedAt to current timestamp", "Persist the updated Table master-data document via ctx.data.mdmDocument update within a single transaction", "Return tableId, confirmed status, and updatedAt"];
            }];
            readonly rulesApplied: readonly ["tableOccupancyConsistency"];
            readonly mdmRefs: readonly ["Table"];
        };
    };
    export default updateTableStatusUsecase;
    export const pipeline: readonly [{
        readonly id: "updateTableStatus__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateTableStatus.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateTableStatus.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["tableOccupancyConsistency"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/updateTableStatus" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface UpdateTableStatusInput {
        tableId: string;
        status: string;
    }
    export interface UpdateTableStatusOutput {
        tableId: string;
        status: string;
        updatedAt: string;
    }
    export function updateTableStatus(ctx: RequestContext, input: UpdateTableStatusInput): Promise<UpdateTableStatusOutput>;
}
declare module "_102050_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageMenuItems.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageTables.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/contracts/openDailyShift.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/contracts/recordPayment.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/browseMenuForPos.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        stateKey: string;
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "browseMenuForPos__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/browseMenuForPos.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/browseMenuForPos.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/browseMenuForPos.defs.ts", "_102050_/l2/cafeFlow/web/shared/browseMenuForPos.ts", "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.defs.ts", "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/browseMenuForPos" {
    import { CafeFlowBrowseMenuForPosBase } from '_102050_/l2/cafeFlow/web/shared/browseMenuForPos';
    export class CafeFlowDesktopPage11BrowseMenuForPosPage extends CafeFlowBrowseMenuForPosBase {
        render(): any;
    }
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/closeDailyShift.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "closeDailyShift__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/closeDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/closeDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/closeDailyShift.defs.ts", "_102050_/l2/cafeFlow/web/shared/closeDailyShift.ts", "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.defs.ts", "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/closeDailyShift" {
    import { CafeFlowCloseDailyShiftBase } from '_102050_/l2/cafeFlow/web/shared/closeDailyShift';
    export class CafeFlowDesktopPage11CloseDailyShiftPage extends CafeFlowCloseDailyShiftBase {
        render(): any;
    }
}
declare module "_102050_/l2/cafeFlow/web/shared/aiPromotionSuggestions.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/shared/aiSalesSummary.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/shared/browseMenuForPos.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/shared/closeDailyShift.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/shared/consumeIngredientsOnConfirmation.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/shared/manageInventoryItems.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "manageInventoryItems.section.main.title": string;
            "manageInventoryItems.organism.form.title": string;
            "manageInventoryItems.intention.status.title": string;
            "manageInventoryItems.intention.form.title": string;
            "manageInventoryItems.field.name.label": string;
            "manageInventoryItems.field.description.label": string;
            "manageInventoryItems.field.unit.label": string;
            "manageInventoryItems.field.currentQuantity.label": string;
            "manageInventoryItems.field.minimumLevel.label": string;
            "manageInventoryItems.field.status.label": string;
            "manageInventoryItems.action.submit.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "manageInventoryItems__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/manageInventoryItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/manageInventoryItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.defs.ts", "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.ts", "_102050_/l2/cafeFlow/web/desktop/page11/manageInventoryItems.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/manageInventoryItems" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class CafeFlowManageInventoryItemsBase extends CollabLitElement {
        status: string;
        manageInventoryItemsState: 'idle' | 'loading' | 'success' | 'error';
        manageInventoryItemsName: string;
        manageInventoryItemsDescription: string;
        manageInventoryItemsUnit: string;
        manageInventoryItemsCurrentQuantity: string;
        manageInventoryItemsMinimumLevel: string;
        manageInventoryItemsStatus: string;
        protected get msg(): Record<string, string>;
        connectedCallback(): void;
        disconnectedCallback(): void;
        setManageInventoryItemsName(value: string): void;
        handleManageInventoryItemsNameChange(e: Event): void;
        setManageInventoryItemsDescription(value: string): void;
        handleManageInventoryItemsDescriptionChange(e: Event): void;
        setManageInventoryItemsUnit(value: string): void;
        handleManageInventoryItemsUnitChange(e: Event): void;
        setManageInventoryItemsCurrentQuantity(value: string): void;
        handleManageInventoryItemsCurrentQuantityChange(e: Event): void;
        setManageInventoryItemsMinimumLevel(value: string): void;
        handleManageInventoryItemsMinimumLevelChange(e: Event): void;
        setManageInventoryItemsStatus(value: string): void;
        handleManageInventoryItemsStatusChange(e: Event): void;
        manageInventoryItems(): Promise<void>;
        handleManageInventoryItemsClick(e: Event): void;
    }
}
declare module "_102050_/l2/cafeFlow/web/shared/openDailyShift.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "openDailyShift.section.main.title": string;
            "openDailyShift.organism.createDailyShift.title": string;
            "openDailyShift.intention.createDailyShift.form.title": string;
            "openDailyShift.field.createDailyShift.shiftDate.label": string;
            "openDailyShift.field.createDailyShift.status.label": string;
            "openDailyShift.field.createDailyShift.openedAt.label": string;
            "openDailyShift.field.createDailyShift.openingCashBalance.label": string;
            "openDailyShift.action.createDailyShift.submit.label": string;
            "openDailyShift.organism.recordOpeningCashMovement.title": string;
            "openDailyShift.intention.recordOpeningCashMovement.form.title": string;
            "openDailyShift.field.recordOpeningCashMovement.movementType.label": string;
            "openDailyShift.field.recordOpeningCashMovement.amount.label": string;
            "openDailyShift.field.recordOpeningCashMovement.reason.label": string;
            "openDailyShift.action.recordOpeningCashMovement.submit.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "openDailyShift__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/openDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/openDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/openDailyShift.defs.ts", "_102050_/l2/cafeFlow/web/contracts/openDailyShift.ts", "_102050_/l2/cafeFlow/web/desktop/page11/openDailyShift.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/openDailyShift" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    type ActionStatus = 'idle' | 'loading' | 'success' | 'error';
    export class CafeFlowOpenDailyShiftBase extends CollabLitElement {
        status: string;
        createDailyShiftState: ActionStatus;
        createDailyShiftShiftDate: string;
        createDailyShiftStatus: string;
        createDailyShiftOpenedAt: string;
        createDailyShiftOpeningCashBalance: string;
        recordOpeningCashMovementState: ActionStatus;
        recordOpeningCashMovementMovementType: string;
        recordOpeningCashMovementAmount: string;
        recordOpeningCashMovementReason: string;
        protected get msg(): Record<string, string>;
        setCreateDailyShiftShiftDate(value: string): void;
        handleCreateDailyShiftShiftDateChange(e: Event): void;
        setCreateDailyShiftStatus(value: string): void;
        handleCreateDailyShiftStatusChange(e: Event): void;
        setCreateDailyShiftOpenedAt(value: string): void;
        handleCreateDailyShiftOpenedAtChange(e: Event): void;
        setCreateDailyShiftOpeningCashBalance(value: string): void;
        handleCreateDailyShiftOpeningCashBalanceChange(e: Event): void;
        setRecordOpeningCashMovementMovementType(value: string): void;
        handleRecordOpeningCashMovementMovementTypeChange(e: Event): void;
        setRecordOpeningCashMovementAmount(value: string): void;
        handleRecordOpeningCashMovementAmountChange(e: Event): void;
        setRecordOpeningCashMovementReason(value: string): void;
        handleRecordOpeningCashMovementReasonChange(e: Event): void;
        createDailyShift(): Promise<void>;
        handleCreateDailyShiftClick(): void;
        recordOpeningCashMovement(): Promise<void>;
        handleRecordOpeningCashMovementClick(): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
    }
}
declare module "_102050_/l2/cafeFlow/web/shared/recordPayment.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "recordPayment.section.title": string;
            "recordPayment.organism.title": string;
            "recordPayment.form.title": string;
            "recordPayment.field.method": string;
            "recordPayment.field.amount": string;
            "recordPayment.field.status": string;
            "recordPayment.action.submit": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "recordPayment__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/recordPayment.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/recordPayment.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/recordPayment.defs.ts", "_102050_/l2/cafeFlow/web/contracts/recordPayment.ts", "_102050_/l2/cafeFlow/web/desktop/page11/recordPayment.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/recordPayment" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    type ActionStatus = 'idle' | 'loading' | 'success' | 'error';
    export class CafeFlowRecordPaymentBase extends CollabLitElement {
        status: string;
        recordPaymentState: ActionStatus;
        recordPaymentMethod: string;
        recordPaymentAmount: string;
        recordPaymentStatus: string;
        protected get msg(): Record<string, string>;
        connectedCallback(): void;
        disconnectedCallback(): void;
        setRecordPaymentMethod(value: string): void;
        handleRecordPaymentMethodChange(e: Event): void;
        setRecordPaymentAmount(value: string): void;
        handleRecordPaymentAmountChange(e: Event): void;
        setRecordPaymentStatus(value: string): void;
        handleRecordPaymentStatusChange(e: Event): void;
        recordPayment(): Promise<void>;
        handleRecordPaymentClick(e: Event): void;
    }
}
declare module "_102050_/l2/cafeFlow/web/shared/viewOperationalDashboard.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        navigationRefs: any[];
        i18n: {
            "viewOperationalDashboard.section.title": string;
            "viewOperationalDashboard.organism.title": string;
            "viewOperationalDashboard.filters.title": string;
            "viewOperationalDashboard.field.dailyShiftId": string;
            "viewOperationalDashboard.field.shiftDate": string;
            "viewOperationalDashboard.field.status": string;
            "viewOperationalDashboard.field.openedAt": string;
            "viewOperationalDashboard.field.closedAt": string;
            "viewOperationalDashboard.field.createdAt": string;
            "viewOperationalDashboard.action.run": string;
            "viewOperationalDashboard.summary.title": string;
            "viewOperationalDashboard.summary.dailyShiftId": string;
            "viewOperationalDashboard.summary.shiftDate": string;
            "viewOperationalDashboard.summary.status": string;
            "viewOperationalDashboard.summary.openedAt": string;
            "viewOperationalDashboard.summary.closedAt": string;
            "viewOperationalDashboard.summary.openingCashBalance": string;
            "viewOperationalDashboard.summary.closingCashBalance": string;
            "viewOperationalDashboard.summary.totalSales": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "viewOperationalDashboard__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/viewOperationalDashboard.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/viewOperationalDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.defs.ts", "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.ts", "_102050_/l2/cafeFlow/web/desktop/page11/viewOperationalDashboard.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/viewOperationalDashboard" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { CafeFlowViewOperationalDashboardOutputItem } from '_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard';
    export class CafeFlowViewOperationalDashboardBase extends CollabLitElement {
        status: string;
        viewOperationalDashboardState: 'idle' | 'loading' | 'success' | 'error';
        viewOperationalDashboardDailyShiftId: string;
        viewOperationalDashboardShiftDate: string;
        viewOperationalDashboardStatus: string;
        viewOperationalDashboardOpenedAt: string;
        viewOperationalDashboardClosedAt: string;
        viewOperationalDashboardCreatedAt: string;
        viewOperationalDashboardData: CafeFlowViewOperationalDashboardOutputItem[];
        protected get msg(): Record<string, string>;
        connectedCallback(): void;
        disconnectedCallback(): void;
        loadViewOperationalDashboard(): Promise<void>;
        handleViewOperationalDashboardClick(): void;
        setViewOperationalDashboardDailyShiftId(value: string): void;
        handleViewOperationalDashboardDailyShiftIdChange(e: Event): void;
        setViewOperationalDashboardShiftDate(value: string): void;
        handleViewOperationalDashboardShiftDateChange(e: Event): void;
        setViewOperationalDashboardStatus(value: string): void;
        handleViewOperationalDashboardStatusChange(e: Event): void;
        setViewOperationalDashboardOpenedAt(value: string): void;
        handleViewOperationalDashboardOpenedAtChange(e: Event): void;
        setViewOperationalDashboardClosedAt(value: string): void;
        handleViewOperationalDashboardClosedAtChange(e: Event): void;
        setViewOperationalDashboardCreatedAt(value: string): void;
        handleViewOperationalDashboardCreatedAtChange(e: Event): void;
    }
}
