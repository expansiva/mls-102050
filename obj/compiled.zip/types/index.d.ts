declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/addOrderItem.defs" {
    export const addOrderItemController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "addOrderItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "addOrderItem";
            readonly controllerName: "AddOrderItemController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowAddOrderItemHandler";
                readonly command: "addOrderItem";
                readonly usecaseRef: "addOrderItem";
                readonly kind: "create";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.addOrderItem.addOrderItem";
                readonly handlerName: "cafeFlowAddOrderItemHandler";
            }];
        };
    };
    export default addOrderItemController;
    export const pipeline: readonly [{
        readonly id: "addOrderItem__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/addOrderItem.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/addOrderItem.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/addOrderItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/aiPromotionSuggestions.defs" {
    export const aiPromotionSuggestionsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "aiPromotionSuggestions";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "aiPromotionSuggestions";
            readonly controllerName: "AiPromotionSuggestionsController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowAiPromotionSuggestionsHandler";
                readonly command: "aiPromotionSuggestions";
                readonly usecaseRef: "aiPromotionSuggestions";
                readonly kind: "query";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.aiPromotionSuggestions.aiPromotionSuggestions";
                readonly handlerName: "cafeFlowAiPromotionSuggestionsHandler";
            }];
        };
    };
    export default aiPromotionSuggestionsController;
    export const pipeline: readonly [{
        readonly id: "aiPromotionSuggestions__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/aiPromotionSuggestions.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/aiPromotionSuggestions.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/aiPromotionSuggestions.d.ts", "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/aiSalesSummary.defs" {
    export const aiSalesSummaryController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "aiSalesSummary";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "aiSalesSummary";
            readonly controllerName: "AiSalesSummaryController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowAiSalesSummaryHandler";
                readonly command: "aiSalesSummary";
                readonly usecaseRef: "aiSalesSummary";
                readonly kind: "query";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.aiSalesSummary.aiSalesSummary";
                readonly handlerName: "cafeFlowAiSalesSummaryHandler";
            }];
        };
    };
    export default aiSalesSummaryController;
    export const pipeline: readonly [{
        readonly id: "aiSalesSummary__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/aiSalesSummary.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/aiSalesSummary.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/aiSalesSummary.d.ts", "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseMenuForPos.defs" {
    export const browseMenuForPosController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "browseMenuForPos";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "browseMenuForPos";
            readonly controllerName: "BrowseMenuForPosController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowBrowseMenuForPosHandler";
                readonly command: "browseMenuForPos";
                readonly usecaseRef: "browseMenuForPos";
                readonly kind: "query";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.browseMenuForPos.browseMenuForPos";
                readonly handlerName: "cafeFlowBrowseMenuForPosHandler";
            }];
        };
    };
    export default browseMenuForPosController;
    export const pipeline: readonly [{
        readonly id: "browseMenuForPos__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseMenuForPos.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseMenuForPos.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/browseMenuForPos.d.ts", "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/closeDailyShift.defs" {
    export const closeDailyShiftController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "closeDailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "closeDailyShift";
            readonly controllerName: "CloseDailyShiftController";
            readonly ownerKind: "workflow";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowCloseDailyShiftHandler";
                readonly command: "closeDailyShift";
                readonly usecaseRef: "closeDailyShift";
                readonly kind: "command";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.closeDailyShift.closeDailyShift";
                readonly handlerName: "cafeFlowCloseDailyShiftHandler";
            }];
        };
    };
    export default closeDailyShiftController;
    export const pipeline: readonly [{
        readonly id: "closeDailyShift__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/closeDailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/closeDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/closeDailyShift.d.ts", "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/consumeIngredientsOnConfirmation.defs" {
    export const consumeIngredientsOnConfirmationController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "consumeIngredientsOnConfirmation";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "consumeIngredientsOnConfirmation";
            readonly controllerName: "ConsumeIngredientsOnConfirmationController";
            readonly ownerKind: "workflow";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowConsumeIngredientsOnConfirmationHandler";
                readonly command: "consumeIngredientsOnConfirmation";
                readonly usecaseRef: "consumeIngredientsOnConfirmation";
                readonly kind: "command";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.consumeIngredientsOnConfirmation.consumeIngredientsOnConfirmation";
                readonly handlerName: "cafeFlowConsumeIngredientsOnConfirmationHandler";
            }];
        };
    };
    export default consumeIngredientsOnConfirmationController;
    export const pipeline: readonly [{
        readonly id: "consumeIngredientsOnConfirmation__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/consumeIngredientsOnConfirmation.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/consumeIngredientsOnConfirmation.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/consumeIngredientsOnConfirmation.d.ts", "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createDailyShift.defs" {
    export const createDailyShiftController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createDailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "createDailyShift";
            readonly controllerName: "CreateDailyShiftController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowCreateDailyShiftHandler";
                readonly command: "createDailyShift";
                readonly usecaseRef: "createDailyShift";
                readonly kind: "create";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.createDailyShift.createDailyShift";
                readonly handlerName: "cafeFlowCreateDailyShiftHandler";
            }];
        };
    };
    export default createDailyShiftController;
    export const pipeline: readonly [{
        readonly id: "createDailyShift__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createDailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/createDailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createKitchenTicket.defs" {
    export const createKitchenTicketController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createKitchenTicket";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "createKitchenTicket";
            readonly controllerName: "CreateKitchenTicketController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowCreateKitchenTicketHandler";
                readonly command: "createKitchenTicket";
                readonly usecaseRef: "createKitchenTicket";
                readonly kind: "create";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.createKitchenTicket.createKitchenTicket";
                readonly handlerName: "cafeFlowCreateKitchenTicketHandler";
            }];
        };
    };
    export default createKitchenTicketController;
    export const pipeline: readonly [{
        readonly id: "createKitchenTicket__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createKitchenTicket.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createKitchenTicket.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/createKitchenTicket.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createOrder.defs" {
    export const createOrderController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createOrder";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "createOrder";
            readonly controllerName: "CreateOrderController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowCreateOrderHandler";
                readonly command: "createOrder";
                readonly usecaseRef: "createOrder";
                readonly kind: "create";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.createOrder.createOrder";
                readonly handlerName: "cafeFlowCreateOrderHandler";
            }];
        };
    };
    export default createOrderController;
    export const pipeline: readonly [{
        readonly id: "createOrder__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createOrder.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createOrder.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/createOrder.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createStockConsumption.defs" {
    export const createStockConsumptionController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createStockConsumption";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "createStockConsumption";
            readonly controllerName: "CreateStockConsumptionController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowCreateStockConsumptionHandler";
                readonly command: "createStockConsumption";
                readonly usecaseRef: "createStockConsumption";
                readonly kind: "create";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.createStockConsumption.createStockConsumption";
                readonly handlerName: "cafeFlowCreateStockConsumptionHandler";
            }];
        };
    };
    export default createStockConsumptionController;
    export const pipeline: readonly [{
        readonly id: "createStockConsumption__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createStockConsumption.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createStockConsumption.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/createStockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/dineInOrderLifecycle.defs" {
    export const dineInOrderLifecycleController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "dineInOrderLifecycle";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "dineInOrderLifecycle";
            readonly controllerName: "DineInOrderLifecycleController";
            readonly ownerKind: "workflow";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowDineInOrderLifecycleHandler";
                readonly command: "dineInOrderLifecycle";
                readonly usecaseRef: "dineInOrderLifecycle";
                readonly kind: "command";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.dineInOrderLifecycle.dineInOrderLifecycle";
                readonly handlerName: "cafeFlowDineInOrderLifecycleHandler";
            }];
        };
    };
    export default dineInOrderLifecycleController;
    export const pipeline: readonly [{
        readonly id: "dineInOrderLifecycle__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/dineInOrderLifecycle.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/dineInOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/dineInOrderLifecycle.d.ts", "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/generateShiftCloseReport.defs" {
    export const generateShiftCloseReportController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "generateShiftCloseReport";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "generateShiftCloseReport";
            readonly controllerName: "GenerateShiftCloseReportController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowGenerateShiftCloseReportHandler";
                readonly command: "generateShiftCloseReport";
                readonly usecaseRef: "generateShiftCloseReport";
                readonly kind: "query";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.generateShiftCloseReport.generateShiftCloseReport";
                readonly handlerName: "cafeFlowGenerateShiftCloseReportHandler";
            }];
        };
    };
    export default generateShiftCloseReportController;
    export const pipeline: readonly [{
        readonly id: "generateShiftCloseReport__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/generateShiftCloseReport.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/generateShiftCloseReport.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/generateShiftCloseReport.d.ts", "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/kitchenProductionFlow.defs" {
    export const kitchenProductionFlowController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "kitchenProductionFlow";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "kitchenProductionFlow";
            readonly controllerName: "KitchenProductionFlowController";
            readonly ownerKind: "workflow";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowKitchenProductionFlowHandler";
                readonly command: "kitchenProductionFlow";
                readonly usecaseRef: "kitchenProductionFlow";
                readonly kind: "command";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.kitchenProductionFlow.kitchenProductionFlow";
                readonly handlerName: "cafeFlowKitchenProductionFlowHandler";
            }];
        };
    };
    export default kitchenProductionFlowController;
    export const pipeline: readonly [{
        readonly id: "kitchenProductionFlow__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/kitchenProductionFlow.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/kitchenProductionFlow.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/kitchenProductionFlow.d.ts", "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageInventoryItems.defs" {
    export const manageInventoryItemsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "manageInventoryItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "manageInventoryItems";
            readonly controllerName: "ManageInventoryItemsController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowManageInventoryItemsHandler";
                readonly command: "manageInventoryItems";
                readonly usecaseRef: "manageInventoryItems";
                readonly kind: "update";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.manageInventoryItems.manageInventoryItems";
                readonly handlerName: "cafeFlowManageInventoryItemsHandler";
            }];
        };
    };
    export default manageInventoryItemsController;
    export const pipeline: readonly [{
        readonly id: "manageInventoryItems__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageInventoryItems.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageInventoryItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/manageInventoryItems.d.ts", "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuCategories.defs" {
    export const manageMenuCategoriesController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "manageMenuCategories";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "manageMenuCategories";
            readonly controllerName: "ManageMenuCategoriesController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowManageMenuCategoriesHandler";
                readonly command: "manageMenuCategories";
                readonly usecaseRef: "manageMenuCategories";
                readonly kind: "update";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.manageMenuCategories.manageMenuCategories";
                readonly handlerName: "cafeFlowManageMenuCategoriesHandler";
            }];
        };
    };
    export default manageMenuCategoriesController;
    export const pipeline: readonly [{
        readonly id: "manageMenuCategories__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuCategories.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuCategories.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuCategories.d.ts", "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuItems.defs" {
    export const manageMenuItemsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "manageMenuItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "manageMenuItems";
            readonly controllerName: "ManageMenuItemsController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowManageMenuItemsHandler";
                readonly command: "manageMenuItems";
                readonly usecaseRef: "manageMenuItems";
                readonly kind: "update";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.manageMenuItems.manageMenuItems";
                readonly handlerName: "cafeFlowManageMenuItemsHandler";
            }];
        };
    };
    export default manageMenuItemsController;
    export const pipeline: readonly [{
        readonly id: "manageMenuItems__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuItems.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuItems.d.ts", "_102050_/l2/cafeFlow/web/contracts/manageMenuItems.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageTables.defs" {
    export const manageTablesController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "manageTables";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "manageTables";
            readonly controllerName: "ManageTablesController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowManageTablesHandler";
                readonly command: "manageTables";
                readonly usecaseRef: "manageTables";
                readonly kind: "update";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.manageTables.manageTables";
                readonly handlerName: "cafeFlowManageTablesHandler";
            }];
        };
    };
    export default manageTablesController;
    export const pipeline: readonly [{
        readonly id: "manageTables__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageTables.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageTables.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/manageTables.d.ts", "_102050_/l2/cafeFlow/web/contracts/manageTables.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/openDailyShift.defs" {
    export const openDailyShiftController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "openDailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "openDailyShift";
            readonly controllerName: "OpenDailyShiftController";
            readonly ownerKind: "workflow";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowOpenDailyShiftHandler";
                readonly command: "openDailyShift";
                readonly usecaseRef: "openDailyShift";
                readonly kind: "command";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.openDailyShift.openDailyShift";
                readonly handlerName: "cafeFlowOpenDailyShiftHandler";
            }];
        };
    };
    export default openDailyShiftController;
    export const pipeline: readonly [{
        readonly id: "openDailyShift__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/openDailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/openDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/openDailyShift.d.ts", "_102050_/l2/cafeFlow/web/contracts/openDailyShift.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/recordOpeningCashMovement.defs" {
    export const recordOpeningCashMovementController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "recordOpeningCashMovement";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "recordOpeningCashMovement";
            readonly controllerName: "RecordOpeningCashMovementController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowRecordOpeningCashMovementHandler";
                readonly command: "recordOpeningCashMovement";
                readonly usecaseRef: "recordOpeningCashMovement";
                readonly kind: "create";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.recordOpeningCashMovement.recordOpeningCashMovement";
                readonly handlerName: "cafeFlowRecordOpeningCashMovementHandler";
            }];
        };
    };
    export default recordOpeningCashMovementController;
    export const pipeline: readonly [{
        readonly id: "recordOpeningCashMovement__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/recordOpeningCashMovement.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/recordOpeningCashMovement.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/recordOpeningCashMovement.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/recordPayment.defs" {
    export const recordPaymentController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "recordPayment";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "recordPayment";
            readonly controllerName: "RecordPaymentController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowRecordPaymentHandler";
                readonly command: "recordPayment";
                readonly usecaseRef: "recordPayment";
                readonly kind: "create";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.recordPayment.recordPayment";
                readonly handlerName: "cafeFlowRecordPaymentHandler";
            }];
        };
    };
    export default recordPaymentController;
    export const pipeline: readonly [{
        readonly id: "recordPayment__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/recordPayment.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/recordPayment.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/recordPayment.d.ts", "_102050_/l2/cafeFlow/web/contracts/recordPayment.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/takeoutOrderLifecycle.defs" {
    export const takeoutOrderLifecycleController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "takeoutOrderLifecycle";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "takeoutOrderLifecycle";
            readonly controllerName: "TakeoutOrderLifecycleController";
            readonly ownerKind: "workflow";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowTakeoutOrderLifecycleHandler";
                readonly command: "takeoutOrderLifecycle";
                readonly usecaseRef: "takeoutOrderLifecycle";
                readonly kind: "command";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.takeoutOrderLifecycle.takeoutOrderLifecycle";
                readonly handlerName: "cafeFlowTakeoutOrderLifecycleHandler";
            }];
        };
    };
    export default takeoutOrderLifecycleController;
    export const pipeline: readonly [{
        readonly id: "takeoutOrderLifecycle__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/takeoutOrderLifecycle.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/takeoutOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/takeoutOrderLifecycle.d.ts", "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateKitchenTicketStatus.defs" {
    export const updateKitchenTicketStatusController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateKitchenTicketStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "updateKitchenTicketStatus";
            readonly controllerName: "UpdateKitchenTicketStatusController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowUpdateKitchenTicketStatusHandler";
                readonly command: "updateKitchenTicketStatus";
                readonly usecaseRef: "updateKitchenTicketStatus";
                readonly kind: "update";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.updateKitchenTicketStatus.updateKitchenTicketStatus";
                readonly handlerName: "cafeFlowUpdateKitchenTicketStatusHandler";
            }];
        };
    };
    export default updateKitchenTicketStatusController;
    export const pipeline: readonly [{
        readonly id: "updateKitchenTicketStatus__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateKitchenTicketStatus.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateKitchenTicketStatus.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/updateKitchenTicketStatus.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateOrderItemStatus.defs" {
    export const updateOrderItemStatusController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateOrderItemStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "updateOrderItemStatus";
            readonly controllerName: "UpdateOrderItemStatusController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowUpdateOrderItemStatusHandler";
                readonly command: "updateOrderItemStatus";
                readonly usecaseRef: "updateOrderItemStatus";
                readonly kind: "update";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.updateOrderItemStatus.updateOrderItemStatus";
                readonly handlerName: "cafeFlowUpdateOrderItemStatusHandler";
            }];
        };
    };
    export default updateOrderItemStatusController;
    export const pipeline: readonly [{
        readonly id: "updateOrderItemStatus__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateOrderItemStatus.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateOrderItemStatus.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderItemStatus.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateOrderStatus.defs" {
    export const updateOrderStatusController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateOrderStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "updateOrderStatus";
            readonly controllerName: "UpdateOrderStatusController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowUpdateOrderStatusHandler";
                readonly command: "updateOrderStatus";
                readonly usecaseRef: "updateOrderStatus";
                readonly kind: "update";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.updateOrderStatus.updateOrderStatus";
                readonly handlerName: "cafeFlowUpdateOrderStatusHandler";
            }];
        };
    };
    export default updateOrderStatusController;
    export const pipeline: readonly [{
        readonly id: "updateOrderStatus__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateOrderStatus.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateOrderStatus.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateTableStatus.defs" {
    export const updateTableStatusController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateTableStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "updateTableStatus";
            readonly controllerName: "UpdateTableStatusController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowUpdateTableStatusHandler";
                readonly command: "updateTableStatus";
                readonly usecaseRef: "updateTableStatus";
                readonly kind: "update";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.updateTableStatus.updateTableStatus";
                readonly handlerName: "cafeFlowUpdateTableStatusHandler";
            }];
        };
    };
    export default updateTableStatusController;
    export const pipeline: readonly [{
        readonly id: "updateTableStatus__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateTableStatus.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateTableStatus.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/updateTableStatus.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewKitchenTickets.defs" {
    export const viewKitchenTicketsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "viewKitchenTickets";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "viewKitchenTickets";
            readonly controllerName: "ViewKitchenTicketsController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowViewKitchenTicketsHandler";
                readonly command: "viewKitchenTickets";
                readonly usecaseRef: "viewKitchenTickets";
                readonly kind: "query";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.viewKitchenTickets.viewKitchenTickets";
                readonly handlerName: "cafeFlowViewKitchenTicketsHandler";
            }];
        };
    };
    export default viewKitchenTicketsController;
    export const pipeline: readonly [{
        readonly id: "viewKitchenTickets__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewKitchenTickets.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewKitchenTickets.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/viewKitchenTickets.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewOperationalDashboard.defs" {
    export const viewOperationalDashboardController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "viewOperationalDashboard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "viewOperationalDashboard";
            readonly controllerName: "ViewOperationalDashboardController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowViewOperationalDashboardHandler";
                readonly command: "viewOperationalDashboard";
                readonly usecaseRef: "viewOperationalDashboard";
                readonly kind: "query";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.viewOperationalDashboard.viewOperationalDashboard";
                readonly handlerName: "cafeFlowViewOperationalDashboardHandler";
            }];
        };
    };
    export default viewOperationalDashboardController;
    export const pipeline: readonly [{
        readonly id: "viewOperationalDashboard__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewOperationalDashboard.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewOperationalDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/usecases/viewOperationalDashboard.d.ts", "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShift.defs" {
    export const dailyShiftTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "DailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "DailyShift";
            readonly tableName: "daily_shift";
            readonly columns: readonly [{
                readonly name: "daily_shift_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "shiftDate, openedAt, closedAt, openingCashBalance, closingCashBalance, totalSales, totalPayments, closingNotes, updatedAt";
            }];
            readonly primaryKey: readonly ["daily_shift_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_daily_shift_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_daily_shift_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly ["CashMovement"];
            };
        };
    };
    export default dailyShiftTableDefinition;
    export const pipeline: readonly [{
        readonly id: "dailyShift__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShiftRepositoryAdapter.defs" {
    export const dailyShiftRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "DailyShiftRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "DailyShiftRepositoryAdapter";
            readonly entityId: "DailyShift";
            readonly portRef: "IDailyShiftRepository";
            readonly tableRef: "daily_shifts";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Real columns: daily_shift_id, status, created_at", "Details JSONB holds shiftDate, openedAt, closedAt, openingCashBalance, closingCashBalance, totalSales, totalPayments, closingNotes, updatedAt, cashMovements (embedded)"];
        };
    };
    export default dailyShiftRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "dailyShiftRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShiftRepositoryAdapter.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShiftRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShift.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShiftRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IDailyShiftRepository } from '_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository';
    export function createDailyShiftRepositoryAdapter(ctx: RequestContext): IDailyShiftRepository;
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItem.defs" {
    export const inventoryItemTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "InventoryItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "InventoryItem";
            readonly tableName: "inventory_item";
            readonly columns: readonly [{
                readonly name: "inventory_item_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "name, description, unit, currentQuantity, minimumLevel, updatedAt";
            }];
            readonly primaryKey: readonly ["inventory_item_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_inventory_item_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_inventory_item_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
        };
    };
    export default inventoryItemTableDefinition;
    export const pipeline: readonly [{
        readonly id: "inventoryItem__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItem.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItem.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItemRepositoryAdapter.defs" {
    export const inventoryItemRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "InventoryItemRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "InventoryItemRepositoryAdapter";
            readonly entityId: "InventoryItem";
            readonly portRef: "IInventoryItemRepository";
            readonly tableRef: "inventory_items";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Real columns: inventory_item_id, status, created_at", "Details JSONB holds name, description, unit, current_quantity, minimum_level, updated_at"];
        };
    };
    export default inventoryItemRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "inventoryItemRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItemRepositoryAdapter.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItemRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItem.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItemRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IInventoryItemRepository } from '_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository';
    export function createInventoryItemRepositoryAdapter(ctx: RequestContext): IInventoryItemRepository;
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItem.defs" {
    export const menuItemTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "MenuItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "MenuItem";
            readonly tableName: "menu_item";
            readonly columns: readonly [{
                readonly name: "menu_item_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "menu_category_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "name, description, price, updatedAt";
            }];
            readonly primaryKey: readonly ["menu_item_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_menu_item_menu_category_id";
                readonly columns: readonly ["menu_category_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_menu_item_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_menu_item_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly ["RecipeComponent"];
            };
        };
    };
    export default menuItemTableDefinition;
    export const pipeline: readonly [{
        readonly id: "menuItem__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItem.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItem.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemRepositoryAdapter.defs" {
    export const menuItemRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "MenuItemRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "MenuItemRepositoryAdapter";
            readonly entityId: "MenuItem";
            readonly portRef: "IMenuItemRepository";
            readonly tableRef: "menu_items";
            readonly mdmReads: readonly ["MenuCategory"];
            readonly notes: readonly ["Real columns: menu_item_id, menu_category_id, status, created_at", "Details JSONB holds name, description, price, updated_at, recipeComponents (embedded)", "Resolves MenuCategory via ctx.data.mdm(102034) — no local MDM table"];
        };
    };
    export default menuItemRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "menuItemRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemRepositoryAdapter.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItem.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IMenuItemRepository } from '_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository';
    export function createMenuItemRepositoryAdapter(ctx: RequestContext): IMenuItemRepository;
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/order.defs" {
    export const orderTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Order";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Order";
            readonly tableName: "order";
            readonly columns: readonly [{
                readonly name: "order_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "daily_shift_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "table_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "kitchen_ticket_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "order_type";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "status";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "totalAmount, notes, customerName, customerPhone, numberOfGuests, closedAt, cancelledAt, cancellationReason, updatedAt";
            }];
            readonly primaryKey: readonly ["order_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_order_daily_shift_id";
                readonly columns: readonly ["daily_shift_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_table_id";
                readonly columns: readonly ["table_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_kitchen_ticket_id";
                readonly columns: readonly ["kitchen_ticket_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_order_type";
                readonly columns: readonly ["order_type"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly ["OrderItem", "KitchenTicket"];
            };
        };
    };
    export default orderTableDefinition;
    export const pipeline: readonly [{
        readonly id: "order__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/order.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/order.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter.defs" {
    export const orderRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "OrderRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "OrderRepositoryAdapter";
            readonly entityId: "Order";
            readonly portRef: "IOrderRepository";
            readonly tableRef: "orders";
            readonly mdmReads: readonly ["Table"];
            readonly notes: readonly ["Real columns: order_id, daily_shift_id, table_id, kitchen_ticket_id, order_type, status, created_at", "Details JSONB holds totalAmount, notes, customerName, customerPhone, numberOfGuests, closedAt, cancelledAt, cancellationReason, updatedAt, orderItems (embedded), kitchenTickets (embedded)", "Resolves Table via ctx.data.mdm(102034) — no local MDM table"];
        };
    };
    export default orderRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "orderRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IOrderRepository } from '_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository';
    export function createOrderRepositoryAdapter(ctx: RequestContext): IOrderRepository;
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/payment.defs" {
    export const paymentTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Payment";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Payment";
            readonly tableName: "payment";
            readonly columns: readonly [{
                readonly name: "payment_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "order_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "daily_shift_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "method, amount, updatedAt";
            }];
            readonly primaryKey: readonly ["payment_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_payment_order_id";
                readonly columns: readonly ["order_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_payment_daily_shift_id";
                readonly columns: readonly ["daily_shift_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_payment_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_payment_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
        };
    };
    export default paymentTableDefinition;
    export const pipeline: readonly [{
        readonly id: "payment__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/payment.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/payment.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/paymentRepositoryAdapter.defs" {
    export const paymentRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "PaymentRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "PaymentRepositoryAdapter";
            readonly entityId: "Payment";
            readonly portRef: "IPaymentRepository";
            readonly tableRef: "payments";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Real columns: payment_id, order_id, daily_shift_id, status, created_at", "Details JSONB holds method, amount, updatedAt"];
        };
    };
    export default paymentRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "paymentRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/paymentRepositoryAdapter.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/paymentRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.d.ts", "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/payment.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/paymentRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IPaymentRepository } from '_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository';
    export function createPaymentRepositoryAdapter(ctx: RequestContext): IPaymentRepository;
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/tableOccupancy.defs" {
    export const tableOccupancyTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "TableOccupancy";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "TableOccupancy";
            readonly tableName: "table_occupancy";
            readonly columns: readonly [{
                readonly name: "table_occupancy_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "table_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "currentChargesTotal, openedAt, closedAt, updatedAt";
            }];
            readonly primaryKey: readonly ["table_occupancy_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_table_occupancy_table_id";
                readonly columns: readonly ["table_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_table_occupancy_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_table_occupancy_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
        };
    };
    export default tableOccupancyTableDefinition;
    export const pipeline: readonly [{
        readonly id: "tableOccupancy__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/tableOccupancy.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/tableOccupancy.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/tableOccupancy.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/tableOccupancyRepositoryAdapter.defs" {
    export const tableOccupancyRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "TableOccupancyRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "TableOccupancyRepositoryAdapter";
            readonly entityId: "TableOccupancy";
            readonly portRef: "ITableOccupancyRepository";
            readonly tableRef: "table_occupancies";
            readonly mdmReads: readonly ["Table"];
            readonly notes: readonly ["Columns: table_occupancy_id, table_id, status, created_at", "Details JSONB: currentChargesTotal, openedAt, closedAt, updatedAt", "MDM ref Table resolved via 102034 runtime; ctx.data allowed"];
        };
    };
    export default tableOccupancyRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "tableOccupancyRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/tableOccupancyRepositoryAdapter.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/tableOccupancyRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/tableOccupancyRepository.d.ts", "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/tableOccupancy.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/tableOccupancy.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.defs" {
    export const dailyShiftRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "DailyShiftRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "DailyShift";
            readonly interfaceName: "IDailyShiftRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: DailyShiftId"];
                readonly returns: "DailyShift";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: DailyShiftFilter"];
                readonly returns: "DailyShift[]";
            }, {
                readonly name: "save";
                readonly params: readonly ["dailyShift: DailyShift"];
                readonly returns: "void";
            }, {
                readonly name: "findOpenShift";
                readonly params: readonly [];
                readonly returns: "DailyShift | null";
            }, {
                readonly name: "findByDate";
                readonly params: readonly ["businessDate: LocalDate"];
                readonly returns: "DailyShift[]";
            }];
        };
    };
    export default dailyShiftRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "dailyShiftRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.defs" {
    export const inventoryItemRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "InventoryItemRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "InventoryItem";
            readonly interfaceName: "IInventoryItemRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: InventoryItemId"];
                readonly returns: "InventoryItem";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: InventoryItemFilter"];
                readonly returns: "InventoryItem[]";
            }, {
                readonly name: "save";
                readonly params: readonly ["inventoryItem: InventoryItem"];
                readonly returns: "void";
            }, {
                readonly name: "findLowStock";
                readonly params: readonly [];
                readonly returns: "InventoryItem[]";
            }, {
                readonly name: "findBySupplier";
                readonly params: readonly ["supplierId: SupplierId"];
                readonly returns: "InventoryItem[]";
            }];
        };
    };
    export default inventoryItemRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "inventoryItemRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.defs" {
    export const menuItemRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "MenuItemRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "MenuItem";
            readonly interfaceName: "IMenuItemRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: MenuItemId"];
                readonly returns: "MenuItem";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: MenuItemFilter"];
                readonly returns: "MenuItem[]";
            }, {
                readonly name: "save";
                readonly params: readonly ["menuItem: MenuItem"];
                readonly returns: "void";
            }, {
                readonly name: "findByCategory";
                readonly params: readonly ["categoryId: CategoryId"];
                readonly returns: "MenuItem[]";
            }, {
                readonly name: "findAvailable";
                readonly params: readonly [];
                readonly returns: "MenuItem[]";
            }];
        };
    };
    export default menuItemRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "menuItemRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.defs" {
    export const orderRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "OrderRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Order";
            readonly interfaceName: "IOrderRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: OrderId"];
                readonly returns: "Order";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: OrderFilter"];
                readonly returns: "Order[]";
            }, {
                readonly name: "save";
                readonly params: readonly ["order: Order"];
                readonly returns: "void";
            }, {
                readonly name: "findOpenByTable";
                readonly params: readonly ["tableId: TableId"];
                readonly returns: "Order[]";
            }, {
                readonly name: "findWithPendingKitchenTickets";
                readonly params: readonly [];
                readonly returns: "Order[]";
            }, {
                readonly name: "findByShift";
                readonly params: readonly ["shiftId: DailyShiftId"];
                readonly returns: "Order[]";
            }];
        };
    };
    export default orderRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "orderRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.defs" {
    export const paymentRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "PaymentRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Payment";
            readonly interfaceName: "IPaymentRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: PaymentId"];
                readonly returns: "Payment";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: PaymentFilter"];
                readonly returns: "Payment[]";
            }, {
                readonly name: "save";
                readonly params: readonly ["payment: Payment"];
                readonly returns: "void";
            }, {
                readonly name: "findByOrder";
                readonly params: readonly ["orderId: OrderId"];
                readonly returns: "Payment[]";
            }, {
                readonly name: "findPendingSettlement";
                readonly params: readonly [];
                readonly returns: "Payment[]";
            }];
        };
    };
    export default paymentRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "paymentRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/ports/tableOccupancyRepository.defs" {
    export const tableOccupancyRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "TableOccupancyRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "TableOccupancy";
            readonly interfaceName: "ITableOccupancyRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: TableOccupancyId"];
                readonly returns: "TableOccupancy";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: TableOccupancyFilter"];
                readonly returns: "TableOccupancy[]";
            }, {
                readonly name: "save";
                readonly params: readonly ["tableOccupancy: TableOccupancy"];
                readonly returns: "void";
            }, {
                readonly name: "findActiveByTable";
                readonly params: readonly ["tableId: TableId"];
                readonly returns: "TableOccupancy | null";
            }, {
                readonly name: "findActive";
                readonly params: readonly [];
                readonly returns: "TableOccupancy[]";
            }];
        };
    };
    export default tableOccupancyRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "tableOccupancyRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/ports/tableOccupancyRepository.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/ports/tableOccupancyRepository.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/tableOccupancy.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/addOrderItem.defs" {
    export const addOrderItemUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "addOrderItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "addOrderItem";
            readonly ports: readonly ["Order", "MenuItem"];
            readonly functions: readonly [{
                readonly functionName: "addOrderItem";
                readonly inputTypeName: "AddOrderItemInput";
                readonly outputTypeName: "AddOrderItemOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "ID of the parent Order to which the item will be added";
                }, {
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "ID of the MenuItem to add to the order";
                }, {
                    readonly name: "quantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "OrderItem";
                    readonly description: "Quantity of the menu item ordered";
                }, {
                    readonly name: "observations";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "OrderItem";
                    readonly description: "Optional preparation notes or customer requests";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "ID of the parent Order";
                }, {
                    readonly name: "orderItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "OrderItem";
                    readonly description: "ID of the newly created OrderItem";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "OrderItem";
                    readonly description: "Initial status of the order item (new)";
                }];
                readonly ports: readonly ["Order", "MenuItem"];
                readonly rulesApplied: readonly ["orderStatusTransitions", "ingredientConsumptionTrigger"];
                readonly transactional: true;
                readonly steps: readonly ["Load Order by orderId via Order port", "Validate Order status is not closed or cancelled (orderStatusTransitions rule)", "Load MenuItem by menuItemId via MenuItem port", "Validate MenuItem status is active", "Compute unitPrice from MenuItem.price and totalPrice = unitPrice * quantity", "Create new OrderItem with status 'new', computed prices, and provided observations", "Add OrderItem to Order's items collection", "Recalculate Order.totalAmount from all order items", "Apply ingredientConsumptionTrigger: generate StockConsumption entries for the menu item's ingredients", "Save Order (with embedded OrderItem and StockConsumption) via Order port", "Return orderId, orderItemId, and status"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default addOrderItemUsecase;
    export const pipeline: readonly [{
        readonly id: "addOrderItem__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/addOrderItem.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/addOrderItem.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/addOrderItem" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface AddOrderItemInput {
        orderId: string;
        menuItemId: string;
        quantity: number;
        observations?: string;
    }
    export interface AddOrderItemOutput {
        orderId: string;
        orderItemId: string;
        status: string;
    }
    export function addOrderItem(ctx: RequestContext, input: AddOrderItemInput): Promise<AddOrderItemOutput>;
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/aiPromotionSuggestions.defs" {
    export const aiPromotionSuggestionsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "aiPromotionSuggestions";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "aiPromotionSuggestions";
            readonly ports: readonly ["Order", "MenuItem"];
            readonly functions: readonly [{
                readonly functionName: "aiPromotionSuggestions";
                readonly inputTypeName: "AiPromotionSuggestionsInput";
                readonly outputTypeName: "AiPromotionSuggestionsOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "The order to analyze for promotion suggestions";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "The analyzed order id";
                }, {
                    readonly name: "suggestions";
                    readonly type: "array";
                    readonly required: true;
                    readonly description: "List of AI-generated promotion suggestions based on the order items and available menu items";
                    readonly ofEntity: "OrderItem";
                }];
                readonly ports: readonly ["Order", "MenuItem"];
                readonly rulesApplied: readonly [];
                readonly transactional: false;
                readonly steps: readonly ["Load the Order aggregate by orderId via OrderPort (includes embedded OrderItems)", "Collect all menuItemIds from the order items", "Load referenced MenuItems via MenuItemPort to obtain names, prices, categories and status", "Filter MenuItems to only active ones for suggestion candidates", "Analyze current order items: quantities, categories, total amount, and item combinations", "Generate promotion suggestions (upsell, cross-sell, bundle, discount) based on order composition and available active menu items", "Return the orderId and the list of suggestions with suggested menu item, suggestion type, description, suggested price and discount percentage"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default aiPromotionSuggestionsUsecase;
    export const pipeline: readonly [{
        readonly id: "aiPromotionSuggestions__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/aiPromotionSuggestions.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/aiPromotionSuggestions.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/aiPromotionSuggestions" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export type PromotionSuggestionType = 'upsell' | 'crossSell' | 'bundle' | 'discount';
    export interface PromotionSuggestion {
        menuItemId: string;
        menuItemName: string;
        suggestionType: PromotionSuggestionType;
        description: string;
        originalPrice: number;
        suggestedPrice: number;
        discountPercentage: number;
    }
    export interface AiPromotionSuggestionsInput {
        orderId: string;
    }
    export interface AiPromotionSuggestionsOutput {
        orderId: string;
        suggestions: PromotionSuggestion[];
    }
    export function aiPromotionSuggestions(ctx: RequestContext, input: AiPromotionSuggestionsInput): Promise<AiPromotionSuggestionsOutput>;
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/aiSalesSummary.defs" {
    export const aiSalesSummaryUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "aiSalesSummary";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "aiSalesSummary";
            readonly ports: readonly ["Order", "DailyShift", "MenuItem"];
            readonly functions: readonly [{
                readonly functionName: "aiSalesSummary";
                readonly inputTypeName: "AiSalesSummaryInput";
                readonly outputTypeName: "AiSalesSummaryOutput";
                readonly input: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Filter summary to a specific daily shift";
                }, {
                    readonly name: "startDate";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Start date for the summary period (ISO date)";
                }, {
                    readonly name: "endDate";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "End date for the summary period (ISO date)";
                }, {
                    readonly name: "language";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Preferred output language for the AI-generated summary text (e.g. pt-BR, en-US)";
                }];
                readonly output: readonly [{
                    readonly name: "totalSales";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Sum of totalAmount across all closed orders in the period";
                }, {
                    readonly name: "totalOrders";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Count of orders included in the summary";
                }, {
                    readonly name: "totalCancelledOrders";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Count of cancelled orders in the period";
                }, {
                    readonly name: "averageOrderValue";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Average totalAmount per closed order";
                }, {
                    readonly name: "topSellingItems";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "JSON string listing top-selling menu items by quantity and revenue";
                }, {
                    readonly name: "salesByOrderType";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "JSON string with sales breakdown by order type (mesa vs takeout)";
                }, {
                    readonly name: "summaryText";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "AI-generated natural-language sales summary in the selected language";
                }, {
                    readonly name: "language";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "The language used for the AI summary text";
                }];
                readonly ports: readonly ["Order", "DailyShift", "MenuItem"];
                readonly rulesApplied: readonly ["aiOutputLanguageSelection"];
                readonly transactional: false;
                readonly steps: readonly ["1. Resolve the target period: if dailyShiftId is provided, load the DailyShift via DailyShiftPort to obtain shiftDate; otherwise use startDate/endDate (defaulting to today if both absent).", "2. Query all Order aggregates within the period via OrderPort, including embedded OrderItem children.", "3. Separate closed orders (status=closed) from cancelled orders (status=cancelled) for metric computation.", "4. Compute totalSales (sum of totalAmount on closed orders), totalOrders, totalCancelledOrders, and averageOrderValue.", "5. Aggregate OrderItem quantities grouped by menuItemId; load MenuItem names via MenuItemPort to build topSellingItems ranking.", "6. Break down sales by orderType (mesa vs takeout) into salesByOrderType.", "7. Apply rule aiOutputLanguageSelection: determine the output language from the language input field (default to pt-BR if not provided), and generate summaryText in that language.", "8. Return the assembled AiSalesSummaryOutput."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default aiSalesSummaryUsecase;
    export const pipeline: readonly [{
        readonly id: "aiSalesSummary__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/aiSalesSummary.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/aiSalesSummary.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/aiSalesSummary" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface AiSalesSummaryInput {
        dailyShiftId?: string;
        startDate?: string;
        endDate?: string;
        language?: string;
    }
    export interface AiSalesSummaryOutput {
        totalSales: number;
        totalOrders: number;
        totalCancelledOrders: number;
        averageOrderValue: number;
        topSellingItems: string;
        salesByOrderType: string;
        summaryText: string;
        language: string;
    }
    export function aiSalesSummary(ctx: RequestContext, input: AiSalesSummaryInput): Promise<AiSalesSummaryOutput>;
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/browseMenuForPos.defs" {
    export const browseMenuForPosUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "browseMenuForPos";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "browseMenuForPos";
            readonly ports: readonly ["MenuItem"];
            readonly functions: readonly [{
                readonly functionName: "browseMenuForPos";
                readonly inputTypeName: "BrowseMenuForPosInput";
                readonly outputTypeName: "BrowseMenuForPosOutput";
                readonly input: readonly [{
                    readonly name: "menuCategoryId";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Filter menu items by category id (optional)";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Filter by menu item status (e.g. 'active' for POS display)";
                }];
                readonly output: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "menuCategoryId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "categoryName";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuCategory";
                    readonly description: "Category name resolved from MDM MenuCategory";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                }];
                readonly ports: readonly ["MenuItem"];
                readonly rulesApplied: readonly ["aiOutputLanguageSelection"];
                readonly transactional: false;
                readonly steps: readonly ["1. Query MenuItem entities via MenuItem port, optionally filtered by menuCategoryId and status", "2. Collect distinct menuCategoryIds from the returned items", "3. For each distinct menuCategoryId, resolve MenuCategory from MDM via ctx.data.mdmDocument.get({ mdmId: menuCategoryId }) to obtain the category name", "4. Apply aiOutputLanguageSelection rule to select the appropriate language for display fields (name, description, categoryName)", "5. Return the enriched list of menu items with categoryName included"];
            }];
            readonly mdmRefs: readonly ["MenuCategory"];
        };
    };
    export default browseMenuForPosUsecase;
    export const pipeline: readonly [{
        readonly id: "browseMenuForPos__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/browseMenuForPos.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/browseMenuForPos.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/browseMenuForPos" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface BrowseMenuForPosInput {
        menuCategoryId?: string;
        status?: string;
    }
    export interface BrowseMenuForPosItem {
        menuItemId: string;
        menuCategoryId: string;
        categoryName: string;
        name: string;
        description?: string | null;
        price: number;
        status: string;
    }
    export interface BrowseMenuForPosOutput {
        items: BrowseMenuForPosItem[];
    }
    export function browseMenuForPos(ctx: RequestContext, input: BrowseMenuForPosInput): Promise<BrowseMenuForPosOutput>;
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/closeDailyShift.defs" {
    export const closeDailyShiftUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "closeDailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "closeDailyShift";
            readonly ports: readonly ["DailyShift"];
            readonly functions: readonly [{
                readonly functionName: "closeDailyShift";
                readonly inputTypeName: "CloseDailyShiftInput";
                readonly outputTypeName: "CloseDailyShiftOutput";
                readonly input: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "closingNotes";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "DailyShift";
                }];
                readonly output: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "closedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "openingCashBalance";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "closingCashBalance";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "totalSales";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "totalPayments";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "closingNotes";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "DailyShift";
                }];
                readonly ports: readonly ["DailyShift"];
                readonly rulesApplied: readonly ["SHIFT_MUST_BE_OPEN", "CLOSING_BALANCE_CALCULATED_FROM_CASH_MOVEMENTS", "CLOSED_AT_SET_TO_CURRENT_TIMESTAMP"];
                readonly transactional: true;
                readonly steps: readonly ["Load DailyShift by dailyShiftId via DailyShiftPort.findById", "Validate shift.status === 'open' (SHIFT_MUST_BE_OPEN)", "Load all CashMovements embedded in the DailyShift aggregate for dailyShiftId", "Calculate totalCashIn = sum of CashMovement.amount where movementType === 'entrada'", "Calculate totalCashOut = sum of CashMovement.amount where movementType === 'saída'", "Calculate closingCashBalance = openingCashBalance + totalCashIn - totalCashOut (CLOSING_BALANCE_CALCULATED_FROM_CASH_MOVEMENTS)", "Set shift.status = 'closed'", "Set shift.closedAt = current timestamp (CLOSED_AT_SET_TO_CURRENT_TIMESTAMP)", "Set shift.closingCashBalance = calculated value", "Set shift.closingNotes = provided closingNotes if present", "Save DailyShift via DailyShiftPort.save", "Return updated shift summary"];
            }, {
                readonly functionName: "previewDailyShiftClosure";
                readonly inputTypeName: "PreviewDailyShiftClosureInput";
                readonly outputTypeName: "PreviewDailyShiftClosureOutput";
                readonly input: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }];
                readonly output: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "shiftDate";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "openingCashBalance";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "totalCashIn";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "CashMovement";
                }, {
                    readonly name: "totalCashOut";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "CashMovement";
                }, {
                    readonly name: "projectedClosingBalance";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "totalSales";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "totalPayments";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }];
                readonly ports: readonly ["DailyShift"];
                readonly rulesApplied: readonly ["SHIFT_MUST_BE_OPEN", "CLOSING_BALANCE_CALCULATED_FROM_CASH_MOVEMENTS"];
                readonly transactional: false;
                readonly steps: readonly ["Load DailyShift by dailyShiftId via DailyShiftPort.findById", "Validate shift.status === 'open' (SHIFT_MUST_BE_OPEN)", "Load all CashMovements embedded in the DailyShift aggregate for dailyShiftId", "Calculate totalCashIn = sum of CashMovement.amount where movementType === 'entrada'", "Calculate totalCashOut = sum of CashMovement.amount where movementType === 'saída'", "Calculate projectedClosingBalance = openingCashBalance + totalCashIn - totalCashOut (CLOSING_BALANCE_CALCULATED_FROM_CASH_MOVEMENTS)", "Return preview summary without mutating the shift"];
            }];
            readonly rulesApplied: readonly ["SHIFT_MUST_BE_OPEN", "CLOSING_BALANCE_CALCULATED_FROM_CASH_MOVEMENTS", "CLOSED_AT_SET_TO_CURRENT_TIMESTAMP"];
            readonly mdmRefs: readonly [];
        };
    };
    export default closeDailyShiftUsecase;
    export const pipeline: readonly [{
        readonly id: "closeDailyShift__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/closeDailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/closeDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["SHIFT_MUST_BE_OPEN", "CLOSING_BALANCE_CALCULATED_FROM_CASH_MOVEMENTS", "CLOSED_AT_SET_TO_CURRENT_TIMESTAMP"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/closeDailyShift" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CloseDailyShiftInput {
        dailyShiftId: string;
        closingNotes?: string;
    }
    export interface CloseDailyShiftOutput {
        dailyShiftId: string;
        status: string;
        closedAt: string;
        openingCashBalance: number;
        closingCashBalance: number;
        totalSales: number;
        totalPayments: number;
        closingNotes?: string;
    }
    export interface PreviewDailyShiftClosureInput {
        dailyShiftId: string;
    }
    export interface PreviewDailyShiftClosureOutput {
        dailyShiftId: string;
        shiftDate: string;
        status: string;
        openingCashBalance: number;
        totalCashIn: number;
        totalCashOut: number;
        projectedClosingBalance: number;
        totalSales: number;
        totalPayments: number;
    }
    export function closeDailyShift(ctx: RequestContext, input: CloseDailyShiftInput): Promise<CloseDailyShiftOutput>;
    export function previewDailyShiftClosure(ctx: RequestContext, input: PreviewDailyShiftClosureInput): Promise<PreviewDailyShiftClosureOutput>;
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/consumeIngredientsOnConfirmation.defs" {
    export const consumeIngredientsOnConfirmationUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "consumeIngredientsOnConfirmation";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "consumeIngredientsOnConfirmation";
            readonly ports: readonly ["Order", "InventoryItem", "MenuItem"];
            readonly functions: readonly [{
                readonly functionName: "consumeIngredientsOnConfirmation";
                readonly inputTypeName: "ConsumeIngredientsOnConfirmationInput";
                readonly outputTypeName: "ConsumeIngredientsOnConfirmationOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "The order whose ingredients should be consumed upon confirmation";
                }, {
                    readonly name: "confirmedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Timestamp at which the confirmation/consumption occurs";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "The confirmed order id";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Result status of the consumption operation";
                }, {
                    readonly name: "stockConsumptionIds";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockConsumption";
                    readonly description: "Ids of the StockConsumption records created";
                }, {
                    readonly name: "updatedInventoryItemIds";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "InventoryItem";
                    readonly description: "Ids of InventoryItems whose quantity was decremented";
                }, {
                    readonly name: "consumedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Timestamp when consumption was posted";
                }, {
                    readonly name: "belowMinimumInventoryItemIds";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "InventoryItem";
                    readonly description: "Inventory item ids that fell below their minimum level after consumption";
                }];
                readonly ports: readonly ["Order", "InventoryItem", "MenuItem"];
                readonly rulesApplied: readonly ["order-must-exist", "order-items-must-be-in-confirmable-status", "recipe-components-resolved-per-menu-item", "required-quantity-equals-recipe-component-quantity-times-order-item-quantity", "inventory-must-have-sufficient-stock", "stock-consumption-created-per-component-per-order-item", "inventory-quantity-decremented-by-consumed-amount", "flag-inventory-below-minimum-level"];
                readonly transactional: true;
                readonly steps: readonly ["Load the Order aggregate by orderId via Order port; validate it exists and its order items are in a confirmable status (sentToKitchen, inPreparation, or ready)", "For each OrderItem in the order, load the MenuItem aggregate by menuItemId via MenuItem port to retrieve its RecipeComponent collection", "For each RecipeComponent, compute requiredQuantity = recipeComponent.quantity × orderItem.quantity", "Load the InventoryItem by recipeComponent.inventoryItemId via InventoryItem port; validate currentQuantity >= requiredQuantity; collect any that would fall below minimumLevel", "Create a StockConsumption record (status=posted, consumedAt=confirmedAt) for each component-orderItem pair and embed it in the Order aggregate", "Decrement each InventoryItem.currentQuantity by the consumed amount and save via InventoryItem port", "Save the Order aggregate (with new StockConsumption records and updated OrderItem statuses) via Order port", "Return orderId, status, stockConsumptionIds, updatedInventoryItemIds, consumedAt, and belowMinimumInventoryItemIds"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default consumeIngredientsOnConfirmationUsecase;
    export const pipeline: readonly [{
        readonly id: "consumeIngredientsOnConfirmation__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/consumeIngredientsOnConfirmation.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/consumeIngredientsOnConfirmation.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/createDailyShift.defs" {
    export const createDailyShiftUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createDailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createDailyShift";
            readonly ports: readonly ["DailyShift"];
            readonly functions: readonly [{
                readonly functionName: "createDailyShift";
                readonly inputTypeName: "CreateDailyShiftInput";
                readonly outputTypeName: "CreateDailyShiftOutput";
                readonly input: readonly [{
                    readonly name: "shiftDate";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "The calendar date the shift belongs to (ISO date)";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Initial shift status: 'open' or 'closed'";
                }, {
                    readonly name: "openedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Timestamp when the shift was opened (ISO datetime)";
                }, {
                    readonly name: "closedAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Timestamp when the shift was closed (ISO datetime)";
                }, {
                    readonly name: "openingCashBalance";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Cash float counted at shift opening";
                }, {
                    readonly name: "closingCashBalance";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Cash float counted at shift closing";
                }, {
                    readonly name: "totalSales";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Accumulated sales total for the shift";
                }, {
                    readonly name: "totalPayments";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Accumulated payments total for the shift";
                }, {
                    readonly name: "closingNotes";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Free-text notes recorded at closing";
                }];
                readonly output: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "The id of the newly created daily shift";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "The status of the created shift ('open' or 'closed')";
                }];
                readonly ports: readonly ["DailyShift"];
                readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
                readonly transactional: true;
                readonly steps: readonly ["1. Load existing DailyShift records for the given shiftDate via DailyShift port to check for duplicates", "2. Validate that no open shift already exists for the same shiftDate — reject if a shift with status 'open' is found", "3. Apply paymentTimingByOrderType rule to set default payment timing expectations on the new shift", "4. Apply aiOutputLanguageSelection rule to determine the language for any AI-generated shift summaries", "5. Create a new DailyShift aggregate with the provided fields, generating dailyShiftId, createdAt, and updatedAt server-side", "6. Set initial status to 'open' unless 'closed' is explicitly provided with a valid closedAt timestamp", "7. Save the DailyShift aggregate via the DailyShift port", "8. Return the dailyShiftId and status of the created shift"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default createDailyShiftUsecase;
    export const pipeline: readonly [{
        readonly id: "createDailyShift__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createDailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/createKitchenTicket.defs" {
    export const createKitchenTicketUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createKitchenTicket";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createKitchenTicket";
            readonly ports: readonly ["Order"];
            readonly functions: readonly [{
                readonly functionName: "createKitchenTicket";
                readonly inputTypeName: "CreateKitchenTicketInput";
                readonly outputTypeName: "CreateKitchenTicketOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "ID of the Order for which a kitchen ticket is created";
                }];
                readonly output: readonly [{
                    readonly name: "kitchenTicketId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "KitchenTicket";
                    readonly description: "Generated ID of the new KitchenTicket";
                }, {
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "ID of the parent Order";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "KitchenTicket";
                    readonly description: "Initial status of the KitchenTicket (open)";
                }, {
                    readonly name: "orderStatus";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Updated status of the Order after kitchen ticket creation (sentToKitchen)";
                }];
                readonly ports: readonly ["Order"];
                readonly rulesApplied: readonly ["orderStatusTransitions"];
                readonly transactional: true;
                readonly steps: readonly ["Load the Order aggregate by orderId via OrderPort.findById", "Validate that the Order exists and its current status allows transition to 'sentToKitchen' per orderStatusTransitions rule (e.g. from 'draft')", "Validate that the Order does not already have a kitchenTicketId assigned", "Create a new KitchenTicket embedded in the Order aggregate: generate kitchenTicketId, set status to 'open', set createdAt and updatedAt to current timestamp", "Set order.kitchenTicketId to the new kitchen ticket id", "Transition Order.status to 'sentToKitchen' per orderStatusTransitions rule", "Update Order.updatedAt to current timestamp", "Save the Order aggregate via OrderPort.save", "Return kitchenTicketId, orderId, kitchen ticket status, and updated order status"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default createKitchenTicketUsecase;
    export const pipeline: readonly [{
        readonly id: "createKitchenTicket__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createKitchenTicket.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createKitchenTicket.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/createOrder.defs" {
    export const createOrderUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createOrder";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createOrder";
            readonly ports: readonly ["Order", "DailyShift"];
            readonly functions: readonly [{
                readonly functionName: "createOrder";
                readonly inputTypeName: "CreateOrderInput";
                readonly outputTypeName: "CreateOrderOutput";
                readonly input: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                    readonly description: "The open daily shift under which the order is created";
                }, {
                    readonly name: "tableId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Table";
                    readonly description: "Required when orderType is 'mesa'; references the Table master-data document";
                }, {
                    readonly name: "orderType";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Order type: 'mesa' (dine-in) or 'takeout'";
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Free-text notes for the order";
                }, {
                    readonly name: "customerName";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Customer name (optional, used mainly for takeout)";
                }, {
                    readonly name: "customerPhone";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Customer phone (optional, used mainly for takeout)";
                }, {
                    readonly name: "numberOfGuests";
                    readonly type: "number";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Number of guests at the table (optional, used mainly for mesa)";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "The newly created order identifier";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Initial status of the order, always 'draft' on creation";
                }, {
                    readonly name: "totalAmount";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Initial total amount, always 0 on creation";
                }, {
                    readonly name: "tableStatus";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Table";
                    readonly description: "Updated table status ('occupied') when orderType is 'mesa'";
                }];
                readonly ports: readonly ["Order", "DailyShift"];
                readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "aiOutputLanguageSelection", "tableOccupancyConsistency"];
                readonly transactional: true;
                readonly steps: readonly ["1. Load DailyShift via DailyShift port by dailyShiftId; validate that shift status is 'open' — reject if closed or not found.", "2. If orderType is 'mesa': require tableId (reject if missing); read Table master-data document via ctx.data.mdmDocument.get({ mdmId: tableId }); validate table status is 'available' (tableOccupancyConsistency) — reject if 'occupied' or 'disabled'.", "3. If orderType is 'takeout': tableId must be null; skip table validation.", "4. Create new Order aggregate with status='draft' (orderStatusTransitions initial state), totalAmount=0, kitchenTicketId=null, closedAt=null, cancelledAt=null; set createdAt/updatedAt to server timestamp.", "5. Apply paymentTimingByOrderType: for 'takeout' payment is expected immediately; for 'mesa' payment is deferred until close — store this expectation as order metadata.", "6. Apply aiOutputLanguageSelection: determine the language for AI-generated kitchen ticket output based on shift or tenant configuration.", "7. ingredientConsumptionTrigger is registered but not fired on create — it fires when status transitions to 'sentToKitchen'.", "8. Save Order via Order port.", "9. If orderType is 'mesa': update Table master-data document status to 'occupied' (tableOccupancyConsistency) and persist via ctx.data.mdmDocument update.", "10. Return orderId, status, totalAmount, and tableStatus (if applicable)."];
            }];
            readonly mdmRefs: readonly ["Table"];
        };
    };
    export default createOrderUsecase;
    export const pipeline: readonly [{
        readonly id: "createOrder__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createOrder.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createOrder.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/createOrder" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CreateOrderInput {
        dailyShiftId: string;
        tableId?: string;
        orderType: string;
        notes?: string;
        customerName?: string;
        customerPhone?: string;
        numberOfGuests?: number;
    }
    export interface CreateOrderOutput {
        orderId: string;
        status: string;
        totalAmount: number;
        tableStatus?: string;
    }
    export function createOrder(ctx: RequestContext, input: CreateOrderInput): Promise<CreateOrderOutput>;
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/createStockConsumption.defs" {
    export const createStockConsumptionUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createStockConsumption";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createStockConsumption";
            readonly ports: readonly ["Order", "MenuItem", "InventoryItem"];
            readonly functions: readonly [{
                readonly functionName: "createStockConsumption";
                readonly inputTypeName: "CreateStockConsumptionInput";
                readonly outputTypeName: "CreateStockConsumptionOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "The order containing the item that triggered stock consumption";
                }, {
                    readonly name: "orderItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "OrderItem";
                    readonly description: "The order item whose menu item recipe components will be consumed";
                }];
                readonly output: readonly [{
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Overall result status: 'posted' when all consumption records are created successfully";
                }, {
                    readonly name: "stockConsumptionCount";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Number of StockConsumption records created (one per recipe component)";
                }, {
                    readonly name: "inventoryItemIds";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "InventoryItem";
                    readonly description: "Comma-separated list of InventoryItem ids whose stock was decremented";
                }];
                readonly ports: readonly ["Order", "MenuItem", "InventoryItem"];
                readonly rulesApplied: readonly ["ingredientConsumptionTrigger"];
                readonly transactional: true;
                readonly steps: readonly ["1. Load Order by orderId via Order port; validate order exists and status is not 'cancelled'", "2. Find the OrderItem by orderItemId within the Order's items collection; validate it exists and status is 'served' or 'ready'", "3. Load MenuItem by orderItem.menuItemId via MenuItem port; validate menuItem status is 'active'", "4. Retrieve RecipeComponents from the MenuItem aggregate (each has inventoryItemId and quantity per unit)", "5. For each RecipeComponent calculate consumedQuantity = recipeComponent.quantity * orderItem.quantity", "6. Load InventoryItem by recipeComponent.inventoryItemId via InventoryItem port; validate status is 'active' and currentQuantity >= consumedQuantity", "7. Decrement InventoryItem.currentQuantity by consumedQuantity; save InventoryItem via InventoryItem port", "8. Create StockConsumption record: inventoryItemId, orderItemId, quantity=consumedQuantity, status='posted', consumedAt=now; save via StockConsumption port", "9. Repeat steps 6-8 for every recipe component", "10. Return status='posted', stockConsumptionCount, and affected inventoryItemIds"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default createStockConsumptionUsecase;
    export const pipeline: readonly [{
        readonly id: "createStockConsumption__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createStockConsumption.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createStockConsumption.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/createStockConsumption" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CreateStockConsumptionInput {
        orderId: string;
        orderItemId: string;
    }
    export interface CreateStockConsumptionOutput {
        status: string;
        stockConsumptionCount: number;
        inventoryItemIds: string;
    }
    export function createStockConsumption(ctx: RequestContext, input: CreateStockConsumptionInput): Promise<CreateStockConsumptionOutput>;
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/dineInOrderLifecycle.defs" {
    export const dineInOrderLifecycleUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "dineInOrderLifecycle";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "dineInOrderLifecycle";
            readonly ports: readonly ["Order"];
            readonly functions: readonly [{
                readonly functionName: "sendToKitchen";
                readonly inputTypeName: "SendToKitchenInput";
                readonly outputTypeName: "SendToKitchenOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "tableId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Table";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "kitchenTicketId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "KitchenTicket";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }];
                readonly ports: readonly ["Order"];
                readonly rulesApplied: readonly ["order-status-transition-draft-to-sentToKitchen", "kitchen-ticket-created-on-send", "order-items-status-synced-on-send", "table-marked-occupied-on-send"];
                readonly transactional: true;
                readonly steps: readonly ["Load Order aggregate by orderId via Order port", "Validate order.status === 'draft'", "Validate order.orderType === 'mesa' and tableId is present for dine-in", "Read Table master data via ctx.data.mdmDocument.get({ mdmId: tableId }) and validate table.status === 'available'", "Create KitchenTicket embedded in Order aggregate with status 'open'", "Set order.kitchenTicketId to new ticket id", "Set order.status to 'sentToKitchen'", "Set all OrderItem.status to 'sentToKitchen' and link each to kitchenTicketId", "Update Table master data status to 'occupied' via ctx.data.mdmDocument", "Save Order aggregate via Order port"];
            }, {
                readonly functionName: "markOrderReady";
                readonly inputTypeName: "MarkOrderReadyInput";
                readonly outputTypeName: "MarkOrderReadyOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "kitchenTicketStatus";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "KitchenTicket";
                }];
                readonly ports: readonly ["Order"];
                readonly rulesApplied: readonly ["order-status-transition-sentToKitchen-or-inPreparation-to-ready", "kitchen-ticket-status-to-done", "order-items-status-synced-to-ready"];
                readonly transactional: true;
                readonly steps: readonly ["Load Order aggregate by orderId via Order port", "Validate order.status is 'sentToKitchen' or 'inPreparation'", "Set KitchenTicket.status to 'done'", "Set order.status to 'ready'", "Set all OrderItem.status to 'ready'", "Save Order aggregate via Order port"];
            }, {
                readonly functionName: "serveOrder";
                readonly inputTypeName: "ServeOrderInput";
                readonly outputTypeName: "ServeOrderOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }];
                readonly ports: readonly ["Order"];
                readonly rulesApplied: readonly ["order-status-transition-ready-to-served", "order-items-status-synced-to-served"];
                readonly transactional: true;
                readonly steps: readonly ["Load Order aggregate by orderId via Order port", "Validate order.status === 'ready'", "Set order.status to 'served'", "Set all OrderItem.status to 'served'", "Save Order aggregate via Order port"];
            }, {
                readonly functionName: "closeOrder";
                readonly inputTypeName: "CloseOrderInput";
                readonly outputTypeName: "CloseOrderOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "tableId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Table";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "closedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }];
                readonly ports: readonly ["Order"];
                readonly rulesApplied: readonly ["order-status-transition-served-to-closed", "table-freed-on-close", "closedAt-set-on-close"];
                readonly transactional: true;
                readonly steps: readonly ["Load Order aggregate by orderId via Order port", "Validate order.status === 'served'", "Set order.status to 'closed'", "Set order.closedAt to current datetime", "If order.orderType === 'mesa' and tableId present, update Table master data status to 'available' via ctx.data.mdmDocument", "Save Order aggregate via Order port"];
            }, {
                readonly functionName: "cancelOrder";
                readonly inputTypeName: "CancelOrderInput";
                readonly outputTypeName: "CancelOrderOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "cancellationReason";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "tableId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Table";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "cancelledAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }];
                readonly ports: readonly ["Order"];
                readonly rulesApplied: readonly ["order-cancel-not-allowed-if-closed-or-cancelled", "kitchen-ticket-voided-on-cancel", "order-items-cancelled-on-cancel", "table-freed-on-cancel"];
                readonly transactional: true;
                readonly steps: readonly ["Load Order aggregate by orderId via Order port", "Validate order.status is not 'closed' and not 'cancelled'", "Set order.status to 'cancelled'", "Set order.cancelledAt to current datetime", "Set order.cancellationReason if provided", "If KitchenTicket exists, set KitchenTicket.status to 'void'", "Set all OrderItem.status to 'cancelled'", "If order.orderType === 'mesa' and tableId present, update Table master data status to 'available' via ctx.data.mdmDocument", "Save Order aggregate via Order port"];
            }];
            readonly mdmRefs: readonly ["Table"];
        };
    };
    export default dineInOrderLifecycleUsecase;
    export const pipeline: readonly [{
        readonly id: "dineInOrderLifecycle__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/dineInOrderLifecycle.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/dineInOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/dineInOrderLifecycle" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface SendToKitchenInput {
        orderId: string;
        tableId?: string;
    }
    export interface SendToKitchenOutput {
        orderId: string;
        kitchenTicketId: string;
        status: string;
    }
    export function sendToKitchen(ctx: RequestContext, input: SendToKitchenInput): Promise<SendToKitchenOutput>;
    export interface MarkOrderReadyInput {
        orderId: string;
    }
    export interface MarkOrderReadyOutput {
        orderId: string;
        status: string;
        kitchenTicketStatus: string;
    }
    export function markOrderReady(ctx: RequestContext, input: MarkOrderReadyInput): Promise<MarkOrderReadyOutput>;
    export interface ServeOrderInput {
        orderId: string;
    }
    export interface ServeOrderOutput {
        orderId: string;
        status: string;
    }
    export function serveOrder(ctx: RequestContext, input: ServeOrderInput): Promise<ServeOrderOutput>;
    export interface CloseOrderInput {
        orderId: string;
        tableId?: string;
    }
    export interface CloseOrderOutput {
        orderId: string;
        status: string;
        closedAt: string;
    }
    export function closeOrder(ctx: RequestContext, input: CloseOrderInput): Promise<CloseOrderOutput>;
    export interface CancelOrderInput {
        orderId: string;
        cancellationReason?: string;
        tableId?: string;
    }
    export interface CancelOrderOutput {
        orderId: string;
        status: string;
        cancelledAt: string;
    }
    export function cancelOrder(ctx: RequestContext, input: CancelOrderInput): Promise<CancelOrderOutput>;
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/generateShiftCloseReport.defs" {
    export const generateShiftCloseReportUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "generateShiftCloseReport";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "generateShiftCloseReport";
            readonly ports: readonly ["DailyShift", "Payment", "Order"];
            readonly functions: readonly [{
                readonly functionName: "generateShiftCloseReport";
                readonly inputTypeName: "GenerateShiftCloseReportInput";
                readonly outputTypeName: "ShiftCloseReportOutput";
                readonly input: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                    readonly description: "ID of the daily shift to generate the close report for";
                }, {
                    readonly name: "outputLanguage";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Preferred language for AI-generated report narrative (applies aiOutputLanguageSelection rule)";
                }];
                readonly output: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                    readonly description: "ID of the reported daily shift";
                }, {
                    readonly name: "shiftDate";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                    readonly description: "Date of the shift";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                    readonly description: "Current status of the shift (open or closed)";
                }, {
                    readonly name: "openedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                    readonly description: "Timestamp when the shift was opened";
                }, {
                    readonly name: "closedAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "DailyShift";
                    readonly description: "Timestamp when the shift was closed, if applicable";
                }, {
                    readonly name: "openingCashBalance";
                    readonly type: "number";
                    readonly required: false;
                    readonly ofEntity: "DailyShift";
                    readonly description: "Cash balance at shift opening";
                }, {
                    readonly name: "closingCashBalance";
                    readonly type: "number";
                    readonly required: false;
                    readonly ofEntity: "DailyShift";
                    readonly description: "Cash balance at shift closing";
                }, {
                    readonly name: "totalSales";
                    readonly type: "number";
                    readonly required: false;
                    readonly ofEntity: "DailyShift";
                    readonly description: "Total sales amount for the shift";
                }, {
                    readonly name: "totalPayments";
                    readonly type: "number";
                    readonly required: false;
                    readonly ofEntity: "DailyShift";
                    readonly description: "Total payments captured for the shift";
                }, {
                    readonly name: "closingNotes";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "DailyShift";
                    readonly description: "Notes recorded at shift closing";
                }, {
                    readonly name: "totalOrders";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Count of all orders in the shift";
                }, {
                    readonly name: "ordersByType";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "JSON breakdown of order counts and totals by orderType (mesa/takeout), applying paymentTimingByOrderType rule";
                }, {
                    readonly name: "paymentsByMethod";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "JSON breakdown of captured payments grouped by payment method with totals";
                }, {
                    readonly name: "paymentsByOrderType";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "JSON breakdown of payments categorized by associated order type, applying paymentTimingByOrderType rule";
                }, {
                    readonly name: "cashMovementsSummary";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "JSON summary of cash movements (entrada/saída) with totals, read via DailyShift aggregate children";
                }, {
                    readonly name: "orderItemsSummary";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "JSON summary of order items (top items, quantities, revenue) read via Order aggregate children";
                }, {
                    readonly name: "reportLanguage";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Language selected for the report narrative, applying aiOutputLanguageSelection rule";
                }, {
                    readonly name: "reportNarrative";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "AI-generated narrative summary of the shift in the selected language";
                }];
                readonly ports: readonly ["DailyShift", "Payment", "Order"];
                readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
                readonly transactional: false;
                readonly steps: readonly ["1. Load DailyShift by dailyShiftId via DailyShift port (including embedded CashMovement children)", "2. Validate that the DailyShift exists; if status is 'open', include a warning in the report that the shift is not yet closed", "3. Load all Orders for the shift via Order port filtered by dailyShiftId (including embedded OrderItem children)", "4. Load all Payments for the shift via Payment port filtered by dailyShiftId", "5. Apply paymentTimingByOrderType rule: categorize each payment by the orderType of its associated Order (mesa vs takeout) and compute timing metrics (when payment was captured relative to order lifecycle)", "6. Aggregate payments by method (cash, card, etc.) with captured amounts only (exclude voided/refunded)", "7. Aggregate orders by type (mesa/takeout) with counts and total amounts", "8. Summarize cash movements (entrada/saída) from the DailyShift aggregate children", "9. Summarize order items from Order aggregate children (top-selling items, total quantities, revenue)", "10. Apply aiOutputLanguageSelection rule: determine the output language from the input preference or default, and generate a narrative summary of the shift in that language", "11. Assemble and return the complete ShiftCloseReportOutput with all aggregated sections"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default generateShiftCloseReportUsecase;
    export const pipeline: readonly [{
        readonly id: "generateShiftCloseReport__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/generateShiftCloseReport.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/generateShiftCloseReport.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/kitchenProductionFlow.defs" {
    export const kitchenProductionFlowUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "kitchenProductionFlow";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "kitchenProductionFlow";
            readonly ports: readonly ["Order"];
            readonly functions: readonly [{
                readonly functionName: "sendToKitchen";
                readonly inputTypeName: "SendToKitchenInput";
                readonly outputTypeName: "SendToKitchenOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "The order whose items are to be sent to the kitchen";
                }];
                readonly output: readonly [{
                    readonly name: "kitchenTicketId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "KitchenTicket";
                    readonly description: "The newly created kitchen ticket id";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "The kitchen ticket status after creation (open)";
                }];
                readonly ports: readonly ["Order"];
                readonly rulesApplied: readonly ["Only order items with status 'new' are eligible to be sent to kitchen", "A kitchen ticket is created with status 'open' and linked to the order", "Eligible order items are linked to the kitchen ticket and transitioned to 'sentToKitchen'", "At least one eligible order item must exist to create a kitchen ticket"];
                readonly transactional: true;
                readonly steps: readonly ["Load Order aggregate via Order port by orderId", "Validate that at least one OrderItem has status 'new'", "Create a KitchenTicket with status 'open' and generate kitchenTicketId", "Link eligible OrderItems (status 'new') to the kitchenTicketId and set their status to 'sentToKitchen'", "Save Order aggregate via Order port", "Return kitchenTicketId and status"];
            }, {
                readonly functionName: "startPreparation";
                readonly inputTypeName: "StartPreparationInput";
                readonly outputTypeName: "StartPreparationOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "The order containing the kitchen ticket";
                }, {
                    readonly name: "kitchenTicketId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "KitchenTicket";
                    readonly description: "The kitchen ticket to start preparing";
                }];
                readonly output: readonly [{
                    readonly name: "kitchenTicketId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "KitchenTicket";
                    readonly description: "The kitchen ticket id that was updated";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "The kitchen ticket status after update (inProgress)";
                }];
                readonly ports: readonly ["Order"];
                readonly rulesApplied: readonly ["Kitchen ticket must be in status 'open' to start preparation", "Kitchen ticket status transitions from 'open' to 'inProgress'", "All OrderItems linked to the kitchen ticket with status 'sentToKitchen' transition to 'inPreparation'"];
                readonly transactional: true;
                readonly steps: readonly ["Load Order aggregate via Order port by orderId", "Find KitchenTicket by kitchenTicketId within the Order", "Validate kitchen ticket status is 'open'", "Transition kitchen ticket status to 'inProgress'", "Transition all linked OrderItems from 'sentToKitchen' to 'inPreparation'", "Save Order aggregate via Order port", "Return kitchenTicketId and status"];
            }, {
                readonly functionName: "markReady";
                readonly inputTypeName: "MarkReadyInput";
                readonly outputTypeName: "MarkReadyOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "The order containing the kitchen ticket";
                }, {
                    readonly name: "kitchenTicketId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "KitchenTicket";
                    readonly description: "The kitchen ticket to mark as ready";
                }];
                readonly output: readonly [{
                    readonly name: "kitchenTicketId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "KitchenTicket";
                    readonly description: "The kitchen ticket id that was updated";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "The kitchen ticket status after update (done)";
                }];
                readonly ports: readonly ["Order"];
                readonly rulesApplied: readonly ["Kitchen ticket must be in status 'inProgress' to mark as ready", "Kitchen ticket status transitions from 'inProgress' to 'done'", "All OrderItems linked to the kitchen ticket with status 'inPreparation' transition to 'ready'"];
                readonly transactional: true;
                readonly steps: readonly ["Load Order aggregate via Order port by orderId", "Find KitchenTicket by kitchenTicketId within the Order", "Validate kitchen ticket status is 'inProgress'", "Transition kitchen ticket status to 'done'", "Transition all linked OrderItems from 'inPreparation' to 'ready'", "Save Order aggregate via Order port", "Return kitchenTicketId and status"];
            }, {
                readonly functionName: "voidKitchenTicket";
                readonly inputTypeName: "VoidKitchenTicketInput";
                readonly outputTypeName: "VoidKitchenTicketOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "The order containing the kitchen ticket";
                }, {
                    readonly name: "kitchenTicketId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "KitchenTicket";
                    readonly description: "The kitchen ticket to void";
                }, {
                    readonly name: "reason";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Optional reason for voiding the kitchen ticket";
                }];
                readonly output: readonly [{
                    readonly name: "kitchenTicketId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "KitchenTicket";
                    readonly description: "The voided kitchen ticket id";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "The kitchen ticket status after void (void)";
                }];
                readonly ports: readonly ["Order"];
                readonly rulesApplied: readonly ["Kitchen ticket must not already be in status 'done' or 'void' to be voided", "Kitchen ticket status transitions to 'void'", "All OrderItems linked to the kitchen ticket that are not yet 'served' or 'cancelled' are transitioned to 'cancelled'"];
                readonly transactional: true;
                readonly steps: readonly ["Load Order aggregate via Order port by orderId", "Find KitchenTicket by kitchenTicketId within the Order", "Validate kitchen ticket status is not 'done' or 'void'", "Transition kitchen ticket status to 'void'", "Transition all linked OrderItems that are not 'served' or 'cancelled' to 'cancelled'", "Save Order aggregate via Order port", "Return kitchenTicketId and status"];
            }, {
                readonly functionName: "queryKitchenTicketsByOrder";
                readonly inputTypeName: "QueryKitchenTicketsByOrderInput";
                readonly outputTypeName: "QueryKitchenTicketsByOrderOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "The order to query kitchen tickets for";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Optional filter by kitchen ticket status";
                }];
                readonly output: readonly [{
                    readonly name: "kitchenTickets";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "KitchenTicket";
                    readonly description: "List of kitchen ticket ids matching the filter";
                }, {
                    readonly name: "statuses";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Corresponding statuses for each kitchen ticket";
                }];
                readonly ports: readonly ["Order"];
                readonly rulesApplied: readonly ["Kitchen tickets are read from the Order aggregate", "Optional status filter narrows the result set"];
                readonly transactional: false;
                readonly steps: readonly ["Load Order aggregate via Order port by orderId", "Extract all KitchenTickets from the Order", "If status filter is provided, filter tickets by that status", "Return list of kitchenTicketIds and their statuses"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default kitchenProductionFlowUsecase;
    export const pipeline: readonly [{
        readonly id: "kitchenProductionFlow__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/kitchenProductionFlow.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/kitchenProductionFlow.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/manageInventoryItems.defs" {
    export const manageInventoryItemsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "manageInventoryItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "manageInventoryItems";
            readonly ports: readonly ["InventoryItem"];
            readonly functions: readonly [{
                readonly functionName: "updateInventoryItem";
                readonly inputTypeName: "UpdateInventoryItemInput";
                readonly outputTypeName: "UpdateInventoryItemOutput";
                readonly input: readonly [{
                    readonly name: "inventoryItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "InventoryItem";
                    readonly description: "Identifier of the inventory item to update";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "InventoryItem";
                    readonly description: "Updated name of the inventory item";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "InventoryItem";
                    readonly description: "Updated description";
                }, {
                    readonly name: "unit";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "InventoryItem";
                    readonly description: "Updated unit of measure";
                }, {
                    readonly name: "currentQuantity";
                    readonly type: "number";
                    readonly required: false;
                    readonly ofEntity: "InventoryItem";
                    readonly description: "Updated current quantity on hand";
                }, {
                    readonly name: "minimumLevel";
                    readonly type: "number";
                    readonly required: false;
                    readonly ofEntity: "InventoryItem";
                    readonly description: "Updated minimum stock threshold level";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "InventoryItem";
                    readonly description: "Updated status (active or inactive)";
                }];
                readonly output: readonly [{
                    readonly name: "inventoryItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "InventoryItem";
                    readonly description: "Identifier of the updated inventory item";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "InventoryItem";
                    readonly description: "Name of the updated inventory item";
                }, {
                    readonly name: "currentQuantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "InventoryItem";
                    readonly description: "Current quantity after update";
                }, {
                    readonly name: "minimumLevel";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "InventoryItem";
                    readonly description: "Minimum level after update";
                }, {
                    readonly name: "isLowStock";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly description: "Whether the item is below minimum stock threshold";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "InventoryItem";
                    readonly description: "Status of the inventory item after update";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "InventoryItem";
                    readonly description: "Timestamp of the update";
                }];
                readonly ports: readonly ["InventoryItem"];
                readonly rulesApplied: readonly ["inventoryLowStockThreshold"];
                readonly transactional: true;
                readonly steps: readonly ["Load InventoryItem by inventoryItemId via InventoryItem port", "Validate that the item exists and is not in a terminal state", "Apply provided field changes (name, description, unit, currentQuantity, minimumLevel, status) to the loaded aggregate", "Evaluate inventoryLowStockThreshold rule: if currentQuantity <= minimumLevel mark isLowStock true", "Save the updated InventoryItem aggregate via InventoryItem port", "Return updated item id, key fields, isLowStock flag, and updatedAt timestamp"];
            }, {
                readonly functionName: "adjustInventoryQuantity";
                readonly inputTypeName: "AdjustInventoryQuantityInput";
                readonly outputTypeName: "AdjustInventoryQuantityOutput";
                readonly input: readonly [{
                    readonly name: "inventoryItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "InventoryItem";
                    readonly description: "Identifier of the inventory item to adjust";
                }, {
                    readonly name: "quantityDelta";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Positive or negative quantity adjustment to apply";
                }];
                readonly output: readonly [{
                    readonly name: "inventoryItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "InventoryItem";
                    readonly description: "Identifier of the adjusted inventory item";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "InventoryItem";
                    readonly description: "Name of the adjusted inventory item";
                }, {
                    readonly name: "currentQuantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "InventoryItem";
                    readonly description: "Resulting quantity after adjustment";
                }, {
                    readonly name: "minimumLevel";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "InventoryItem";
                    readonly description: "Minimum stock threshold level";
                }, {
                    readonly name: "isLowStock";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly description: "Whether the item fell below minimum stock threshold";
                }, {
                    readonly name: "consumptionTriggered";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly description: "Whether ingredient consumption was triggered by this adjustment";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "InventoryItem";
                    readonly description: "Status of the inventory item after adjustment";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "InventoryItem";
                    readonly description: "Timestamp of the adjustment";
                }];
                readonly ports: readonly ["InventoryItem"];
                readonly rulesApplied: readonly ["inventoryLowStockThreshold", "ingredientConsumptionTrigger"];
                readonly transactional: true;
                readonly steps: readonly ["Load InventoryItem by inventoryItemId via InventoryItem port", "Validate that the item exists and status is active", "Compute new currentQuantity = currentQuantity + quantityDelta; reject if result is negative", "Apply ingredientConsumptionTrigger rule: if quantityDelta is negative (consumption), trigger ingredient consumption event", "Apply inventoryLowStockThreshold rule: if new currentQuantity <= minimumLevel mark isLowStock true", "Save the updated InventoryItem aggregate via InventoryItem port", "Return adjusted item id, name, new quantity, minimumLevel, isLowStock, consumptionTriggered, status, and updatedAt"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default manageInventoryItemsUsecase;
    export const pipeline: readonly [{
        readonly id: "manageInventoryItems__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageInventoryItems.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageInventoryItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuCategories.defs" {
    export const manageMenuCategoriesUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "manageMenuCategories";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "manageMenuCategories";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "updateMenuCategory";
                readonly inputTypeName: "UpdateMenuCategoryInput";
                readonly outputTypeName: "UpdateMenuCategoryOutput";
                readonly input: readonly [{
                    readonly name: "menuCategoryId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuCategory";
                    readonly description: "Identifier of the MenuCategory to update";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuCategory";
                    readonly description: "Updated category name";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "MenuCategory";
                    readonly description: "Updated category description";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuCategory";
                    readonly description: "Updated status (active or inactive)";
                }];
                readonly output: readonly [{
                    readonly name: "menuCategoryId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuCategory";
                    readonly description: "Identifier of the updated MenuCategory";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuCategory";
                    readonly description: "Confirmed status after update";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuCategory";
                    readonly description: "Timestamp of the update";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly [];
                readonly transactional: true;
                readonly steps: readonly ["Load MenuCategory by menuCategoryId via MenuCategory port", "Validate that the MenuCategory exists; throw not-found if absent", "Validate status is one of 'active' or 'inactive'", "Apply updated fields (name, description, status) to the MenuCategory aggregate", "Set updatedAt to the current server timestamp", "Save the MenuCategory aggregate via MenuCategory port", "Return menuCategoryId, status, and updatedAt"];
            }];
            readonly mdmRefs: readonly ["MenuCategory"];
        };
    };
    export default manageMenuCategoriesUsecase;
    export const pipeline: readonly [{
        readonly id: "manageMenuCategories__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuCategories.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuCategories.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuCategories" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface UpdateMenuCategoryInput {
        menuCategoryId: string;
        name: string;
        description?: string;
        status: string;
    }
    export interface UpdateMenuCategoryOutput {
        menuCategoryId: string;
        status: string;
        updatedAt: string;
    }
    export function updateMenuCategory(ctx: RequestContext, input: UpdateMenuCategoryInput): Promise<UpdateMenuCategoryOutput>;
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuItems.defs" {
    export const manageMenuItemsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "manageMenuItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "manageMenuItems";
            readonly ports: readonly ["MenuItem"];
            readonly functions: readonly [{
                readonly functionName: "updateMenuItem";
                readonly inputTypeName: "UpdateMenuItemInput";
                readonly outputTypeName: "UpdateMenuItemOutput";
                readonly input: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Identifier of the menu item to update";
                }, {
                    readonly name: "menuCategoryId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "MenuCategory";
                    readonly description: "Updated category reference (mdmRef) — validated against master data";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Updated display name of the menu item";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Updated description of the menu item";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: false;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Updated price of the menu item";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Updated lifecycle status: draft | active | inactive";
                }];
                readonly output: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Identifier of the updated menu item";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Result status of the update operation";
                }];
                readonly ports: readonly ["MenuItem"];
                readonly rulesApplied: readonly ["aiOutputLanguageSelection"];
                readonly transactional: true;
                readonly steps: readonly ["1. Load the MenuItem aggregate by menuItemId via MenuItemPort.findById; throw NotFound if missing.", "2. If menuCategoryId is provided, validate it exists in master data via ctx.data.mdmDocument.get({ mdmId: menuCategoryId }) and that the MenuCategory status is 'active'; throw InvalidMenuCategory otherwise.", "3. Apply the provided field changes (menuCategoryId, name, description, price, status) to the loaded MenuItem aggregate using its domain mutation methods.", "4. Validate the MenuItem invariants (e.g. price >= 0, status enum value) via the aggregate's validate() method.", "5. Persist the updated MenuItem aggregate via MenuItemPort.save.", "6. Return menuItemId and operation status."];
            }];
            readonly mdmRefs: readonly ["MenuCategory"];
        };
    };
    export default manageMenuItemsUsecase;
    export const pipeline: readonly [{
        readonly id: "manageMenuItems__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuItems.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/manageTables.defs" {
    export const manageTablesUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "manageTables";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "manageTables";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "updateTable";
                readonly inputTypeName: "UpdateTableInput";
                readonly outputTypeName: "UpdateTableOutput";
                readonly input: readonly [{
                    readonly name: "tableId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Identifier of the table to update";
                }, {
                    readonly name: "number";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Table";
                    readonly description: "Table number label";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Table";
                    readonly description: "Table status: active or inactive";
                }];
                readonly output: readonly [{
                    readonly name: "tableId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Identifier of the updated table";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Timestamp of the last update";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["table-must-exist", "at-least-one-field-must-be-provided", "status-must-be-valid-enum"];
                readonly transactional: true;
                readonly steps: readonly ["Load Table aggregate by tableId via TablePort", "Validate that at least one writable field (number or status) is provided", "If status is provided, validate it is one of: active, inactive", "Apply field changes to the Table aggregate", "Set updatedAt to current timestamp", "Save Table aggregate via TablePort", "Return tableId and updatedAt"];
            }, {
                readonly functionName: "changeTableStatus";
                readonly inputTypeName: "ChangeTableStatusInput";
                readonly outputTypeName: "ChangeTableStatusOutput";
                readonly input: readonly [{
                    readonly name: "tableId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Identifier of the table whose status will change";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "New status: active or inactive";
                }];
                readonly output: readonly [{
                    readonly name: "tableId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Identifier of the updated table";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "The new status applied";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Timestamp of the status change";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["table-must-exist", "status-must-be-valid-enum"];
                readonly transactional: true;
                readonly steps: readonly ["Load Table aggregate by tableId via TablePort", "Validate status is one of: active, inactive", "Apply new status to the Table aggregate", "Set updatedAt to current timestamp", "Save Table aggregate via TablePort", "Return tableId, status, and updatedAt"];
            }];
            readonly mdmRefs: readonly ["Table"];
        };
    };
    export default manageTablesUsecase;
    export const pipeline: readonly [{
        readonly id: "manageTables__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageTables.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageTables.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/openDailyShift.defs" {
    export const openDailyShiftUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "openDailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "openDailyShift";
            readonly ports: readonly ["DailyShift"];
            readonly functions: readonly [{
                readonly functionName: "openDailyShift";
                readonly inputTypeName: "OpenDailyShiftInput";
                readonly outputTypeName: "OpenDailyShiftOutput";
                readonly input: readonly [{
                    readonly name: "shiftDate";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Date of the shift to open (ISO date)";
                }, {
                    readonly name: "openingCashBalance";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Initial cash balance at shift open";
                }];
                readonly output: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Generated id of the newly opened DailyShift";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Status of the shift (always 'open' on creation)";
                }, {
                    readonly name: "openedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Timestamp when the shift was opened";
                }];
                readonly ports: readonly ["DailyShift"];
                readonly rulesApplied: readonly ["SHIFT-001: No duplicate open shift for the same shiftDate", "SHIFT-002: Opening cash balance must be >= 0", "SHIFT-003: Initial CashMovement of type 'entrada' recorded on shift open with reason 'Abertura de caixa'"];
                readonly transactional: true;
                readonly steps: readonly ["Query DailyShift port for any existing shift with status='open' for the given shiftDate; reject if found (SHIFT-001)", "Validate openingCashBalance >= 0 (SHIFT-002)", "Create DailyShift aggregate: status='open', openedAt=now, openingCashBalance, createdAt=now, updatedAt=now", "Create embedded CashMovement: movementType='entrada', amount=openingCashBalance, reason='Abertura de caixa', createdAt=now, updatedAt=now (SHIFT-003)", "Save DailyShift aggregate (with embedded CashMovement) via DailyShift port", "Return dailyShiftId, status, openedAt"];
            }, {
                readonly functionName: "findOpenShiftByDate";
                readonly inputTypeName: "FindOpenShiftByDateInput";
                readonly outputTypeName: "FindOpenShiftByDateOutput";
                readonly input: readonly [{
                    readonly name: "shiftDate";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Date to search for an open shift";
                }];
                readonly output: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Id of the open shift if found";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Status of the found shift";
                }, {
                    readonly name: "openedAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Timestamp when the shift was opened";
                }, {
                    readonly name: "openingCashBalance";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Opening cash balance of the found shift";
                }];
                readonly ports: readonly ["DailyShift"];
                readonly rulesApplied: readonly ["SHIFT-001: No duplicate open shift for the same shiftDate"];
                readonly transactional: false;
                readonly steps: readonly ["Query DailyShift port for a shift with status='open' matching the given shiftDate", "Return shift details if found, empty result otherwise"];
            }];
            readonly rulesApplied: readonly ["SHIFT-001: No duplicate open shift for the same shiftDate", "SHIFT-002: Opening cash balance must be >= 0", "SHIFT-003: Initial CashMovement of type 'entrada' recorded on shift open with reason 'Abertura de caixa'"];
            readonly mdmRefs: readonly [];
        };
    };
    export default openDailyShiftUsecase;
    export const pipeline: readonly [{
        readonly id: "openDailyShift__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/openDailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/openDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["SHIFT-001: No duplicate open shift for the same shiftDate", "SHIFT-002: Opening cash balance must be >= 0", "SHIFT-003: Initial CashMovement of type 'entrada' recorded on shift open with reason 'Abertura de caixa'"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/recordOpeningCashMovement.defs" {
    export const recordOpeningCashMovementUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "recordOpeningCashMovement";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "recordOpeningCashMovement";
            readonly ports: readonly ["DailyShift"];
            readonly functions: readonly [{
                readonly functionName: "recordOpeningCashMovement";
                readonly inputTypeName: "RecordOpeningCashMovementInput";
                readonly outputTypeName: "RecordOpeningCashMovementOutput";
                readonly input: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                    readonly description: "ID of the DailyShift to record the opening cash movement on";
                }, {
                    readonly name: "movementType";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "CashMovement";
                    readonly description: "Type of cash movement: 'entrada' or 'saída'";
                }, {
                    readonly name: "amount";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "CashMovement";
                    readonly description: "Monetary amount of the cash movement";
                }, {
                    readonly name: "reason";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "CashMovement";
                    readonly description: "Reason for the cash movement";
                }];
                readonly output: readonly [{
                    readonly name: "cashMovementId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "CashMovement";
                    readonly description: "ID of the newly created cash movement";
                }, {
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                    readonly description: "ID of the parent DailyShift aggregate";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Result status of the operation";
                }];
                readonly ports: readonly ["DailyShift"];
                readonly rulesApplied: readonly ["DailyShift must be in 'open' status to record a cash movement", "CashMovement is created and embedded in the DailyShift aggregate; no separate repository", "cashMovementId, createdAt and updatedAt are server-generated", "Opening cash movement sets or updates DailyShift.openingCashBalance"];
                readonly transactional: true;
                readonly steps: readonly ["Load DailyShift by dailyShiftId via DailyShift port", "Validate DailyShift.status is 'open'; reject if closed", "Create a new CashMovement with provided movementType, amount, reason; generate cashMovementId, createdAt, updatedAt", "Add the CashMovement to the DailyShift's cash movements collection", "If movementType is 'entrada', set DailyShift.openingCashBalance to the movement amount (if not already set) or accumulate", "Save the DailyShift aggregate via DailyShift port", "Return cashMovementId, dailyShiftId and status"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default recordOpeningCashMovementUsecase;
    export const pipeline: readonly [{
        readonly id: "recordOpeningCashMovement__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/recordOpeningCashMovement.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/recordOpeningCashMovement.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/recordPayment.defs" {
    export const recordPaymentUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "recordPayment";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "recordPayment";
            readonly ports: readonly ["Payment", "Order", "DailyShift"];
            readonly functions: readonly [{
                readonly functionName: "recordPayment";
                readonly inputTypeName: "RecordPaymentInput";
                readonly outputTypeName: "RecordPaymentOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Reference to the order being paid";
                }, {
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                    readonly description: "Reference to the daily shift in which the payment is recorded";
                }, {
                    readonly name: "method";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Payment method (e.g. cash, card, pix)";
                }, {
                    readonly name: "amount";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Payment amount";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Initial payment status: authorized | captured | voided | refunded";
                }];
                readonly output: readonly [{
                    readonly name: "paymentId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Payment";
                    readonly description: "Generated payment identifier";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Final payment status after rule validation";
                }];
                readonly ports: readonly ["Payment", "Order", "DailyShift"];
                readonly rulesApplied: readonly ["paymentTimingByOrderType"];
                readonly transactional: true;
                readonly steps: readonly ["Load DailyShift by dailyShiftId via DailyShift port and verify its status is 'open'; reject if closed", "Load Order by orderId via Order port and verify order.dailyShiftId matches the provided dailyShiftId", "Apply rule paymentTimingByOrderType: if order.orderType is 'mesa', require order.status to be at least 'served' before accepting payment; if order.orderType is 'takeout', allow payment when order.status is 'sentToKitchen' or later", "Validate that amount is positive and does not exceed order.totalAmount minus already-recorded payments", "Create Payment entity with generated paymentId, provided orderId, dailyShiftId, method, amount, and status; set createdAt and updatedAt to current timestamp", "Save Payment via Payment port", "Return paymentId and final status"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default recordPaymentUsecase;
    export const pipeline: readonly [{
        readonly id: "recordPayment__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/recordPayment.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/recordPayment.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/takeoutOrderLifecycle.defs" {
    export const takeoutOrderLifecycleUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "takeoutOrderLifecycle";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "takeoutOrderLifecycle";
            readonly ports: readonly ["Order"];
            readonly functions: readonly [{
                readonly functionName: "createTakeoutOrder";
                readonly inputTypeName: "CreateTakeoutOrderInput";
                readonly outputTypeName: "CreateTakeoutOrderOutput";
                readonly input: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Daily shift the order belongs to";
                }, {
                    readonly name: "customerName";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Name of the takeout customer";
                }, {
                    readonly name: "customerPhone";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Phone of the takeout customer";
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Order-level notes";
                }, {
                    readonly name: "items";
                    readonly type: "OrderItem[]";
                    readonly required: true;
                    readonly ofEntity: "OrderItem";
                    readonly description: "List of order items with menuItemId, quantity, unitPrice, observations";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Id of the created order";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Initial status (draft)";
                }];
                readonly ports: readonly ["Order"];
                readonly rulesApplied: readonly ["orderType-must-be-takeout", "order-starts-in-draft", "totalAmount-computed-from-items"];
                readonly transactional: true;
                readonly steps: readonly ["Load dailyShift via Order port to validate shift is open", "Create Order with orderType=takeout, status=draft", "Compute totalAmount from items (quantity * unitPrice)", "Embed OrderItem children with status=new", "Save Order aggregate via Order port"];
            }, {
                readonly functionName: "sendOrderToKitchen";
                readonly inputTypeName: "SendOrderToKitchenInput";
                readonly outputTypeName: "SendOrderToKitchenOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Id of the order to send to kitchen";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Id of the order";
                }, {
                    readonly name: "kitchenTicketId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "KitchenTicket";
                    readonly description: "Id of the created kitchen ticket";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "New order status (sentToKitchen)";
                }];
                readonly ports: readonly ["Order"];
                readonly rulesApplied: readonly ["order-must-be-draft-to-send", "kitchen-ticket-created-on-send", "items-transition-to-sentToKitchen"];
                readonly transactional: true;
                readonly steps: readonly ["Load Order aggregate via Order port", "Validate order.status === draft", "Create KitchenTicket with status=open, link to orderId", "Set order.kitchenTicketId", "Transition order.status to sentToKitchen", "Transition all OrderItem.status to sentToKitchen", "Save Order aggregate via Order port"];
            }, {
                readonly functionName: "markOrderReady";
                readonly inputTypeName: "MarkOrderReadyInput";
                readonly outputTypeName: "MarkOrderReadyOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Id of the order to mark ready";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Id of the order";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "New order status (ready)";
                }, {
                    readonly name: "kitchenTicketStatus";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "KitchenTicket";
                    readonly description: "New kitchen ticket status (done)";
                }];
                readonly ports: readonly ["Order"];
                readonly rulesApplied: readonly ["order-must-be-inPreparation-to-mark-ready", "kitchen-ticket-transitions-to-done", "all-items-must-be-ready"];
                readonly transactional: true;
                readonly steps: readonly ["Load Order aggregate via Order port", "Validate order.status === inPreparation", "Transition KitchenTicket.status to done", "Transition order.status to ready", "Ensure all OrderItem.status are ready", "Save Order aggregate via Order port"];
            }, {
                readonly functionName: "startPreparation";
                readonly inputTypeName: "StartPreparationInput";
                readonly outputTypeName: "StartPreparationOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Id of the order to start preparing";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Id of the order";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "New order status (inPreparation)";
                }, {
                    readonly name: "kitchenTicketStatus";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "KitchenTicket";
                    readonly description: "New kitchen ticket status (inProgress)";
                }];
                readonly ports: readonly ["Order"];
                readonly rulesApplied: readonly ["order-must-be-sentToKitchen-to-start", "kitchen-ticket-transitions-to-inProgress", "items-transition-to-inPreparation"];
                readonly transactional: true;
                readonly steps: readonly ["Load Order aggregate via Order port", "Validate order.status === sentToKitchen", "Transition KitchenTicket.status to inProgress", "Transition order.status to inPreparation", "Transition all OrderItem.status to inPreparation", "Save Order aggregate via Order port"];
            }, {
                readonly functionName: "closeOrder";
                readonly inputTypeName: "CloseOrderInput";
                readonly outputTypeName: "CloseOrderOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Id of the order to close";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Id of the closed order";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "New order status (closed)";
                }, {
                    readonly name: "closedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Timestamp when the order was closed";
                }];
                readonly ports: readonly ["Order"];
                readonly rulesApplied: readonly ["order-must-be-ready-or-served-to-close", "closedAt-set-on-close", "kitchen-ticket-must-be-done"];
                readonly transactional: true;
                readonly steps: readonly ["Load Order aggregate via Order port", "Validate order.status === ready or served", "Validate KitchenTicket.status === done", "Set order.status to closed", "Set order.closedAt to current timestamp", "Save Order aggregate via Order port"];
            }, {
                readonly functionName: "cancelOrder";
                readonly inputTypeName: "CancelOrderInput";
                readonly outputTypeName: "CancelOrderOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Id of the order to cancel";
                }, {
                    readonly name: "cancellationReason";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Reason for cancellation";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Id of the cancelled order";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "New order status (cancelled)";
                }, {
                    readonly name: "cancelledAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Timestamp when the order was cancelled";
                }];
                readonly ports: readonly ["Order"];
                readonly rulesApplied: readonly ["order-must-not-be-closed-or-cancelled", "cancelledAt-set-on-cancel", "items-transition-to-cancelled", "kitchen-ticket-transitions-to-void-if-exists"];
                readonly transactional: true;
                readonly steps: readonly ["Load Order aggregate via Order port", "Validate order.status is not closed or cancelled", "Set order.status to cancelled", "Set order.cancelledAt to current timestamp", "Set order.cancellationReason if provided", "Transition all OrderItem.status to cancelled", "If KitchenTicket exists, transition to void", "Save Order aggregate via Order port"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default takeoutOrderLifecycleUsecase;
    export const pipeline: readonly [{
        readonly id: "takeoutOrderLifecycle__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/takeoutOrderLifecycle.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/takeoutOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/updateKitchenTicketStatus.defs" {
    export const updateKitchenTicketStatusUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateKitchenTicketStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateKitchenTicketStatus";
            readonly ports: readonly ["Order"];
            readonly functions: readonly [{
                readonly functionName: "updateKitchenTicketStatus";
                readonly inputTypeName: "UpdateKitchenTicketStatusInput";
                readonly outputTypeName: "UpdateKitchenTicketStatusOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Identifier of the parent Order aggregate to load";
                }, {
                    readonly name: "kitchenTicketId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "KitchenTicket";
                    readonly description: "Identifier of the KitchenTicket whose status will be updated";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "KitchenTicket";
                    readonly description: "New status for the kitchen ticket: open | inProgress | done | void";
                }];
                readonly output: readonly [{
                    readonly name: "kitchenTicketId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "KitchenTicket";
                    readonly description: "Identifier of the updated KitchenTicket";
                }, {
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Identifier of the parent Order aggregate";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "KitchenTicket";
                    readonly description: "The new status applied to the KitchenTicket";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "KitchenTicket";
                    readonly description: "Timestamp of the status update";
                }];
                readonly ports: readonly ["Order"];
                readonly rulesApplied: readonly ["orderStatusTransitions"];
                readonly transactional: true;
                readonly steps: readonly ["Load the Order aggregate via OrderPort.findById(orderId); throw NotFound if missing", "Locate the KitchenTicket with kitchenTicketId inside the Order's kitchenTickets collection; throw NotFound if missing", "Validate the requested status transition against the orderStatusTransitions rule (e.g. open->inProgress, inProgress->done, open->void, etc.); throw InvalidTransition if not allowed", "Apply the new status to the KitchenTicket and set updatedAt to the current timestamp", "Save the Order aggregate via OrderPort.save(order)", "Return kitchenTicketId, orderId, status, and updatedAt"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default updateKitchenTicketStatusUsecase;
    export const pipeline: readonly [{
        readonly id: "updateKitchenTicketStatus__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateKitchenTicketStatus.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateKitchenTicketStatus.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderItemStatus.defs" {
    export const updateOrderItemStatusUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateOrderItemStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateOrderItemStatus";
            readonly ports: readonly ["Order"];
            readonly functions: readonly [{
                readonly functionName: "updateOrderItemStatus";
                readonly inputTypeName: "UpdateOrderItemStatusInput";
                readonly outputTypeName: "UpdateOrderItemStatusOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Parent aggregate id to load the order containing the item";
                }, {
                    readonly name: "orderItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "OrderItem";
                    readonly description: "Id of the order item whose status will be updated";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "OrderItem";
                    readonly description: "New status for the order item; must follow allowed transitions: new -> sentToKitchen -> inPreparation -> ready -> served, or any -> cancelled";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Id of the parent order aggregate";
                }, {
                    readonly name: "orderItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "OrderItem";
                    readonly description: "Id of the updated order item";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "OrderItem";
                    readonly description: "The new status applied to the order item";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "OrderItem";
                    readonly description: "Timestamp of the status update";
                }];
                readonly ports: readonly ["Order"];
                readonly rulesApplied: readonly ["orderStatusTransitions", "ingredientConsumptionTrigger"];
                readonly transactional: true;
                readonly steps: readonly ["Load the Order aggregate via OrderPort.findById(orderId); throw NotFound if absent", "Locate the OrderItem by orderItemId within the order's item collection; throw NotFound if absent", "Validate the requested status transition against orderStatusTransitions rule (new->sentToKitchen->inPreparation->ready->served; any->cancelled); throw InvalidTransition if not allowed", "Apply the new status to the OrderItem and update its updatedAt timestamp", "If status transitions to 'inPreparation', trigger ingredientConsumptionTrigger rule to decrement stock for the menuItemId ingredients", "Save the Order aggregate via OrderPort.save(order)", "Return orderId, orderItemId, status, and updatedAt"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default updateOrderItemStatusUsecase;
    export const pipeline: readonly [{
        readonly id: "updateOrderItemStatus__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderItemStatus.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderItemStatus.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.defs" {
    export const updateOrderStatusUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateOrderStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateOrderStatus";
            readonly ports: readonly ["Order", "Payment", "InventoryItem", "MenuItem"];
            readonly functions: readonly [{
                readonly functionName: "updateOrderStatus";
                readonly inputTypeName: "UpdateOrderStatusInput";
                readonly outputTypeName: "UpdateOrderStatusOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "ID of the order whose status is being updated";
                }, {
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Daily shift context for the operation";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Target status: draft, sentToKitchen, inPreparation, ready, served, closed, cancelled";
                }, {
                    readonly name: "cancellationReason";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Reason required when status is cancelled";
                }, {
                    readonly name: "tableId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Table ID for table-occupancy consistency check (mdmRef)";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "ID of the updated order";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "New status of the order";
                }, {
                    readonly name: "previousStatus";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Previous status before the transition";
                }, {
                    readonly name: "closedAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Timestamp set when order is closed";
                }, {
                    readonly name: "cancelledAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Timestamp set when order is cancelled";
                }, {
                    readonly name: "tableReleased";
                    readonly type: "boolean";
                    readonly required: false;
                    readonly description: "Whether the associated table was released to available";
                }, {
                    readonly name: "stockConsumptionIds";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "StockConsumption";
                    readonly description: "IDs of stock consumption records created when ingredients were consumed";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Timestamp of the update";
                }];
                readonly ports: readonly ["Order", "Payment", "InventoryItem", "MenuItem"];
                readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "aiOutputLanguageSelection", "tableOccupancyConsistency"];
                readonly transactional: true;
                readonly steps: readonly ["1. Load Order by orderId via Order port (includes embedded OrderItem collection and KitchenTicket reference)", "2. Validate the requested status transition against the current status using orderStatusTransitions rule — reject illegal transitions", "3. If target status is 'closed' or 'cancelled', verify payment requirements per paymentTimingByOrderType rule: for 'mesa' type check that a captured Payment exists via Payment port; for 'takeout' type check payment was authorized before preparation", "4. If target status is 'served' or 'closed', trigger ingredientConsumptionTrigger: for each OrderItem load its MenuItem via MenuItem port to obtain RecipeComponent list; for each RecipeComponent deduct quantity * orderItem.quantity from the corresponding InventoryItem via InventoryItem port and create StockConsumption records", "5. Apply aiOutputLanguageSelection to determine the language for any kitchen-ticket or notification output associated with the status change", "6. If target status is 'closed' or 'cancelled' and order has a tableId, enforce tableOccupancyConsistency: read Table via ctx.data.mdmDocument.get({ mdmId: tableId }), verify it is currently 'occupied', and update it to 'available'", "7. If target status is 'cancelled', set cancelledAt and require cancellationReason; if 'closed', set closedAt", "8. Update Order.status and updatedAt, then save the Order aggregate via Order port", "9. Return orderId, status, previousStatus, closedAt/cancelledAt if set, tableReleased flag, stockConsumptionIds if created, and updatedAt"];
            }];
            readonly mdmRefs: readonly ["Table"];
        };
    };
    export default updateOrderStatusUsecase;
    export const pipeline: readonly [{
        readonly id: "updateOrderStatus__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface UpdateOrderStatusInput {
        orderId: string;
        dailyShiftId: string;
        status: string;
        cancellationReason?: string;
        tableId?: string;
    }
    export interface UpdateOrderStatusOutput {
        orderId: string;
        status: string;
        previousStatus: string;
        closedAt?: string;
        cancelledAt?: string;
        tableReleased?: boolean;
        stockConsumptionIds?: string[];
        updatedAt: string;
    }
    export function updateOrderStatus(ctx: RequestContext, input: UpdateOrderStatusInput): Promise<UpdateOrderStatusOutput>;
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/updateTableStatus.defs" {
    export const updateTableStatusUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateTableStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateTableStatus";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "updateTableStatus";
                readonly inputTypeName: "UpdateTableStatusInput";
                readonly outputTypeName: "UpdateTableStatusOutput";
                readonly input: readonly [{
                    readonly name: "tableId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Unique identifier of the table whose status is being updated";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "New status for the table: available, occupied, or disabled";
                }];
                readonly output: readonly [{
                    readonly name: "tableId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Identifier of the updated table";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Confirmed status after update";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Timestamp of the status update";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["tableOccupancyConsistency"];
                readonly transactional: true;
                readonly steps: readonly ["Load Table master-data document by id via ctx.data.mdmDocument.get({ mdmId: tableId })", "Validate that the requested status is one of available, occupied, disabled", "Apply tableOccupancyConsistency rule: if transitioning to 'occupied' ensure no conflicting active occupancy; if transitioning to 'available' ensure no active orders/reservations tied to the table", "Update the Table document status field and set updatedAt to current timestamp", "Persist the updated Table master-data document via ctx.data.mdmDocument update within a single transaction", "Return tableId, confirmed status, and updatedAt"];
            }];
            readonly rulesApplied: readonly ["tableOccupancyConsistency"];
            readonly mdmRefs: readonly ["Table"];
        };
    };
    export default updateTableStatusUsecase;
    export const pipeline: readonly [{
        readonly id: "updateTableStatus__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateTableStatus.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateTableStatus.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["tableOccupancyConsistency"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/updateTableStatus" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface UpdateTableStatusInput {
        tableId: string;
        status: string;
    }
    export interface UpdateTableStatusOutput {
        tableId: string;
        status: string;
        updatedAt: string;
    }
    export function updateTableStatus(ctx: RequestContext, input: UpdateTableStatusInput): Promise<UpdateTableStatusOutput>;
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/viewKitchenTickets.defs" {
    export const viewKitchenTicketsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "viewKitchenTickets";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "viewKitchenTickets";
            readonly ports: readonly ["Order"];
            readonly functions: readonly [{
                readonly functionName: "viewKitchenTickets";
                readonly inputTypeName: "ViewKitchenTicketsInput";
                readonly outputTypeName: "ViewKitchenTicketsOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Filter kitchen tickets by parent order id";
                }, {
                    readonly name: "kitchenTicketId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "KitchenTicket";
                    readonly description: "Filter by a specific kitchen ticket id";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "KitchenTicket";
                    readonly description: "Filter by kitchen ticket status (open, inProgress, done, void)";
                }];
                readonly output: readonly [{
                    readonly name: "kitchenTicketId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "KitchenTicket";
                    readonly description: "Unique identifier of the kitchen ticket";
                }, {
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Parent order id";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "KitchenTicket";
                    readonly description: "Current status of the kitchen ticket";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "KitchenTicket";
                    readonly description: "Creation timestamp";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "KitchenTicket";
                    readonly description: "Last update timestamp";
                }];
                readonly ports: readonly ["Order"];
                readonly rulesApplied: readonly [];
                readonly transactional: false;
                readonly steps: readonly ["If orderId is provided, load the Order aggregate via OrderPort.findById(orderId)", "If kitchenTicketId is provided without orderId, load all candidate Orders via OrderPort and locate the one containing the matching KitchenTicket", "Extract KitchenTicket entries from the loaded Order aggregate(s)", "If status filter is provided, filter the extracted tickets by status", "Project and return the matching KitchenTicket fields: kitchenTicketId, orderId, status, createdAt, updatedAt"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default viewKitchenTicketsUsecase;
    export const pipeline: readonly [{
        readonly id: "viewKitchenTickets__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/viewKitchenTickets.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/viewKitchenTickets.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/viewOperationalDashboard.defs" {
    export const viewOperationalDashboardUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "viewOperationalDashboard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "viewOperationalDashboard";
            readonly ports: readonly ["DailyShift", "Order", "Payment"];
            readonly functions: readonly [{
                readonly functionName: "viewOperationalDashboard";
                readonly inputTypeName: "ViewOperationalDashboardInput";
                readonly outputTypeName: "ViewOperationalDashboardOutput";
                readonly input: readonly [{
                    readonly name: "shiftDate";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Date of the shift to display on the operational dashboard (YYYY-MM-DD)";
                }, {
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Optional specific shift ID; if omitted the shift for shiftDate is resolved";
                }];
                readonly output: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                    readonly description: "Identifier of the resolved daily shift";
                }, {
                    readonly name: "shiftDate";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                    readonly description: "Date of the shift";
                }, {
                    readonly name: "shiftStatus";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                    readonly description: "Current status of the shift (open or closed)";
                }, {
                    readonly name: "openedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                    readonly description: "Timestamp when the shift was opened";
                }, {
                    readonly name: "closedAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "DailyShift";
                    readonly description: "Timestamp when the shift was closed, if applicable";
                }, {
                    readonly name: "openingCashBalance";
                    readonly type: "number";
                    readonly required: false;
                    readonly ofEntity: "DailyShift";
                    readonly description: "Cash balance at shift opening";
                }, {
                    readonly name: "closingCashBalance";
                    readonly type: "number";
                    readonly required: false;
                    readonly ofEntity: "DailyShift";
                    readonly description: "Cash balance at shift closing, if closed";
                }, {
                    readonly name: "totalSales";
                    readonly type: "number";
                    readonly required: false;
                    readonly ofEntity: "DailyShift";
                    readonly description: "Total sales recorded for the shift";
                }, {
                    readonly name: "totalPayments";
                    readonly type: "number";
                    readonly required: false;
                    readonly ofEntity: "DailyShift";
                    readonly description: "Total payments captured for the shift";
                }, {
                    readonly name: "totalOrders";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Total number of orders in the shift";
                }, {
                    readonly name: "openOrders";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Count of orders not yet closed or cancelled";
                }, {
                    readonly name: "closedOrders";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Count of closed orders";
                }, {
                    readonly name: "cancelledOrders";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Count of cancelled orders";
                }, {
                    readonly name: "totalOrderAmount";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Sum of totalAmount across all non-cancelled orders";
                }, {
                    readonly name: "totalCapturedPayments";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Sum of captured payment amounts";
                }, {
                    readonly name: "totalAuthorizedPayments";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Sum of authorized (not yet captured) payment amounts";
                }, {
                    readonly name: "totalRefundedPayments";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Sum of refunded payment amounts";
                }, {
                    readonly name: "totalCashIn";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Sum of entrada cash movements for the shift";
                }, {
                    readonly name: "totalCashOut";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Sum of saída cash movements for the shift";
                }, {
                    readonly name: "expectedCashBalance";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Computed expected cash: openingCashBalance + totalCashIn - totalCashOut + captured cash payments";
                }];
                readonly ports: readonly ["DailyShift", "Order", "Payment"];
                readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
                readonly transactional: false;
                readonly steps: readonly ["Resolve the DailyShift by dailyShiftId or by shiftDate via DailyShift port", "Load all Orders for the resolved dailyShiftId via Order port", "Load all Payments for the resolved dailyShiftId via Payment port", "Apply paymentTimingByOrderType rule to classify payment timing expectations per order type (mesa vs takeout)", "Aggregate order counts by status (open, closed, cancelled) and sum totalAmount for non-cancelled orders", "Aggregate payment amounts by status (captured, authorized, refunded)", "Read CashMovement entries embedded in the DailyShift aggregate to compute totalCashIn and totalCashOut", "Compute expectedCashBalance = openingCashBalance + totalCashIn - totalCashOut + capturedCashPayments", "Apply aiOutputLanguageSelection rule to determine dashboard label language for the response", "Assemble and return the dashboard projection"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default viewOperationalDashboardUsecase;
    export const pipeline: readonly [{
        readonly id: "viewOperationalDashboard__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/viewOperationalDashboard.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/viewOperationalDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.defs" {
    export const dailyShiftDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "DailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "DailyShift";
            readonly fields: readonly [{
                readonly fieldId: "dailyShiftId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do turno diário.";
            }, {
                readonly fieldId: "shiftDate";
                readonly type: "date";
                readonly required: true;
                readonly description: "Data operacional do turno.";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Estado atual do turno.";
                readonly enum: readonly ["open", "closed"];
            }, {
                readonly fieldId: "openedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de abertura do turno.";
            }, {
                readonly fieldId: "closedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora de fechamento do turno.";
            }, {
                readonly fieldId: "openingCashBalance";
                readonly type: "money";
                readonly required: false;
                readonly description: "Valor inicial em caixa ao abrir o turno.";
            }, {
                readonly fieldId: "closingCashBalance";
                readonly type: "money";
                readonly required: false;
                readonly description: "Valor final em caixa ao fechar o turno.";
            }, {
                readonly fieldId: "totalSales";
                readonly type: "money";
                readonly required: false;
                readonly description: "Total consolidado de vendas no turno.";
            }, {
                readonly fieldId: "totalPayments";
                readonly type: "money";
                readonly required: false;
                readonly description: "Total consolidado de pagamentos recebidos no turno.";
            }, {
                readonly fieldId: "closingNotes";
                readonly type: "text";
                readonly required: false;
                readonly description: "Observações e relatório de fechamento do turno.";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro.";
            }];
            readonly statusEnum: readonly ["open", "closed"];
            readonly invariants: readonly ["only one DailyShift per shiftDate may be open at a time", "closedAt must be set when status is closed", "closedAt must be null when status is open", "cannot add CashMovements to a closed DailyShift", "closingCashBalance must equal openingCashBalance plus sum of all CashMovement amounts plus totalPayments when closing", "status can only transition from open to closed"];
            readonly valueObjects: readonly [{
                readonly name: "CashMovement";
                readonly fields: readonly [{
                    readonly fieldId: "cashMovementId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do movimento de caixa";
                }, {
                    readonly fieldId: "dailyShiftId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao turno (DailyShift) ao qual o movimento pertence";
                }, {
                    readonly fieldId: "movementType";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Tipo do movimento: entrada ou saída de caixa";
                    readonly enum: readonly ["entrada", "saída"];
                }, {
                    readonly fieldId: "amount";
                    readonly type: "money";
                    readonly required: true;
                    readonly description: "Valor do movimento";
                }, {
                    readonly fieldId: "reason";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Motivo do movimento (ex.: sangria, reforço, estorno)";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data/hora de criação do registro";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data/hora da última atualização do registro";
                }];
                readonly collection: true;
            }];
        };
    };
    export default dailyShiftDomainEntity;
    export const pipeline: readonly [{
        readonly id: "dailyShift__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.defs" {
    export const inventoryItemDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "InventoryItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "InventoryItem";
            readonly fields: readonly [{
                readonly fieldId: "inventoryItemId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do item de estoque";
            }, {
                readonly fieldId: "name";
                readonly type: "string";
                readonly required: true;
                readonly description: "Nome do ingrediente ou insumo";
            }, {
                readonly fieldId: "description";
                readonly type: "text";
                readonly required: false;
                readonly description: "Descrição detalhada do item";
            }, {
                readonly fieldId: "unit";
                readonly type: "string";
                readonly required: true;
                readonly description: "Unidade de medida (ex.: kg, L, unidade, gramas)";
            }, {
                readonly fieldId: "currentQuantity";
                readonly type: "number";
                readonly required: true;
                readonly description: "Quantidade atual disponível em estoque";
            }, {
                readonly fieldId: "minimumLevel";
                readonly type: "number";
                readonly required: true;
                readonly description: "Nível mínimo para geração de alerta de baixo estoque";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Estado do ciclo de vida do item";
                readonly enum: readonly ["active", "inactive"];
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro";
            }];
            readonly statusEnum: readonly ["active", "inactive"];
            readonly invariants: readonly ["currentQuantity must not be negative", "minimumLevel must be greater than or equal to zero", "name must not be empty", "unit must not be empty", "status can only transition between active and inactive"];
            readonly valueObjects: readonly [];
        };
    };
    export default inventoryItemDomainEntity;
    export const pipeline: readonly [{
        readonly id: "inventoryItem__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.defs" {
    export const menuItemDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "MenuItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "MenuItem";
            readonly fields: readonly [{
                readonly fieldId: "menuItemId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do item do cardápio";
            }, {
                readonly fieldId: "menuCategoryId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência à categoria do cardápio à qual o item pertence";
            }, {
                readonly fieldId: "name";
                readonly type: "string";
                readonly required: true;
                readonly description: "Nome do item (ex.: cappuccino, pão de queijo)";
            }, {
                readonly fieldId: "description";
                readonly type: "text";
                readonly required: false;
                readonly description: "Descrição detalhada do item";
            }, {
                readonly fieldId: "price";
                readonly type: "money";
                readonly required: true;
                readonly description: "Preço de venda do item";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Estado do ciclo de vida do item";
                readonly enum: readonly ["draft", "active", "inactive"];
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro";
            }];
            readonly statusEnum: readonly ["draft", "active", "inactive"];
            readonly invariants: readonly ["price must be greater than zero", "name must not be empty", "status can only transition from draft to active, active to inactive, and inactive to active", "cannot delete a MenuItem referenced by active Orders"];
            readonly valueObjects: readonly [{
                readonly name: "RecipeComponent";
                readonly fields: readonly [{
                    readonly fieldId: "recipeComponentId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do componente de receita";
                }, {
                    readonly fieldId: "menuItemId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao item de menu ao qual este componente pertence";
                }, {
                    readonly fieldId: "inventoryItemId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao item de inventário utilizado como ingrediente";
                }, {
                    readonly fieldId: "quantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade consumida do item de inventário por unidade vendida do menu item";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do registro";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do registro";
                }];
                readonly collection: true;
            }];
        };
    };
    export default menuItemDomainEntity;
    export const pipeline: readonly [{
        readonly id: "menuItem__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_3_domain/entities/order.defs" {
    export const orderDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Order";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Order";
            readonly fields: readonly [{
                readonly fieldId: "orderId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do pedido";
            }, {
                readonly fieldId: "dailyShiftId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Turno diário em que o pedido foi registrado";
            }, {
                readonly fieldId: "tableId";
                readonly type: "uuid";
                readonly required: false;
                readonly description: "Referência à mesa associada (para pedidos do tipo mesa)";
            }, {
                readonly fieldId: "kitchenTicketId";
                readonly type: "uuid";
                readonly required: false;
                readonly description: "Ticket de cozinha gerado para fila de preparo";
            }, {
                readonly fieldId: "orderType";
                readonly type: "string";
                readonly required: true;
                readonly description: "Tipo do pedido: mesa ou takeout";
                readonly enum: readonly ["mesa", "takeout"];
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Status atual do pedido na coordenação com a cozinha";
                readonly enum: readonly ["draft", "sentToKitchen", "inPreparation", "ready", "served", "closed", "cancelled"];
            }, {
                readonly fieldId: "totalAmount";
                readonly type: "money";
                readonly required: true;
                readonly description: "Valor total do pedido com preços no momento da venda";
            }, {
                readonly fieldId: "notes";
                readonly type: "text";
                readonly required: false;
                readonly description: "Observações gerais do pedido";
            }, {
                readonly fieldId: "customerName";
                readonly type: "string";
                readonly required: false;
                readonly description: "Nome do cliente para identificação do pedido";
            }, {
                readonly fieldId: "customerPhone";
                readonly type: "string";
                readonly required: false;
                readonly description: "Telefone de contato do cliente";
            }, {
                readonly fieldId: "numberOfGuests";
                readonly type: "number";
                readonly required: false;
                readonly description: "Número de pessoas na mesa";
            }, {
                readonly fieldId: "closedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora do fechamento do pedido";
            }, {
                readonly fieldId: "cancelledAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora do cancelamento do pedido";
            }, {
                readonly fieldId: "cancellationReason";
                readonly type: "text";
                readonly required: false;
                readonly description: "Motivo do cancelamento";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro";
            }];
            readonly statusEnum: readonly ["draft", "sentToKitchen", "inPreparation", "ready", "served", "closed", "cancelled"];
            readonly invariants: readonly ["totalAmount must equal the sum of all OrderItem.totalPrice", "tableId is required when orderType is mesa", "tableId must be null when orderType is takeout", "status transitions must follow: draft→sentToKitchen→inPreparation→ready→served→closed; any state before closed can transition to cancelled", "closedAt must be set when status is closed", "cancelledAt and cancellationReason must be set when status is cancelled", "cannot modify OrderItems after status is sentToKitchen", "numberOfGuests must be greater than zero when provided"];
            readonly valueObjects: readonly [{
                readonly name: "OrderItem";
                readonly fields: readonly [{
                    readonly fieldId: "id";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do item do pedido";
                }, {
                    readonly fieldId: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao pedido (Order) ao qual este item pertence";
                }, {
                    readonly fieldId: "menuItemId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao item do cardápio (MenuItem) solicitado";
                }, {
                    readonly fieldId: "kitchenTicketId";
                    readonly type: "uuid";
                    readonly required: false;
                    readonly description: "Referência ao ticket de cozinha (KitchenTicket) quando o item exige preparo";
                }, {
                    readonly fieldId: "quantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade solicitada do item";
                }, {
                    readonly fieldId: "unitPrice";
                    readonly type: "money";
                    readonly required: true;
                    readonly description: "Preço unitário do item no momento do pedido";
                }, {
                    readonly fieldId: "totalPrice";
                    readonly type: "money";
                    readonly required: true;
                    readonly description: "Preço total do item (quantidade × preço unitário)";
                }, {
                    readonly fieldId: "observations";
                    readonly type: "text";
                    readonly required: false;
                    readonly description: "Observações ou instruções especiais para o item";
                }, {
                    readonly fieldId: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Status de produção/atendimento do item";
                    readonly enum: readonly ["new", "sentToKitchen", "inPreparation", "ready", "served", "cancelled"];
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do registro";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do registro";
                }];
                readonly collection: true;
            }, {
                readonly name: "KitchenTicket";
                readonly fields: readonly [{
                    readonly fieldId: "kitchenTicketId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do ticket de cozinha";
                }, {
                    readonly fieldId: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao pedido que gerou este ticket para a fila de preparo";
                }, {
                    readonly fieldId: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Status atual do ticket na fila de preparo da cozinha";
                    readonly enum: readonly ["open", "inProgress", "done", "void"];
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do ticket";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do ticket";
                }];
                readonly collection: true;
            }];
        };
    };
    export default orderDomainEntity;
    export const pipeline: readonly [{
        readonly id: "order__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/order.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/order.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.defs" {
    export const paymentDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Payment";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Payment";
            readonly fields: readonly [{
                readonly fieldId: "paymentId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do pagamento.";
            }, {
                readonly fieldId: "orderId";
                readonly type: "uuid";
                readonly required: false;
                readonly description: "Referência ao pedido associado ao pagamento, quando aplicável.";
            }, {
                readonly fieldId: "dailyShiftId";
                readonly type: "uuid";
                readonly required: false;
                readonly description: "Referência ao turno diário de fechamento ao qual o pagamento será consolidado.";
            }, {
                readonly fieldId: "method";
                readonly type: "string";
                readonly required: true;
                readonly description: "Método de pagamento utilizado (ex.: dinheiro, cartão de crédito, PIX).";
            }, {
                readonly fieldId: "amount";
                readonly type: "money";
                readonly required: true;
                readonly description: "Valor recebido/pago.";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Situação atual do pagamento no ciclo de vida.";
                readonly enum: readonly ["authorized", "captured", "voided", "refunded"];
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro.";
            }];
            readonly statusEnum: readonly ["authorized", "captured", "voided", "refunded"];
            readonly invariants: readonly ["amount must be greater than zero", "method must not be empty", "status transitions must follow: authorized→captured; captured→refunded; authorized→voided; captured→voided", "cannot void or refund a payment that is already voided or refunded", "dailyShiftId must reference an open DailyShift at the time of capture"];
            readonly valueObjects: readonly [];
        };
    };
    export default paymentDomainEntity;
    export const pipeline: readonly [{
        readonly id: "payment__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_3_domain/entities/tableOccupancy.defs" {
    export const tableOccupancyDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "TableOccupancy";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "TableOccupancy";
            readonly fields: readonly [{
                readonly fieldId: "tableOccupancyId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do registro de ocupação.";
            }, {
                readonly fieldId: "tableId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência ao cadastro da mesa (Table, MDM).";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Situação operacional da mesa no atendimento.";
                readonly enum: readonly ["available", "occupied", "disabled"];
            }, {
                readonly fieldId: "currentChargesTotal";
                readonly type: "decimal";
                readonly required: true;
                readonly description: "Consumo acumulado da mesa na ocupação atual.";
            }, {
                readonly fieldId: "openedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Início da ocupação atual (null quando livre).";
            }, {
                readonly fieldId: "closedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Fim da última ocupação (null enquanto ocupada).";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro.";
            }];
            readonly statusEnum: readonly ["available", "occupied", "disabled"];
            readonly invariants: readonly ["currentChargesTotal must not be negative", "openedAt must be set when status is occupied", "closedAt must be set when transitioning from occupied to available", "openedAt must be null when status is available", "status can only transition: available→occupied, occupied→available, available→disabled, disabled→available"];
            readonly valueObjects: readonly [];
        };
    };
    export default tableOccupancyDomainEntity;
    export const pipeline: readonly [{
        readonly id: "tableOccupancy__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/tableOccupancy.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/tableOccupancy.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102050_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
    }[];
    export const pipeline: readonly [{
        readonly id: "aiPromotionSuggestions__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions" {
    export interface CafeFlowAiPromotionSuggestionsInput {
        id?: string;
        orderId?: string;
        menuItemId?: string;
        kitchenTicketId?: string;
        status?: "new" | "sentToKitchen" | "inPreparation" | "ready" | "served" | "cancelled";
        createdAt?: string;
    }
    export interface CafeFlowAiPromotionSuggestionsOutputItem {
        id: string;
        orderId: string;
        menuItemId: string;
        kitchenTicketId: string;
        quantity: number;
        unitPrice: number;
        totalPrice: number;
        observations: string;
    }
    export type CafeFlowAiPromotionSuggestionsOutput = CafeFlowAiPromotionSuggestionsOutputItem[];
}
declare module "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
    }[];
    export const pipeline: readonly [{
        readonly id: "aiSalesSummary__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary" {
    export interface CafeFlowAiSalesSummaryInput {
        dailyShiftId?: string;
        status?: "draft" | "sentToKitchen" | "inPreparation" | "ready" | "served" | "closed" | "cancelled";
        closedAt?: string;
    }
    export interface CafeFlowAiSalesSummaryOutputItem {
        dailyShiftId: string;
        status: "draft" | "sentToKitchen" | "inPreparation" | "ready" | "served" | "closed" | "cancelled";
        totalAmount: number;
        closedAt: string;
    }
    export type CafeFlowAiSalesSummaryOutput = CafeFlowAiSalesSummaryOutputItem[];
}
declare module "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
    }[];
    export const pipeline: readonly [{
        readonly id: "browseMenuForPos__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos" {
    export interface CafeFlowBrowseMenuForPosInput {
        menuItemId?: string;
        menuCategoryId?: string;
        name?: string;
        status?: "draft" | "active" | "inactive";
        createdAt?: string;
        updatedAt?: string;
    }
    export interface CafeFlowBrowseMenuForPosOutputItem {
        menuItemId: string;
        menuCategoryId: string;
        name: string;
        description: string;
        price: number;
        status: "draft" | "active" | "inactive";
        createdAt: string;
        updatedAt: string;
    }
    export type CafeFlowBrowseMenuForPosOutput = CafeFlowBrowseMenuForPosOutputItem[];
}
declare module "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
    }[];
    export const pipeline: readonly [{
        readonly id: "closeDailyShift__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/closeDailyShift" {
    export interface CafeFlowUpdateDailyShiftStatusInput {
        dailyShiftId?: string;
        shiftDate: string;
        status: "open" | "closed";
        openedAt: string;
        closedAt?: string;
        openingCashBalance?: number;
        closingCashBalance?: number;
        totalSales?: number;
        totalPayments?: number;
        closingNotes?: string;
    }
    export interface CafeFlowUpdateDailyShiftStatusOutput {
        dailyShiftId: string;
    }
    export interface CafeFlowRecordClosingCashMovementInput {
        shiftDate: string;
        status: "open" | "closed";
        openedAt: string;
        closedAt?: string;
        openingCashBalance?: number;
        closingCashBalance?: number;
        totalSales?: number;
        totalPayments?: number;
        closingNotes?: string;
    }
    export interface CafeFlowRecordClosingCashMovementOutput {
        dailyShiftId: string;
    }
}
declare module "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
    }[];
    export const pipeline: readonly [{
        readonly id: "consumeIngredientsOnConfirmation__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation" {
    export interface CafeFlowCreateStockConsumptionInput {
        quantity: number;
        status: "posted" | "voided";
        consumedAt: string;
    }
    export interface CafeFlowCreateStockConsumptionOutput {
        id: string;
    }
}
declare module "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        } | {
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
    }[];
    export const pipeline: readonly [{
        readonly id: "dineInOrderLifecycle__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle" {
    export interface CafeFlowCreateOrderInput {
        orderType: "mesa" | "takeout";
        status: "draft" | "sentToKitchen" | "inPreparation" | "ready" | "served" | "closed" | "cancelled";
        totalAmount: number;
        notes?: string;
        customerName?: string;
        customerPhone?: string;
        numberOfGuests?: number;
        closedAt?: string;
        cancelledAt?: string;
        cancellationReason?: string;
    }
    export interface CafeFlowCreateOrderOutput {
        orderId: string;
    }
    export interface CafeFlowAddOrderItemInput {
        quantity: number;
        unitPrice: number;
        totalPrice: number;
        observations?: string;
        status: "new" | "sentToKitchen" | "inPreparation" | "ready" | "served" | "cancelled";
    }
    export interface CafeFlowAddOrderItemOutput {
        id: string;
    }
    export interface CafeFlowCreateKitchenTicketInput {
        status: "open" | "inProgress" | "done" | "void";
    }
    export interface CafeFlowCreateKitchenTicketOutput {
        kitchenTicketId: string;
    }
    export interface CafeFlowUpdateOrderStatusInput {
        status: "draft" | "sentToKitchen" | "inPreparation" | "ready" | "served" | "closed" | "cancelled";
        closedAt?: string;
        cancelledAt?: string;
        cancellationReason?: string;
    }
    export interface CafeFlowUpdateOrderStatusOutput {
        orderId: string;
    }
    export interface CafeFlowUpdateTableStatusInput {
        status: "available" | "occupied" | "disabled";
        currentChargesTotal: number;
        openedAt?: string;
        closedAt?: string;
    }
    export interface CafeFlowUpdateTableStatusOutput {
        tableOccupancyId: string;
    }
}
declare module "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        } | {
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        })[];
        output: ({
            name: string;
            type: string;
            enum: string[];
            description: string;
        } | {
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        })[];
    }[];
    export const pipeline: readonly [{
        readonly id: "generateShiftCloseReport__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport" {
    export interface CafeFlowGenerateShiftCloseReportInput {
        status?: "open" | "closed";
        openedAt?: string;
        closedAt?: string;
    }
    export interface CafeFlowGenerateShiftCloseReportOutputItem {
        status: "open" | "closed";
        openedAt: string;
        closedAt: string;
        openingCashBalance: number;
        closingCashBalance: number;
        totalSales: number;
        totalPayments: number;
        closingNotes: string;
    }
    export type CafeFlowGenerateShiftCloseReportOutput = CafeFlowGenerateShiftCloseReportOutputItem[];
}
declare module "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
    }[];
    export const pipeline: readonly [{
        readonly id: "kitchenProductionFlow__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow" {
    export interface CafeFlowViewKitchenTicketsInput {
        kitchenTicketId?: string;
        orderId?: string;
        status?: "open" | "inProgress" | "done" | "void";
        createdAt?: string;
        updatedAt?: string;
    }
    export interface CafeFlowViewKitchenTicketsOutputItem {
        kitchenTicketId: string;
        orderId: string;
        status: "open" | "inProgress" | "done" | "void";
        createdAt: string;
        updatedAt: string;
    }
    export type CafeFlowViewKitchenTicketsOutput = CafeFlowViewKitchenTicketsOutputItem[];
    export interface CafeFlowUpdateKitchenTicketStatusInput {
        status: "open" | "inProgress" | "done" | "void";
    }
    export interface CafeFlowUpdateKitchenTicketStatusOutput {
        kitchenTicketId: string;
    }
    export interface CafeFlowUpdateOrderItemStatusInput {
        status: "new" | "sentToKitchen" | "inPreparation" | "ready" | "served" | "cancelled";
    }
    export interface CafeFlowUpdateOrderItemStatusOutput {
        id: string;
    }
}
declare module "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
    }[];
    export const pipeline: readonly [{
        readonly id: "manageInventoryItems__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems" {
    export interface CafeFlowManageInventoryItemsInput {
        name: string;
        description?: string;
        unit: string;
        currentQuantity: number;
        minimumLevel: number;
        status: "active" | "inactive";
    }
    export interface CafeFlowManageInventoryItemsOutput {
        inventoryItemId: string;
    }
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
    }[];
    export const pipeline: readonly [{
        readonly id: "manageMenuCategories__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories" {
    export interface CafeFlowManageMenuCategoriesInput {
        menuCategoryId?: string;
        name: string;
        description?: string;
        status: "active" | "inactive";
    }
    export interface CafeFlowManageMenuCategoriesOutput {
        menuCategoryId: string;
    }
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageMenuItems.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
    }[];
    export const pipeline: readonly [{
        readonly id: "manageMenuItems__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/manageMenuItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/manageMenuItems.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageMenuItems" {
    export interface CafeFlowManageMenuItemsInput {
        menuItemId?: string;
        menuCategoryId?: string;
        name: string;
        description?: string;
        price: number;
        status: "draft" | "active" | "inactive";
    }
    export interface CafeFlowManageMenuItemsOutput {
        menuItemId: string;
    }
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageMenuItems.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageTables.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
    }[];
    export const pipeline: readonly [{
        readonly id: "manageTables__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/manageTables.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/manageTables.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageTables" {
    export interface CafeFlowManageTablesInput {
        tableId?: string;
        number: string;
        status: "active" | "inactive";
    }
    export interface CafeFlowManageTablesOutput {
        tableId: string;
    }
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageTables.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/contracts/openDailyShift.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
    }[];
    export const pipeline: readonly [{
        readonly id: "openDailyShift__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/openDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/openDailyShift.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/openDailyShift" {
    export interface CafeFlowCreateDailyShiftInput {
        shiftDate: string;
        status: "open" | "closed";
        openedAt: string;
        openingCashBalance?: number;
    }
    export interface CafeFlowCreateDailyShiftOutput {
        dailyShiftId: string;
    }
    export interface CafeFlowRecordOpeningCashMovementInput {
        movementType: "entrada" | "saída";
        amount: number;
        reason: string;
    }
    export interface CafeFlowRecordOpeningCashMovementOutput {
        cashMovementId: string;
    }
}
declare module "_102050_/l2/cafeFlow/web/contracts/openDailyShift.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/contracts/recordPayment.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
    }[];
    export const pipeline: readonly [{
        readonly id: "recordPayment__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/recordPayment.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/recordPayment.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/recordPayment" {
    export interface CafeFlowRecordPaymentInput {
        method: string;
        amount: number;
        status: "authorized" | "captured" | "voided" | "refunded";
    }
    export interface CafeFlowRecordPaymentOutput {
        paymentId: string;
    }
}
declare module "_102050_/l2/cafeFlow/web/contracts/recordPayment.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        } | {
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
    }[];
    export const pipeline: readonly [{
        readonly id: "takeoutOrderLifecycle__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle" {
    export interface CafeFlowCreateOrderInput {
        orderType: "mesa" | "takeout";
        status: "draft" | "sentToKitchen" | "inPreparation" | "ready" | "served" | "closed" | "cancelled";
        totalAmount: number;
        notes?: string;
        customerName?: string;
        customerPhone?: string;
        numberOfGuests?: number;
        closedAt?: string;
        cancelledAt?: string;
        cancellationReason?: string;
    }
    export interface CafeFlowCreateOrderOutput {
        orderId: string;
    }
    export interface CafeFlowAddOrderItemInput {
        quantity: number;
        unitPrice: number;
        totalPrice: number;
        observations?: string;
        status: "new" | "sentToKitchen" | "inPreparation" | "ready" | "served" | "cancelled";
    }
    export interface CafeFlowAddOrderItemOutput {
        id: string;
    }
    export interface CafeFlowCreateKitchenTicketInput {
        status: "open" | "inProgress" | "done" | "void";
    }
    export interface CafeFlowCreateKitchenTicketOutput {
        kitchenTicketId: string;
    }
    export interface CafeFlowUpdateOrderStatusInput {
        status: "draft" | "sentToKitchen" | "inPreparation" | "ready" | "served" | "closed" | "cancelled";
        closedAt?: string;
        cancelledAt?: string;
        cancellationReason?: string;
    }
    export interface CafeFlowUpdateOrderStatusOutput {
        orderId: string;
    }
}
declare module "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
    }[];
    export const pipeline: readonly [{
        readonly id: "viewOperationalDashboard__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard" {
    export interface CafeFlowViewOperationalDashboardInput {
        dailyShiftId?: string;
        shiftDate?: string;
        status?: "open" | "closed";
        openedAt?: string;
        closedAt?: string;
        createdAt?: string;
    }
    export interface CafeFlowViewOperationalDashboardOutputItem {
        dailyShiftId: string;
        shiftDate: string;
        status: "open" | "closed";
        openedAt: string;
        closedAt: string;
        openingCashBalance: number;
        closingCashBalance: number;
        totalSales: number;
    }
    export type CafeFlowViewOperationalDashboardOutput = CafeFlowViewOperationalDashboardOutputItem[];
}
declare module "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/aiPromotionSuggestions.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "aiPromotionSuggestions__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/aiPromotionSuggestions.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/aiPromotionSuggestions.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/aiPromotionSuggestions.defs.ts", "_102050_/l2/cafeFlow/web/shared/aiPromotionSuggestions.ts", "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.defs.ts", "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/aiPromotionSuggestions" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { CafeFlowAiPromotionSuggestionsOutputItem } from "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions";
    type ActionStatus = 'idle' | 'loading' | 'success' | 'error';
    export class CafeFlowAiPromotionSuggestionsBase extends CollabLitElement {
        status: string;
        aiPromotionSuggestionsState: ActionStatus;
        aiPromotionSuggestionsId: string;
        aiPromotionSuggestionsOrderId: string;
        aiPromotionSuggestionsMenuItemId: string;
        aiPromotionSuggestionsKitchenTicketId: string;
        aiPromotionSuggestionsStatus: string;
        aiPromotionSuggestionsCreatedAt: string;
        aiPromotionSuggestionsData: CafeFlowAiPromotionSuggestionsOutputItem[];
        protected message_pt: Record<string, string>;
        protected message_en: Record<string, string>;
        protected get msg(): Record<string, string>;
        loadAiPromotionSuggestions(): Promise<void>;
        handleAiPromotionSuggestionsClick(): void;
        setAiPromotionSuggestionsId(value: string): void;
        handleAiPromotionSuggestionsIdChange(e: Event): void;
        setAiPromotionSuggestionsOrderId(value: string): void;
        handleAiPromotionSuggestionsOrderIdChange(e: Event): void;
        setAiPromotionSuggestionsMenuItemId(value: string): void;
        handleAiPromotionSuggestionsMenuItemIdChange(e: Event): void;
        setAiPromotionSuggestionsKitchenTicketId(value: string): void;
        handleAiPromotionSuggestionsKitchenTicketIdChange(e: Event): void;
        setAiPromotionSuggestionsStatus(value: string): void;
        handleAiPromotionSuggestionsStatusChange(e: Event): void;
        setAiPromotionSuggestionsCreatedAt(value: string): void;
        handleAiPromotionSuggestionsCreatedAtChange(e: Event): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
    }
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/aiPromotionSuggestions" {
    import { CafeFlowAiPromotionSuggestionsBase } from "_102050_/l2/cafeFlow/web/shared/aiPromotionSuggestions";
    export class CafeFlowDesktopPage11AiPromotionSuggestionsPage extends CafeFlowAiPromotionSuggestionsBase {
        render(): any;
    }
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/aiSalesSummary.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                } | {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                    action?: undefined;
                    submitAction?: undefined;
                })[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        stateKey: string;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                        action?: undefined;
                        submitAction?: undefined;
                    })[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "aiSalesSummary__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/aiSalesSummary.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/aiSalesSummary.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/aiSalesSummary.defs.ts", "_102050_/l2/cafeFlow/web/shared/aiSalesSummary.ts", "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.defs.ts", "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/aiSalesSummary" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { CafeFlowAiSalesSummaryOutput } from "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary";
    export class CafeFlowAiSalesSummaryBase extends CollabLitElement {
        status: string;
        aiSalesSummaryState: 'idle' | 'loading' | 'success' | 'error';
        aiSalesSummaryDailyShiftId: string;
        aiSalesSummaryStatus: string;
        aiSalesSummaryClosedAt: string;
        aiSalesSummaryData: CafeFlowAiSalesSummaryOutput;
        protected get msg(): Record<string, string>;
        connectedCallback(): void;
        disconnectedCallback(): void;
        loadAiSalesSummary(): Promise<void>;
        handleAiSalesSummaryClick: () => void;
        setAiSalesSummaryDailyShiftId(value: string): void;
        handleAiSalesSummaryDailyShiftIdChange: (e: Event) => void;
        setAiSalesSummaryStatus(value: string): void;
        handleAiSalesSummaryStatusChange: (e: Event) => void;
        setAiSalesSummaryClosedAt(value: string): void;
        handleAiSalesSummaryClosedAtChange: (e: Event) => void;
    }
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/aiSalesSummary" {
    import { CafeFlowAiSalesSummaryBase } from "_102050_/l2/cafeFlow/web/shared/aiSalesSummary";
    export class CafeFlowDesktopPage11AiSalesSummaryPage extends CafeFlowAiSalesSummaryBase {
        render(): any;
    }
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/browseMenuForPos.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        stateKey: string;
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "browseMenuForPos__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/browseMenuForPos.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/browseMenuForPos.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/browseMenuForPos.defs.ts", "_102050_/l2/cafeFlow/web/shared/browseMenuForPos.ts", "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.defs.ts", "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/browseMenuForPos" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { CafeFlowBrowseMenuForPosOutputItem } from "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos";
    export class CafeFlowBrowseMenuForPosBase extends CollabLitElement {
        status: string;
        browseMenuForPosState: 'idle' | 'loading' | 'success' | 'error';
        browseMenuForPosMenuItemId: string;
        browseMenuForPosMenuCategoryId: string;
        browseMenuForPosName: string;
        browseMenuForPosStatus: string;
        browseMenuForPosCreatedAt: string;
        browseMenuForPosUpdatedAt: string;
        browseMenuForPosData: CafeFlowBrowseMenuForPosOutputItem[];
        protected get msg(): Record<string, string>;
        connectedCallback(): void;
        disconnectedCallback(): void;
        loadBrowseMenuForPos(): Promise<void>;
        handleBrowseMenuForPosClick: (event: Event) => void;
        setBrowseMenuForPosMenuItemId(value: string): void;
        handleBrowseMenuForPosMenuItemIdChange: (event: Event) => void;
        setBrowseMenuForPosMenuCategoryId(value: string): void;
        handleBrowseMenuForPosMenuCategoryIdChange: (event: Event) => void;
        setBrowseMenuForPosName(value: string): void;
        handleBrowseMenuForPosNameChange: (event: Event) => void;
        setBrowseMenuForPosStatus(value: string): void;
        handleBrowseMenuForPosStatusChange: (event: Event) => void;
        setBrowseMenuForPosCreatedAt(value: string): void;
        handleBrowseMenuForPosCreatedAtChange: (event: Event) => void;
        setBrowseMenuForPosUpdatedAt(value: string): void;
        handleBrowseMenuForPosUpdatedAtChange: (event: Event) => void;
    }
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/browseMenuForPos" {
    import { CafeFlowBrowseMenuForPosBase } from "_102050_/l2/cafeFlow/web/shared/browseMenuForPos";
    export class CafeFlowDesktopPage11BrowseMenuForPosPage extends CafeFlowBrowseMenuForPosBase {
        render(): any;
    }
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/closeDailyShift.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "closeDailyShift__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/closeDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/closeDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/closeDailyShift.defs.ts", "_102050_/l2/cafeFlow/web/shared/closeDailyShift.ts", "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.defs.ts", "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/closeDailyShift" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    const message_en: {
        "closeDailyShift.section.main": string;
        "closeDailyShift.update.title": string;
        "closeDailyShift.record.title": string;
        "closeDailyShift.summary.title": string;
        "closeDailyShift.action.updateDailyShiftStatus": string;
        "closeDailyShift.action.recordClosingCashMovement": string;
        "field.dailyShiftId": string;
        "field.shiftDate": string;
        "field.status": string;
        "field.openedAt": string;
        "field.closedAt": string;
        "field.openingCashBalance": string;
        "field.closingCashBalance": string;
        "field.totalSales": string;
        "field.totalPayments": string;
        "field.closingNotes": string;
    };
    type MessageType = typeof message_en;
    export class CafeFlowCloseDailyShiftBase extends CollabLitElement {
        status: string;
        updateDailyShiftStatusState: "idle" | "loading" | "success" | "error";
        updateDailyShiftStatusDailyShiftId: string;
        updateDailyShiftStatusShiftDate: string;
        updateDailyShiftStatusStatus: string;
        updateDailyShiftStatusOpenedAt: string;
        updateDailyShiftStatusClosedAt: string;
        updateDailyShiftStatusOpeningCashBalance: string;
        updateDailyShiftStatusClosingCashBalance: string;
        updateDailyShiftStatusTotalSales: string;
        updateDailyShiftStatusTotalPayments: string;
        updateDailyShiftStatusClosingNotes: string;
        recordClosingCashMovementState: "idle" | "loading" | "success" | "error";
        recordClosingCashMovementShiftDate: string;
        recordClosingCashMovementStatus: string;
        recordClosingCashMovementOpenedAt: string;
        recordClosingCashMovementClosedAt: string;
        recordClosingCashMovementOpeningCashBalance: string;
        recordClosingCashMovementClosingCashBalance: string;
        recordClosingCashMovementTotalSales: string;
        recordClosingCashMovementTotalPayments: string;
        recordClosingCashMovementClosingNotes: string;
        protected get msg(): MessageType;
        setUpdateDailyShiftStatusDailyShiftId(value: string): void;
        handleUpdateDailyShiftStatusDailyShiftIdChange(e: Event): void;
        setUpdateDailyShiftStatusShiftDate(value: string): void;
        handleUpdateDailyShiftStatusShiftDateChange(e: Event): void;
        setUpdateDailyShiftStatusStatus(value: string): void;
        handleUpdateDailyShiftStatusStatusChange(e: Event): void;
        setUpdateDailyShiftStatusOpenedAt(value: string): void;
        handleUpdateDailyShiftStatusOpenedAtChange(e: Event): void;
        setUpdateDailyShiftStatusClosedAt(value: string): void;
        handleUpdateDailyShiftStatusClosedAtChange(e: Event): void;
        setUpdateDailyShiftStatusOpeningCashBalance(value: string): void;
        handleUpdateDailyShiftStatusOpeningCashBalanceChange(e: Event): void;
        setUpdateDailyShiftStatusClosingCashBalance(value: string): void;
        handleUpdateDailyShiftStatusClosingCashBalanceChange(e: Event): void;
        setUpdateDailyShiftStatusTotalSales(value: string): void;
        handleUpdateDailyShiftStatusTotalSalesChange(e: Event): void;
        setUpdateDailyShiftStatusTotalPayments(value: string): void;
        handleUpdateDailyShiftStatusTotalPaymentsChange(e: Event): void;
        setUpdateDailyShiftStatusClosingNotes(value: string): void;
        handleUpdateDailyShiftStatusClosingNotesChange(e: Event): void;
        setRecordClosingCashMovementShiftDate(value: string): void;
        handleRecordClosingCashMovementShiftDateChange(e: Event): void;
        setRecordClosingCashMovementStatus(value: string): void;
        handleRecordClosingCashMovementStatusChange(e: Event): void;
        setRecordClosingCashMovementOpenedAt(value: string): void;
        handleRecordClosingCashMovementOpenedAtChange(e: Event): void;
        setRecordClosingCashMovementClosedAt(value: string): void;
        handleRecordClosingCashMovementClosedAtChange(e: Event): void;
        setRecordClosingCashMovementOpeningCashBalance(value: string): void;
        handleRecordClosingCashMovementOpeningCashBalanceChange(e: Event): void;
        setRecordClosingCashMovementClosingCashBalance(value: string): void;
        handleRecordClosingCashMovementClosingCashBalanceChange(e: Event): void;
        setRecordClosingCashMovementTotalSales(value: string): void;
        handleRecordClosingCashMovementTotalSalesChange(e: Event): void;
        setRecordClosingCashMovementTotalPayments(value: string): void;
        handleRecordClosingCashMovementTotalPaymentsChange(e: Event): void;
        setRecordClosingCashMovementClosingNotes(value: string): void;
        handleRecordClosingCashMovementClosingNotesChange(e: Event): void;
        updateDailyShiftStatus(): Promise<void>;
        handleUpdateDailyShiftStatusClick(e: Event): void;
        recordClosingCashMovement(): Promise<void>;
        handleRecordClosingCashMovementClick(e: Event): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
    }
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/closeDailyShift" {
    import { CafeFlowCloseDailyShiftBase } from "_102050_/l2/cafeFlow/web/shared/closeDailyShift";
    export class CafeFlowDesktopPage11CloseDailyShiftPage extends CafeFlowCloseDailyShiftBase {
        render(): any;
    }
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/consumeIngredientsOnConfirmation.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    action: string;
                    submitAction: string;
                    order: number;
                } | {
                    id: string;
                    intent: string;
                    order: number;
                    action?: undefined;
                    submitAction?: undefined;
                })[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        action?: undefined;
                        submitAction?: undefined;
                    })[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "consumeIngredientsOnConfirmation__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/consumeIngredientsOnConfirmation.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/consumeIngredientsOnConfirmation.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/consumeIngredientsOnConfirmation.defs.ts", "_102050_/l2/cafeFlow/web/shared/consumeIngredientsOnConfirmation.ts", "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.defs.ts", "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.ts"];
        readonly dependsOn: readonly ["consumeIngredientsOnConfirmation__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/consumeIngredientsOnConfirmation" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class CafeFlowConsumeIngredientsOnConfirmationBase extends CollabLitElement {
        status: string;
        createStockConsumptionState: 'idle' | 'loading' | 'success' | 'error';
        createStockConsumptionQuantity: string | number;
        createStockConsumptionStatus: string;
        createStockConsumptionConsumedAt: string;
        protected get msg(): Record<string, string>;
        connectedCallback(): void;
        disconnectedCallback(): void;
        setCreateStockConsumptionQuantity(value: string | number): void;
        handleCreateStockConsumptionQuantityChange(e: Event): void;
        setCreateStockConsumptionStatus(value: string): void;
        handleCreateStockConsumptionStatusChange(e: Event): void;
        setCreateStockConsumptionConsumedAt(value: string): void;
        handleCreateStockConsumptionConsumedAtChange(e: Event): void;
        createStockConsumption(): Promise<void>;
        handleCreateStockConsumptionClick(): void;
    }
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/consumeIngredientsOnConfirmation" {
    import { CafeFlowConsumeIngredientsOnConfirmationBase } from "_102050_/l2/cafeFlow/web/shared/consumeIngredientsOnConfirmation";
    export class CafeFlowDesktopPage11ConsumeIngredientsOnConfirmationPage extends CafeFlowConsumeIngredientsOnConfirmationBase {
        render(): any;
    }
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/dineInOrderLifecycle.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "dineInOrderLifecycle__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/dineInOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/dineInOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/dineInOrderLifecycle.defs.ts", "_102050_/l2/cafeFlow/web/shared/dineInOrderLifecycle.ts", "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.defs.ts", "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/dineInOrderLifecycle" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    const message_en: {
        "dineInOrderLifecycle.section.main.title": string;
        "dineInOrderLifecycle.organism.createOrder.title": string;
        "dineInOrderLifecycle.stage.createOrder.title": string;
        "dineInOrderLifecycle.field.orderType.label": string;
        "dineInOrderLifecycle.field.status.label": string;
        "dineInOrderLifecycle.field.totalAmount.label": string;
        "dineInOrderLifecycle.field.notes.label": string;
        "dineInOrderLifecycle.field.customerName.label": string;
        "dineInOrderLifecycle.field.customerPhone.label": string;
        "dineInOrderLifecycle.field.numberOfGuests.label": string;
        "dineInOrderLifecycle.field.closedAt.label": string;
        "dineInOrderLifecycle.field.cancelledAt.label": string;
        "dineInOrderLifecycle.field.cancellationReason.label": string;
        "dineInOrderLifecycle.action.createOrder.label": string;
        "dineInOrderLifecycle.organism.addOrderItem.title": string;
        "dineInOrderLifecycle.stage.addOrderItem.title": string;
        "dineInOrderLifecycle.field.quantity.label": string;
        "dineInOrderLifecycle.field.unitPrice.label": string;
        "dineInOrderLifecycle.field.totalPrice.label": string;
        "dineInOrderLifecycle.field.observations.label": string;
        "dineInOrderLifecycle.field.itemStatus.label": string;
        "dineInOrderLifecycle.action.addOrderItem.label": string;
        "dineInOrderLifecycle.organism.createKitchenTicket.title": string;
        "dineInOrderLifecycle.stage.createKitchenTicket.title": string;
        "dineInOrderLifecycle.field.kitchenTicketStatus.label": string;
        "dineInOrderLifecycle.action.createKitchenTicket.label": string;
        "dineInOrderLifecycle.organism.updateOrderStatus.title": string;
        "dineInOrderLifecycle.stage.updateOrderStatus.title": string;
        "dineInOrderLifecycle.action.updateOrderStatus.label": string;
        "dineInOrderLifecycle.organism.updateTableStatus.title": string;
        "dineInOrderLifecycle.stage.updateTableStatus.title": string;
        "dineInOrderLifecycle.field.tableStatus.label": string;
        "dineInOrderLifecycle.field.currentChargesTotal.label": string;
        "dineInOrderLifecycle.field.openedAt.label": string;
        "dineInOrderLifecycle.action.updateTableStatus.label": string;
        "dineInOrderLifecycle.organism.review.title": string;
        "dineInOrderLifecycle.stage.review.title": string;
    };
    type MessageType = typeof message_en;
    export class CafeFlowDineInOrderLifecycleBase extends CollabLitElement {
        status: string;
        createOrderState: "idle" | "loading" | "success" | "error";
        createOrderOrderType: string;
        createOrderStatus: string;
        createOrderTotalAmount: string;
        createOrderNotes: string;
        createOrderCustomerName: string;
        createOrderCustomerPhone: string;
        createOrderNumberOfGuests: string;
        createOrderClosedAt: string;
        createOrderCancelledAt: string;
        createOrderCancellationReason: string;
        addOrderItemState: "idle" | "loading" | "success" | "error";
        addOrderItemQuantity: string;
        addOrderItemUnitPrice: string;
        addOrderItemTotalPrice: string;
        addOrderItemObservations: string;
        addOrderItemStatus: string;
        createKitchenTicketState: "idle" | "loading" | "success" | "error";
        createKitchenTicketStatus: string;
        updateOrderStatusState: "idle" | "loading" | "success" | "error";
        updateOrderStatusStatus: string;
        updateOrderStatusClosedAt: string;
        updateOrderStatusCancelledAt: string;
        updateOrderStatusCancellationReason: string;
        updateTableStatusState: "idle" | "loading" | "success" | "error";
        updateTableStatusStatus: string;
        updateTableStatusCurrentChargesTotal: string;
        updateTableStatusOpenedAt: string;
        updateTableStatusClosedAt: string;
        protected get msg(): MessageType;
        setCreateOrderOrderType(value: string): void;
        handleCreateOrderOrderTypeChange(e: Event): void;
        setCreateOrderStatus(value: string): void;
        handleCreateOrderStatusChange(e: Event): void;
        setCreateOrderTotalAmount(value: string): void;
        handleCreateOrderTotalAmountChange(e: Event): void;
        setCreateOrderNotes(value: string): void;
        handleCreateOrderNotesChange(e: Event): void;
        setCreateOrderCustomerName(value: string): void;
        handleCreateOrderCustomerNameChange(e: Event): void;
        setCreateOrderCustomerPhone(value: string): void;
        handleCreateOrderCustomerPhoneChange(e: Event): void;
        setCreateOrderNumberOfGuests(value: string): void;
        handleCreateOrderNumberOfGuestsChange(e: Event): void;
        setCreateOrderClosedAt(value: string): void;
        handleCreateOrderClosedAtChange(e: Event): void;
        setCreateOrderCancelledAt(value: string): void;
        handleCreateOrderCancelledAtChange(e: Event): void;
        setCreateOrderCancellationReason(value: string): void;
        handleCreateOrderCancellationReasonChange(e: Event): void;
        setAddOrderItemQuantity(value: string): void;
        handleAddOrderItemQuantityChange(e: Event): void;
        setAddOrderItemUnitPrice(value: string): void;
        handleAddOrderItemUnitPriceChange(e: Event): void;
        setAddOrderItemTotalPrice(value: string): void;
        handleAddOrderItemTotalPriceChange(e: Event): void;
        setAddOrderItemObservations(value: string): void;
        handleAddOrderItemObservationsChange(e: Event): void;
        setAddOrderItemStatus(value: string): void;
        handleAddOrderItemStatusChange(e: Event): void;
        setCreateKitchenTicketStatus(value: string): void;
        handleCreateKitchenTicketStatusChange(e: Event): void;
        setUpdateOrderStatusStatus(value: string): void;
        handleUpdateOrderStatusStatusChange(e: Event): void;
        setUpdateOrderStatusClosedAt(value: string): void;
        handleUpdateOrderStatusClosedAtChange(e: Event): void;
        setUpdateOrderStatusCancelledAt(value: string): void;
        handleUpdateOrderStatusCancelledAtChange(e: Event): void;
        setUpdateOrderStatusCancellationReason(value: string): void;
        handleUpdateOrderStatusCancellationReasonChange(e: Event): void;
        setUpdateTableStatusStatus(value: string): void;
        handleUpdateTableStatusStatusChange(e: Event): void;
        setUpdateTableStatusCurrentChargesTotal(value: string): void;
        handleUpdateTableStatusCurrentChargesTotalChange(e: Event): void;
        setUpdateTableStatusOpenedAt(value: string): void;
        handleUpdateTableStatusOpenedAtChange(e: Event): void;
        setUpdateTableStatusClosedAt(value: string): void;
        handleUpdateTableStatusClosedAtChange(e: Event): void;
        createOrder(): Promise<void>;
        handleCreateOrderClick(): void;
        addOrderItem(): Promise<void>;
        handleAddOrderItemClick(): void;
        createKitchenTicket(): Promise<void>;
        handleCreateKitchenTicketClick(): void;
        updateOrderStatus(): Promise<void>;
        handleUpdateOrderStatusClick(): void;
        updateTableStatus(): Promise<void>;
        handleUpdateTableStatusClick(): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
    }
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/dineInOrderLifecycle" {
    import { CafeFlowDineInOrderLifecycleBase } from "_102050_/l2/cafeFlow/web/shared/dineInOrderLifecycle";
    export class CafeFlowDesktopPage11DineInOrderLifecyclePage extends CafeFlowDineInOrderLifecycleBase {
        render(): any;
    }
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/generateShiftCloseReport.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        stateKey: string;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            inputType?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                    })[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "generateShiftCloseReport__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/generateShiftCloseReport.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/generateShiftCloseReport.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/generateShiftCloseReport.defs.ts", "_102050_/l2/cafeFlow/web/shared/generateShiftCloseReport.ts", "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.defs.ts", "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/generateShiftCloseReport" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { CafeFlowGenerateShiftCloseReportOutput } from "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport";
    export class CafeFlowGenerateShiftCloseReportBase extends CollabLitElement {
        status: string;
        generateShiftCloseReportState: 'idle' | 'loading' | 'success' | 'error';
        generateShiftCloseReportStatus: string;
        generateShiftCloseReportOpenedAt: string;
        generateShiftCloseReportClosedAt: string;
        generateShiftCloseReportData: CafeFlowGenerateShiftCloseReportOutput;
        protected get msg(): Record<string, string>;
        connectedCallback(): void;
        disconnectedCallback(): void;
        setGenerateShiftCloseReportStatus(value: string): void;
        handleGenerateShiftCloseReportStatusChange(e: Event): void;
        setGenerateShiftCloseReportOpenedAt(value: string): void;
        handleGenerateShiftCloseReportOpenedAtChange(e: Event): void;
        setGenerateShiftCloseReportClosedAt(value: string): void;
        handleGenerateShiftCloseReportClosedAtChange(e: Event): void;
        loadGenerateShiftCloseReport(): Promise<void>;
        handleGenerateShiftCloseReportClick(e: Event): void;
    }
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/generateShiftCloseReport" {
    import { CafeFlowGenerateShiftCloseReportBase } from "_102050_/l2/cafeFlow/web/shared/generateShiftCloseReport";
    export class CafeFlowDesktopPage11GenerateShiftCloseReportPage extends CafeFlowGenerateShiftCloseReportBase {
        render(): any;
    }
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/kitchenProductionFlow.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            })[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    }[];
                })[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "kitchenProductionFlow__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/kitchenProductionFlow.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/kitchenProductionFlow.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/kitchenProductionFlow.defs.ts", "_102050_/l2/cafeFlow/web/shared/kitchenProductionFlow.ts", "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.defs.ts", "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/kitchenProductionFlow" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { CafeFlowViewKitchenTicketsOutput } from "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow";
    const message_en: {
        "kitchenProductionFlow.section.main.title": string;
        "kitchenProductionFlow.organism.viewKitchenTickets.title": string;
        "kitchenProductionFlow.intention.viewKitchenTickets.list.title": string;
        "kitchenProductionFlow.field.kitchenTicketId": string;
        "kitchenProductionFlow.field.orderId": string;
        "kitchenProductionFlow.field.status": string;
        "kitchenProductionFlow.field.createdAt": string;
        "kitchenProductionFlow.field.updatedAt": string;
        "kitchenProductionFlow.filter.kitchenTicketId": string;
        "kitchenProductionFlow.filter.orderId": string;
        "kitchenProductionFlow.filter.status": string;
        "kitchenProductionFlow.filter.createdAt": string;
        "kitchenProductionFlow.filter.updatedAt": string;
        "kitchenProductionFlow.action.viewKitchenTickets": string;
        "kitchenProductionFlow.organism.updateKitchenTicketStatus.title": string;
        "kitchenProductionFlow.intention.updateKitchenTicketStatus.form.title": string;
        "kitchenProductionFlow.field.kitchenTicket.status": string;
        "kitchenProductionFlow.action.updateKitchenTicketStatus": string;
        "kitchenProductionFlow.organism.updateOrderItemStatus.title": string;
        "kitchenProductionFlow.intention.updateOrderItemStatus.form.title": string;
        "kitchenProductionFlow.field.orderItem.status": string;
        "kitchenProductionFlow.action.updateOrderItemStatus": string;
        "kitchenProductionFlow.organism.summary.title": string;
        "kitchenProductionFlow.intention.summary.title": string;
    };
    type MessageType = typeof message_en;
    export class CafeFlowKitchenProductionFlowBase extends CollabLitElement {
        status: string;
        viewKitchenTicketsState: 'idle' | 'loading' | 'success' | 'error';
        viewKitchenTicketsKitchenTicketId: string;
        viewKitchenTicketsOrderId: string;
        viewKitchenTicketsStatus: 'open' | 'inProgress' | 'done' | 'void' | '';
        viewKitchenTicketsCreatedAt: string;
        viewKitchenTicketsUpdatedAt: string;
        viewKitchenTicketsData: CafeFlowViewKitchenTicketsOutput;
        updateKitchenTicketStatusState: 'idle' | 'loading' | 'success' | 'error';
        updateKitchenTicketStatusStatus: 'open' | 'inProgress' | 'done' | 'void' | '';
        updateOrderItemStatusState: 'idle' | 'loading' | 'success' | 'error';
        updateOrderItemStatusStatus: 'new' | 'sentToKitchen' | 'inPreparation' | 'ready' | 'served' | 'cancelled' | '';
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        setViewKitchenTicketsKitchenTicketId(value: string): void;
        handleViewKitchenTicketsKitchenTicketIdChange(event: Event): void;
        setViewKitchenTicketsOrderId(value: string): void;
        handleViewKitchenTicketsOrderIdChange(event: Event): void;
        setViewKitchenTicketsStatus(value: 'open' | 'inProgress' | 'done' | 'void' | ''): void;
        handleViewKitchenTicketsStatusChange(event: Event): void;
        setViewKitchenTicketsCreatedAt(value: string): void;
        handleViewKitchenTicketsCreatedAtChange(event: Event): void;
        setViewKitchenTicketsUpdatedAt(value: string): void;
        handleViewKitchenTicketsUpdatedAtChange(event: Event): void;
        setUpdateKitchenTicketStatusStatus(value: 'open' | 'inProgress' | 'done' | 'void' | ''): void;
        handleUpdateKitchenTicketStatusStatusChange(event: Event): void;
        setUpdateOrderItemStatusStatus(value: 'new' | 'sentToKitchen' | 'inPreparation' | 'ready' | 'served' | 'cancelled' | ''): void;
        handleUpdateOrderItemStatusStatusChange(event: Event): void;
        loadViewKitchenTickets(): Promise<void>;
        handleViewKitchenTicketsClick(): void;
        updateKitchenTicketStatus(): Promise<void>;
        handleUpdateKitchenTicketStatusClick(): void;
        updateOrderItemStatus(): Promise<void>;
        handleUpdateOrderItemStatusClick(): void;
    }
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/kitchenProductionFlow" {
    import { CafeFlowKitchenProductionFlowBase } from "_102050_/l2/cafeFlow/web/shared/kitchenProductionFlow";
    export class CafeFlowDesktopPage11KitchenProductionFlowPage extends CafeFlowKitchenProductionFlowBase {
        render(): any;
    }
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/manageInventoryItems.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    order: number;
                    action?: undefined;
                    submitAction?: undefined;
                } | {
                    id: string;
                    intent: string;
                    action: string;
                    submitAction: string;
                    order: number;
                })[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        action?: undefined;
                        submitAction?: undefined;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    })[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "manageInventoryItems__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageInventoryItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageInventoryItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/manageInventoryItems.defs.ts", "_102050_/l2/cafeFlow/web/shared/manageInventoryItems.ts", "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.defs.ts", "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/manageInventoryItems" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class CafeFlowManageInventoryItemsBase extends CollabLitElement {
        status: string;
        manageInventoryItemsState: 'idle' | 'loading' | 'success' | 'error';
        manageInventoryItemsName: string;
        manageInventoryItemsDescription: string;
        manageInventoryItemsUnit: string;
        manageInventoryItemsCurrentQuantity: string;
        manageInventoryItemsMinimumLevel: string;
        manageInventoryItemsStatus: string;
        protected get msg(): Record<string, string>;
        connectedCallback(): void;
        disconnectedCallback(): void;
        setManageInventoryItemsName(value: string): void;
        handleManageInventoryItemsNameChange(e: Event): void;
        setManageInventoryItemsDescription(value: string): void;
        handleManageInventoryItemsDescriptionChange(e: Event): void;
        setManageInventoryItemsUnit(value: string): void;
        handleManageInventoryItemsUnitChange(e: Event): void;
        setManageInventoryItemsCurrentQuantity(value: string): void;
        handleManageInventoryItemsCurrentQuantityChange(e: Event): void;
        setManageInventoryItemsMinimumLevel(value: string): void;
        handleManageInventoryItemsMinimumLevelChange(e: Event): void;
        setManageInventoryItemsStatus(value: string): void;
        handleManageInventoryItemsStatusChange(e: Event): void;
        manageInventoryItems(): Promise<void>;
        handleManageInventoryItemsClick(e: Event): void;
    }
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/manageInventoryItems" {
    import { CafeFlowManageInventoryItemsBase } from "_102050_/l2/cafeFlow/web/shared/manageInventoryItems";
    export class CafeFlowDesktopPage11ManageInventoryItemsPage extends CafeFlowManageInventoryItemsBase {
        render(): any;
    }
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuCategories.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: string[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: string[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "manageMenuCategories__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuCategories.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuCategories.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/manageMenuCategories.defs.ts", "_102050_/l2/cafeFlow/web/shared/manageMenuCategories.ts", "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.defs.ts", "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/manageMenuCategories" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    const message_en: {
        "manageMenuCategories.section.main.title": string;
        "manageMenuCategories.organism.form.title": string;
        "manageMenuCategories.intention.commandForm.title": string;
        "manageMenuCategories.field.menuCategoryId.label": string;
        "manageMenuCategories.field.name.label": string;
        "manageMenuCategories.field.description.label": string;
        "manageMenuCategories.field.status.label": string;
        "manageMenuCategories.action.submit.label": string;
    };
    type MessageType = typeof message_en;
    export class CafeFlowManageMenuCategoriesBase extends CollabLitElement {
        status: string;
        manageMenuCategoriesState: 'idle' | 'loading' | 'success' | 'error';
        manageMenuCategoriesMenuCategoryId: string;
        manageMenuCategoriesName: string;
        manageMenuCategoriesDescription: string;
        manageMenuCategoriesStatus: 'active' | 'inactive' | '';
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        setManageMenuCategoriesMenuCategoryId(value: string): void;
        handleManageMenuCategoriesMenuCategoryIdChange(event: Event): void;
        setManageMenuCategoriesName(value: string): void;
        handleManageMenuCategoriesNameChange(event: Event): void;
        setManageMenuCategoriesDescription(value: string): void;
        handleManageMenuCategoriesDescriptionChange(event: Event): void;
        setManageMenuCategoriesStatus(value: 'active' | 'inactive' | ''): void;
        handleManageMenuCategoriesStatusChange(event: Event): void;
        manageMenuCategories(): Promise<void>;
        handleManageMenuCategoriesClick(event?: Event): void;
    }
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuCategories" {
    import { CafeFlowManageMenuCategoriesBase } from "_102050_/l2/cafeFlow/web/shared/manageMenuCategories";
    export class CafeFlowDesktopPage11ManageMenuCategoriesPage extends CafeFlowManageMenuCategoriesBase {
        render(): any;
    }
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuItems.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    })[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "manageMenuItems__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/manageMenuItems.defs.ts", "_102050_/l2/cafeFlow/web/shared/manageMenuItems.ts", "_102050_/l2/cafeFlow/web/contracts/manageMenuItems.defs.ts", "_102050_/l2/cafeFlow/web/contracts/manageMenuItems.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/manageMenuItems" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { CafeFlowManageMenuItemsInput } from "_102050_/l2/cafeFlow/web/contracts/manageMenuItems";
    const message_en: {
        "manageMenuItems.section.title": string;
        "manageMenuItems.organism.title": string;
        "manageMenuItems.form.title": string;
        "manageMenuItems.field.menuItemId": string;
        "manageMenuItems.field.menuCategoryId": string;
        "manageMenuItems.field.name": string;
        "manageMenuItems.field.description": string;
        "manageMenuItems.field.price": string;
        "manageMenuItems.field.status": string;
        "manageMenuItems.status.draft": string;
        "manageMenuItems.status.active": string;
        "manageMenuItems.status.inactive": string;
        "manageMenuItems.action.submit": string;
    };
    type MessageType = typeof message_en;
    export class CafeFlowManageMenuItemsBase extends CollabLitElement {
        status: string;
        manageMenuItemsState: 'idle' | 'loading' | 'success' | 'error';
        manageMenuItemsMenuItemId: string;
        manageMenuItemsMenuCategoryId: string;
        manageMenuItemsName: string;
        manageMenuItemsDescription: string;
        manageMenuItemsPrice: CafeFlowManageMenuItemsInput['price'];
        manageMenuItemsStatus: CafeFlowManageMenuItemsInput['status'];
        private readonly stateKeys;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        setManageMenuItemsMenuItemId(value: string): void;
        handleManageMenuItemsMenuItemIdChange(event: Event): void;
        setManageMenuItemsMenuCategoryId(value: string): void;
        handleManageMenuItemsMenuCategoryIdChange(event: Event): void;
        setManageMenuItemsName(value: string): void;
        handleManageMenuItemsNameChange(event: Event): void;
        setManageMenuItemsDescription(value: string): void;
        handleManageMenuItemsDescriptionChange(event: Event): void;
        setManageMenuItemsPrice(value: CafeFlowManageMenuItemsInput['price']): void;
        handleManageMenuItemsPriceChange(event: Event): void;
        setManageMenuItemsStatus(value: CafeFlowManageMenuItemsInput['status']): void;
        handleManageMenuItemsStatusChange(event: Event): void;
        manageMenuItems(): Promise<void>;
        handleManageMenuItemsClick(): Promise<void>;
    }
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuItems" {
    import { CafeFlowManageMenuItemsBase } from "_102050_/l2/cafeFlow/web/shared/manageMenuItems";
    export class CafeFlowDesktopPage11ManageMenuItemsPage extends CafeFlowManageMenuItemsBase {
        render(): any;
    }
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/manageTables.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: string[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: string[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "manageTables__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageTables.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageTables.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/manageTables.defs.ts", "_102050_/l2/cafeFlow/web/shared/manageTables.ts", "_102050_/l2/cafeFlow/web/contracts/manageTables.defs.ts", "_102050_/l2/cafeFlow/web/contracts/manageTables.ts"];
        readonly dependsOn: readonly ["manageTables__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/manageTables" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { CafeFlowManageTablesInput } from "_102050_/l2/cafeFlow/web/contracts/manageTables";
    const message_en: {
        "manageTables.section.title": string;
        "manageTables.organism.title": string;
        "manageTables.form.title": string;
        "manageTables.field.tableId": string;
        "manageTables.field.number": string;
        "manageTables.field.status": string;
        "manageTables.action.submit": string;
        "manageTables.status.title": string;
    };
    type MessageType = typeof message_en;
    export class CafeFlowManageTablesBase extends CollabLitElement {
        status: string;
        manageTablesState: 'idle' | 'loading' | 'success' | 'error';
        manageTablesTableId: string;
        manageTablesNumber: string;
        manageTablesStatus: CafeFlowManageTablesInput['status'] | '';
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        stateChanged(stateKey: string, value: unknown): void;
        setManageTablesTableId(value: string): void;
        handleManageTablesTableIdChange(event: Event): void;
        setManageTablesNumber(value: string): void;
        handleManageTablesNumberChange(event: Event): void;
        setManageTablesStatus(value: CafeFlowManageTablesInput['status'] | ''): void;
        handleManageTablesStatusChange(event: Event): void;
        manageTables(): Promise<void>;
        handleManageTablesClick(): Promise<void>;
    }
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/manageTables" {
    import { CafeFlowManageTablesBase } from "_102050_/l2/cafeFlow/web/shared/manageTables";
    export class CafeFlowDesktopPage11ManageTablesPage extends CafeFlowManageTablesBase {
        render(): any;
    }
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/openDailyShift.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: string[];
                rulesApplied: any[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                } | {
                    id: string;
                    intent: string;
                    order: number;
                    submitAction?: undefined;
                })[];
            })[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: string[];
                    rulesApplied: any[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        submitAction?: undefined;
                    })[];
                })[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "openDailyShift__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/openDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/openDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/openDailyShift.defs.ts", "_102050_/l2/cafeFlow/web/shared/openDailyShift.ts", "_102050_/l2/cafeFlow/web/contracts/openDailyShift.defs.ts", "_102050_/l2/cafeFlow/web/contracts/openDailyShift.ts"];
        readonly dependsOn: readonly ["openDailyShift__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/openDailyShift" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    type ActionStatus = 'idle' | 'loading' | 'success' | 'error';
    export class CafeFlowOpenDailyShiftBase extends CollabLitElement {
        status: string;
        createDailyShiftState: ActionStatus;
        createDailyShiftShiftDate: string;
        createDailyShiftStatus: string;
        createDailyShiftOpenedAt: string;
        createDailyShiftOpeningCashBalance: string;
        recordOpeningCashMovementState: ActionStatus;
        recordOpeningCashMovementMovementType: string;
        recordOpeningCashMovementAmount: string;
        recordOpeningCashMovementReason: string;
        protected get msg(): Record<string, string>;
        setCreateDailyShiftShiftDate(value: string): void;
        handleCreateDailyShiftShiftDateChange(e: Event): void;
        setCreateDailyShiftStatus(value: string): void;
        handleCreateDailyShiftStatusChange(e: Event): void;
        setCreateDailyShiftOpenedAt(value: string): void;
        handleCreateDailyShiftOpenedAtChange(e: Event): void;
        setCreateDailyShiftOpeningCashBalance(value: string): void;
        handleCreateDailyShiftOpeningCashBalanceChange(e: Event): void;
        setRecordOpeningCashMovementMovementType(value: string): void;
        handleRecordOpeningCashMovementMovementTypeChange(e: Event): void;
        setRecordOpeningCashMovementAmount(value: string): void;
        handleRecordOpeningCashMovementAmountChange(e: Event): void;
        setRecordOpeningCashMovementReason(value: string): void;
        handleRecordOpeningCashMovementReasonChange(e: Event): void;
        createDailyShift(): Promise<void>;
        handleCreateDailyShiftClick(): void;
        recordOpeningCashMovement(): Promise<void>;
        handleRecordOpeningCashMovementClick(): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
    }
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/openDailyShift" {
    import { CafeFlowOpenDailyShiftBase } from "_102050_/l2/cafeFlow/web/shared/openDailyShift";
    export class CafeFlowDesktopPage11OpenDailyShiftPage extends CafeFlowOpenDailyShiftBase {
        render(): any;
    }
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/recordPayment.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "recordPayment__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/recordPayment.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/recordPayment.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/recordPayment.defs.ts", "_102050_/l2/cafeFlow/web/shared/recordPayment.ts", "_102050_/l2/cafeFlow/web/contracts/recordPayment.defs.ts", "_102050_/l2/cafeFlow/web/contracts/recordPayment.ts"];
        readonly dependsOn: readonly ["recordPayment__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/recordPayment" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    type ActionStatus = 'idle' | 'loading' | 'success' | 'error';
    export class CafeFlowRecordPaymentBase extends CollabLitElement {
        status: string;
        recordPaymentState: ActionStatus;
        recordPaymentMethod: string;
        recordPaymentAmount: string;
        recordPaymentStatus: string;
        protected get msg(): Record<string, string>;
        connectedCallback(): void;
        disconnectedCallback(): void;
        setRecordPaymentMethod(value: string): void;
        handleRecordPaymentMethodChange(e: Event): void;
        setRecordPaymentAmount(value: string): void;
        handleRecordPaymentAmountChange(e: Event): void;
        setRecordPaymentStatus(value: string): void;
        handleRecordPaymentStatusChange(e: Event): void;
        recordPayment(): Promise<void>;
        handleRecordPaymentClick(e: Event): void;
    }
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/recordPayment" {
    import { CafeFlowRecordPaymentBase } from "_102050_/l2/cafeFlow/web/shared/recordPayment";
    export class CafeFlowDesktopPage11RecordPaymentPage extends CafeFlowRecordPaymentBase {
        render(): any;
    }
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/takeoutOrderLifecycle.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: any[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            })[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: any[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                })[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "takeoutOrderLifecycle__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/takeoutOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/takeoutOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/takeoutOrderLifecycle.defs.ts", "_102050_/l2/cafeFlow/web/shared/takeoutOrderLifecycle.ts", "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.defs.ts", "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.ts"];
        readonly dependsOn: readonly ["takeoutOrderLifecycle__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/takeoutOrderLifecycle" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { CafeFlowCreateOrderInput, CafeFlowAddOrderItemInput, CafeFlowCreateKitchenTicketInput, CafeFlowUpdateOrderStatusInput } from "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle";
    const message_en: {
        'takeoutOrderLifecycle.section.main.title': string;
        'takeoutOrderLifecycle.organism.createOrder.title': string;
        'takeoutOrderLifecycle.organism.addOrderItem.title': string;
        'takeoutOrderLifecycle.organism.createKitchenTicket.title': string;
        'takeoutOrderLifecycle.organism.updateOrderStatus.title': string;
        'takeoutOrderLifecycle.organism.review.title': string;
        'takeoutOrderLifecycle.intention.createOrder.title': string;
        'takeoutOrderLifecycle.intention.addOrderItem.title': string;
        'takeoutOrderLifecycle.intention.createKitchenTicket.title': string;
        'takeoutOrderLifecycle.intention.updateOrderStatus.title': string;
        'takeoutOrderLifecycle.intention.review.title': string;
        'takeoutOrderLifecycle.field.createOrder.orderType': string;
        'takeoutOrderLifecycle.field.createOrder.status': string;
        'takeoutOrderLifecycle.field.createOrder.totalAmount': string;
        'takeoutOrderLifecycle.field.createOrder.notes': string;
        'takeoutOrderLifecycle.field.createOrder.customerName': string;
        'takeoutOrderLifecycle.field.createOrder.customerPhone': string;
        'takeoutOrderLifecycle.field.createOrder.numberOfGuests': string;
        'takeoutOrderLifecycle.field.createOrder.closedAt': string;
        'takeoutOrderLifecycle.field.createOrder.cancelledAt': string;
        'takeoutOrderLifecycle.field.createOrder.cancellationReason': string;
        'takeoutOrderLifecycle.action.createOrder.submit': string;
        'takeoutOrderLifecycle.field.addOrderItem.quantity': string;
        'takeoutOrderLifecycle.field.addOrderItem.unitPrice': string;
        'takeoutOrderLifecycle.field.addOrderItem.totalPrice': string;
        'takeoutOrderLifecycle.field.addOrderItem.observations': string;
        'takeoutOrderLifecycle.field.addOrderItem.status': string;
        'takeoutOrderLifecycle.action.addOrderItem.submit': string;
        'takeoutOrderLifecycle.field.createKitchenTicket.status': string;
        'takeoutOrderLifecycle.action.createKitchenTicket.submit': string;
        'takeoutOrderLifecycle.field.updateOrderStatus.status': string;
        'takeoutOrderLifecycle.field.updateOrderStatus.closedAt': string;
        'takeoutOrderLifecycle.field.updateOrderStatus.cancelledAt': string;
        'takeoutOrderLifecycle.field.updateOrderStatus.cancellationReason': string;
        'takeoutOrderLifecycle.action.updateOrderStatus.submit': string;
    };
    type MessageType = typeof message_en;
    export class CafeFlowTakeoutOrderLifecycleBase extends CollabLitElement {
        status: string;
        createOrderState: 'idle' | 'loading' | 'success' | 'error';
        createOrderOrderType: CafeFlowCreateOrderInput['orderType'];
        createOrderStatus: CafeFlowCreateOrderInput['status'];
        createOrderTotalAmount: number;
        createOrderNotes: string;
        createOrderCustomerName: string;
        createOrderCustomerPhone: string;
        createOrderNumberOfGuests: number;
        createOrderClosedAt: string;
        createOrderCancelledAt: string;
        createOrderCancellationReason: string;
        addOrderItemState: 'idle' | 'loading' | 'success' | 'error';
        addOrderItemQuantity: number;
        addOrderItemUnitPrice: number;
        addOrderItemTotalPrice: number;
        addOrderItemObservations: string;
        addOrderItemStatus: CafeFlowAddOrderItemInput['status'];
        createKitchenTicketState: 'idle' | 'loading' | 'success' | 'error';
        createKitchenTicketStatus: CafeFlowCreateKitchenTicketInput['status'];
        updateOrderStatusState: 'idle' | 'loading' | 'success' | 'error';
        updateOrderStatusStatus: CafeFlowUpdateOrderStatusInput['status'];
        updateOrderStatusClosedAt: string;
        updateOrderStatusCancelledAt: string;
        updateOrderStatusCancellationReason: string;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        setCreateOrderOrderType(value: CafeFlowCreateOrderInput['orderType']): void;
        handleCreateOrderOrderTypeChange(event: Event): void;
        setCreateOrderStatus(value: CafeFlowCreateOrderInput['status']): void;
        handleCreateOrderStatusChange(event: Event): void;
        setCreateOrderTotalAmount(value: number): void;
        handleCreateOrderTotalAmountChange(event: Event): void;
        setCreateOrderNotes(value: string): void;
        handleCreateOrderNotesChange(event: Event): void;
        setCreateOrderCustomerName(value: string): void;
        handleCreateOrderCustomerNameChange(event: Event): void;
        setCreateOrderCustomerPhone(value: string): void;
        handleCreateOrderCustomerPhoneChange(event: Event): void;
        setCreateOrderNumberOfGuests(value: number): void;
        handleCreateOrderNumberOfGuestsChange(event: Event): void;
        setCreateOrderClosedAt(value: string): void;
        handleCreateOrderClosedAtChange(event: Event): void;
        setCreateOrderCancelledAt(value: string): void;
        handleCreateOrderCancelledAtChange(event: Event): void;
        setCreateOrderCancellationReason(value: string): void;
        handleCreateOrderCancellationReasonChange(event: Event): void;
        setAddOrderItemQuantity(value: number): void;
        handleAddOrderItemQuantityChange(event: Event): void;
        setAddOrderItemUnitPrice(value: number): void;
        handleAddOrderItemUnitPriceChange(event: Event): void;
        setAddOrderItemTotalPrice(value: number): void;
        handleAddOrderItemTotalPriceChange(event: Event): void;
        setAddOrderItemObservations(value: string): void;
        handleAddOrderItemObservationsChange(event: Event): void;
        setAddOrderItemStatus(value: CafeFlowAddOrderItemInput['status']): void;
        handleAddOrderItemStatusChange(event: Event): void;
        setCreateKitchenTicketStatus(value: CafeFlowCreateKitchenTicketInput['status']): void;
        handleCreateKitchenTicketStatusChange(event: Event): void;
        setUpdateOrderStatusStatus(value: CafeFlowUpdateOrderStatusInput['status']): void;
        handleUpdateOrderStatusStatusChange(event: Event): void;
        setUpdateOrderStatusClosedAt(value: string): void;
        handleUpdateOrderStatusClosedAtChange(event: Event): void;
        setUpdateOrderStatusCancelledAt(value: string): void;
        handleUpdateOrderStatusCancelledAtChange(event: Event): void;
        setUpdateOrderStatusCancellationReason(value: string): void;
        handleUpdateOrderStatusCancellationReasonChange(event: Event): void;
        createOrder(): Promise<void>;
        handleCreateOrderClick(): Promise<void>;
        addOrderItem(): Promise<void>;
        handleAddOrderItemClick(): Promise<void>;
        createKitchenTicket(): Promise<void>;
        handleCreateKitchenTicketClick(): Promise<void>;
        updateOrderStatus(): Promise<void>;
        handleUpdateOrderStatusClick(): Promise<void>;
    }
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/takeoutOrderLifecycle" {
    import { CafeFlowTakeoutOrderLifecycleBase } from "_102050_/l2/cafeFlow/web/shared/takeoutOrderLifecycle";
    export class CafeFlowDesktopPage11TakeoutOrderLifecyclePage extends CafeFlowTakeoutOrderLifecycleBase {
        render(): any;
    }
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/viewOperationalDashboard.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        filters: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            inputType?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        })[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        stateKey: string;
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "viewOperationalDashboard__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/viewOperationalDashboard.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/viewOperationalDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/viewOperationalDashboard.defs.ts", "_102050_/l2/cafeFlow/web/shared/viewOperationalDashboard.ts", "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.defs.ts", "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.ts"];
        readonly dependsOn: readonly ["viewOperationalDashboard__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/viewOperationalDashboard" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { CafeFlowViewOperationalDashboardOutputItem } from "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard";
    export class CafeFlowViewOperationalDashboardBase extends CollabLitElement {
        status: string;
        viewOperationalDashboardState: 'idle' | 'loading' | 'success' | 'error';
        viewOperationalDashboardDailyShiftId: string;
        viewOperationalDashboardShiftDate: string;
        viewOperationalDashboardStatus: string;
        viewOperationalDashboardOpenedAt: string;
        viewOperationalDashboardClosedAt: string;
        viewOperationalDashboardCreatedAt: string;
        viewOperationalDashboardData: CafeFlowViewOperationalDashboardOutputItem[];
        protected get msg(): Record<string, string>;
        connectedCallback(): void;
        disconnectedCallback(): void;
        loadViewOperationalDashboard(): Promise<void>;
        handleViewOperationalDashboardClick(): void;
        setViewOperationalDashboardDailyShiftId(value: string): void;
        handleViewOperationalDashboardDailyShiftIdChange(e: Event): void;
        setViewOperationalDashboardShiftDate(value: string): void;
        handleViewOperationalDashboardShiftDateChange(e: Event): void;
        setViewOperationalDashboardStatus(value: string): void;
        handleViewOperationalDashboardStatusChange(e: Event): void;
        setViewOperationalDashboardOpenedAt(value: string): void;
        handleViewOperationalDashboardOpenedAtChange(e: Event): void;
        setViewOperationalDashboardClosedAt(value: string): void;
        handleViewOperationalDashboardClosedAtChange(e: Event): void;
        setViewOperationalDashboardCreatedAt(value: string): void;
        handleViewOperationalDashboardCreatedAtChange(e: Event): void;
    }
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/viewOperationalDashboard" {
    import { CafeFlowViewOperationalDashboardBase } from "_102050_/l2/cafeFlow/web/shared/viewOperationalDashboard";
    export class CafeFlowDesktopPage11ViewOperationalDashboardPage extends CafeFlowViewOperationalDashboardBase {
        render(): any;
    }
}
declare module "_102050_/l2/cafeFlow/web/shared/aiPromotionSuggestions.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        navigationRefs: any[];
        i18n: {
            "aiPromotionSuggestions.section.title": string;
            "aiPromotionSuggestions.organism.title": string;
            "aiPromotionSuggestions.intent.queryList.title": string;
            "aiPromotionSuggestions.field.id": string;
            "aiPromotionSuggestions.field.orderId": string;
            "aiPromotionSuggestions.field.menuItemId": string;
            "aiPromotionSuggestions.field.kitchenTicketId": string;
            "aiPromotionSuggestions.field.quantity": string;
            "aiPromotionSuggestions.field.unitPrice": string;
            "aiPromotionSuggestions.field.totalPrice": string;
            "aiPromotionSuggestions.field.observations": string;
            "aiPromotionSuggestions.filter.id": string;
            "aiPromotionSuggestions.filter.orderId": string;
            "aiPromotionSuggestions.filter.menuItemId": string;
            "aiPromotionSuggestions.filter.kitchenTicketId": string;
            "aiPromotionSuggestions.filter.status": string;
            "aiPromotionSuggestions.filter.createdAt": string;
            "aiPromotionSuggestions.action.run": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "aiPromotionSuggestions__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/aiPromotionSuggestions.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/aiPromotionSuggestions.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.defs.ts", "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.ts", "_102050_/l2/cafeFlow/web/desktop/page11/aiPromotionSuggestions.defs.ts"];
        readonly dependsOn: readonly ["aiPromotionSuggestions__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/aiPromotionSuggestions.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/shared/aiSalesSummary.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        navigationRefs: any[];
        i18n: {
            "aiSalesSummary.section.main.title": string;
            "aiSalesSummary.organism.main.title": string;
            "aiSalesSummary.intent.query.title": string;
            "aiSalesSummary.field.dailyShiftId.label": string;
            "aiSalesSummary.field.status.label": string;
            "aiSalesSummary.field.totalAmount.label": string;
            "aiSalesSummary.field.closedAt.label": string;
            "aiSalesSummary.filter.dailyShiftId.label": string;
            "aiSalesSummary.filter.status.label": string;
            "aiSalesSummary.filter.closedAt.label": string;
            "aiSalesSummary.action.run.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "aiSalesSummary__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/aiSalesSummary.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/aiSalesSummary.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.defs.ts", "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.ts", "_102050_/l2/cafeFlow/web/desktop/page11/aiSalesSummary.defs.ts"];
        readonly dependsOn: readonly ["aiSalesSummary__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/aiSalesSummary.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/shared/browseMenuForPos.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        navigationRefs: any[];
        i18n: {
            "browseMenuForPos.section.title": string;
            "browseMenuForPos.organism.title": string;
            "browseMenuForPos.intent.query.title": string;
            "browseMenuForPos.list.empty": string;
            "browseMenuForPos.field.menuItemId": string;
            "browseMenuForPos.field.menuCategoryId": string;
            "browseMenuForPos.field.name": string;
            "browseMenuForPos.field.description": string;
            "browseMenuForPos.field.price": string;
            "browseMenuForPos.field.status": string;
            "browseMenuForPos.field.createdAt": string;
            "browseMenuForPos.field.updatedAt": string;
            "browseMenuForPos.filter.menuItemId": string;
            "browseMenuForPos.filter.menuCategoryId": string;
            "browseMenuForPos.filter.name": string;
            "browseMenuForPos.filter.status": string;
            "browseMenuForPos.filter.createdAt": string;
            "browseMenuForPos.filter.updatedAt": string;
            "browseMenuForPos.action.browseMenuForPos": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "browseMenuForPos__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/browseMenuForPos.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/browseMenuForPos.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.defs.ts", "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.ts", "_102050_/l2/cafeFlow/web/desktop/page11/browseMenuForPos.defs.ts"];
        readonly dependsOn: readonly ["browseMenuForPos__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/browseMenuForPos.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/shared/closeDailyShift.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "closeDailyShift.section.main": string;
            "closeDailyShift.update.title": string;
            "closeDailyShift.record.title": string;
            "closeDailyShift.summary.title": string;
            "closeDailyShift.action.updateDailyShiftStatus": string;
            "closeDailyShift.action.recordClosingCashMovement": string;
            "field.dailyShiftId": string;
            "field.shiftDate": string;
            "field.status": string;
            "field.openedAt": string;
            "field.closedAt": string;
            "field.openingCashBalance": string;
            "field.closingCashBalance": string;
            "field.totalSales": string;
            "field.totalPayments": string;
            "field.closingNotes": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "closeDailyShift__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/closeDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/closeDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/closeDailyShift.defs.ts", "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.ts", "_102050_/l2/cafeFlow/web/desktop/page11/closeDailyShift.defs.ts"];
        readonly dependsOn: readonly ["closeDailyShift__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/closeDailyShift.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/shared/consumeIngredientsOnConfirmation.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "consumeIngredientsOnConfirmation.section.main.title": string;
            "consumeIngredientsOnConfirmation.organism.createStockConsumption.title": string;
            "consumeIngredientsOnConfirmation.intention.createStockConsumption.title": string;
            "consumeIngredientsOnConfirmation.field.quantity.label": string;
            "consumeIngredientsOnConfirmation.field.status.label": string;
            "consumeIngredientsOnConfirmation.field.consumedAt.label": string;
            "consumeIngredientsOnConfirmation.action.createStockConsumption.label": string;
            "consumeIngredientsOnConfirmation.intention.review.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "consumeIngredientsOnConfirmation__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/consumeIngredientsOnConfirmation.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/consumeIngredientsOnConfirmation.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.defs.ts", "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.ts", "_102050_/l2/cafeFlow/web/desktop/page11/consumeIngredientsOnConfirmation.defs.ts"];
        readonly dependsOn: readonly ["consumeIngredientsOnConfirmation__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/consumeIngredientsOnConfirmation.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/shared/dineInOrderLifecycle.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "dineInOrderLifecycle.section.main.title": string;
            "dineInOrderLifecycle.organism.createOrder.title": string;
            "dineInOrderLifecycle.stage.createOrder.title": string;
            "dineInOrderLifecycle.field.orderType.label": string;
            "dineInOrderLifecycle.field.status.label": string;
            "dineInOrderLifecycle.field.totalAmount.label": string;
            "dineInOrderLifecycle.field.notes.label": string;
            "dineInOrderLifecycle.field.customerName.label": string;
            "dineInOrderLifecycle.field.customerPhone.label": string;
            "dineInOrderLifecycle.field.numberOfGuests.label": string;
            "dineInOrderLifecycle.field.closedAt.label": string;
            "dineInOrderLifecycle.field.cancelledAt.label": string;
            "dineInOrderLifecycle.field.cancellationReason.label": string;
            "dineInOrderLifecycle.action.createOrder.label": string;
            "dineInOrderLifecycle.organism.addOrderItem.title": string;
            "dineInOrderLifecycle.stage.addOrderItem.title": string;
            "dineInOrderLifecycle.field.quantity.label": string;
            "dineInOrderLifecycle.field.unitPrice.label": string;
            "dineInOrderLifecycle.field.totalPrice.label": string;
            "dineInOrderLifecycle.field.observations.label": string;
            "dineInOrderLifecycle.field.itemStatus.label": string;
            "dineInOrderLifecycle.action.addOrderItem.label": string;
            "dineInOrderLifecycle.organism.createKitchenTicket.title": string;
            "dineInOrderLifecycle.stage.createKitchenTicket.title": string;
            "dineInOrderLifecycle.field.kitchenTicketStatus.label": string;
            "dineInOrderLifecycle.action.createKitchenTicket.label": string;
            "dineInOrderLifecycle.organism.updateOrderStatus.title": string;
            "dineInOrderLifecycle.stage.updateOrderStatus.title": string;
            "dineInOrderLifecycle.action.updateOrderStatus.label": string;
            "dineInOrderLifecycle.organism.updateTableStatus.title": string;
            "dineInOrderLifecycle.stage.updateTableStatus.title": string;
            "dineInOrderLifecycle.field.tableStatus.label": string;
            "dineInOrderLifecycle.field.currentChargesTotal.label": string;
            "dineInOrderLifecycle.field.openedAt.label": string;
            "dineInOrderLifecycle.action.updateTableStatus.label": string;
            "dineInOrderLifecycle.organism.review.title": string;
            "dineInOrderLifecycle.stage.review.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "dineInOrderLifecycle__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/dineInOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/dineInOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.defs.ts", "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.ts", "_102050_/l2/cafeFlow/web/desktop/page11/dineInOrderLifecycle.defs.ts"];
        readonly dependsOn: readonly ["dineInOrderLifecycle__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/dineInOrderLifecycle.test" {
    export {};
}
declare module "_102050_/l2/cafeFlow/web/shared/generateShiftCloseReport.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        navigationRefs: any[];
        i18n: {
            "generateShiftCloseReport.section.title": string;
            "generateShiftCloseReport.organism.title": string;
            "generateShiftCloseReport.filters.title": string;
            "generateShiftCloseReport.filters.status": string;
            "generateShiftCloseReport.filters.openedAt": string;
            "generateShiftCloseReport.filters.closedAt": string;
            "generateShiftCloseReport.actions.generate": string;
            "generateShiftCloseReport.summary.title": string;
            "generateShiftCloseReport.summary.status": string;
            "generateShiftCloseReport.summary.openedAt": string;
            "generateShiftCloseReport.summary.closedAt": string;
            "generateShiftCloseReport.summary.openingCashBalance": string;
            "generateShiftCloseReport.summary.closingCashBalance": string;
            "generateShiftCloseReport.summary.totalSales": string;
            "generateShiftCloseReport.summary.totalPayments": string;
            "generateShiftCloseReport.summary.closingNotes": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "generateShiftCloseReport__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/generateShiftCloseReport.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/generateShiftCloseReport.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.defs.ts", "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.ts", "_102050_/l2/cafeFlow/web/desktop/page11/generateShiftCloseReport.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/kitchenProductionFlow.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        navigationRefs: any[];
        i18n: {
            "kitchenProductionFlow.section.main.title": string;
            "kitchenProductionFlow.organism.viewKitchenTickets.title": string;
            "kitchenProductionFlow.intention.viewKitchenTickets.queryList.title": string;
            "kitchenProductionFlow.kitchenTicket.field.kitchenTicketId": string;
            "kitchenProductionFlow.kitchenTicket.field.orderId": string;
            "kitchenProductionFlow.kitchenTicket.field.status": string;
            "kitchenProductionFlow.kitchenTicket.field.createdAt": string;
            "kitchenProductionFlow.kitchenTicket.field.updatedAt": string;
            "kitchenProductionFlow.kitchenTicket.filter.kitchenTicketId": string;
            "kitchenProductionFlow.kitchenTicket.filter.orderId": string;
            "kitchenProductionFlow.kitchenTicket.filter.status": string;
            "kitchenProductionFlow.kitchenTicket.filter.createdAt": string;
            "kitchenProductionFlow.kitchenTicket.filter.updatedAt": string;
            "kitchenProductionFlow.action.viewKitchenTickets": string;
            "kitchenProductionFlow.organism.updateKitchenTicketStatus.title": string;
            "kitchenProductionFlow.intention.updateKitchenTicketStatus.commandForm.title": string;
            "kitchenProductionFlow.action.updateKitchenTicketStatus": string;
            "kitchenProductionFlow.organism.updateOrderItemStatus.title": string;
            "kitchenProductionFlow.intention.updateOrderItemStatus.commandForm.title": string;
            "kitchenProductionFlow.orderItem.field.status": string;
            "kitchenProductionFlow.action.updateOrderItemStatus": string;
            "kitchenProductionFlow.organism.summary.title": string;
            "kitchenProductionFlow.intention.summary.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "kitchenProductionFlow__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/kitchenProductionFlow.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/kitchenProductionFlow.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.defs.ts", "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.ts", "_102050_/l2/cafeFlow/web/desktop/page11/kitchenProductionFlow.defs.ts"];
        readonly dependsOn: readonly ["kitchenProductionFlow__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/manageInventoryItems.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "manageInventoryItems.section.main.title": string;
            "manageInventoryItems.organism.form.title": string;
            "manageInventoryItems.intention.status.title": string;
            "manageInventoryItems.intention.form.title": string;
            "manageInventoryItems.field.name.label": string;
            "manageInventoryItems.field.description.label": string;
            "manageInventoryItems.field.unit.label": string;
            "manageInventoryItems.field.currentQuantity.label": string;
            "manageInventoryItems.field.minimumLevel.label": string;
            "manageInventoryItems.field.status.label": string;
            "manageInventoryItems.action.submit.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "manageInventoryItems__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/manageInventoryItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/manageInventoryItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.defs.ts", "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.ts", "_102050_/l2/cafeFlow/web/desktop/page11/manageInventoryItems.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/manageMenuCategories.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "manageMenuCategories.section.main.title": string;
            "manageMenuCategories.organism.form.title": string;
            "manageMenuCategories.intention.commandForm.title": string;
            "manageMenuCategories.field.menuCategoryId.label": string;
            "manageMenuCategories.field.name.label": string;
            "manageMenuCategories.field.description.label": string;
            "manageMenuCategories.field.status.label": string;
            "manageMenuCategories.action.submit.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "manageMenuCategories__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/manageMenuCategories.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/manageMenuCategories.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.defs.ts", "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.ts", "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuCategories.defs.ts"];
        readonly dependsOn: readonly ["manageMenuCategories__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/manageMenuItems.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "manageMenuItems.section.title": string;
            "manageMenuItems.organism.title": string;
            "manageMenuItems.form.title": string;
            "manageMenuItems.field.menuItemId": string;
            "manageMenuItems.field.menuCategoryId": string;
            "manageMenuItems.field.name": string;
            "manageMenuItems.field.description": string;
            "manageMenuItems.field.price": string;
            "manageMenuItems.field.status": string;
            "manageMenuItems.action.submit": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "manageMenuItems__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/manageMenuItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/manageMenuItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/manageMenuItems.defs.ts", "_102050_/l2/cafeFlow/web/contracts/manageMenuItems.ts", "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuItems.defs.ts"];
        readonly dependsOn: readonly ["manageMenuItems__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/manageTables.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "manageTables.section.main.title": string;
            "manageTables.organism.form.title": string;
            "manageTables.intention.commandForm.title": string;
            "manageTables.field.tableId": string;
            "manageTables.field.number": string;
            "manageTables.field.status": string;
            "manageTables.action.submit": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "manageTables__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/manageTables.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/manageTables.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/manageTables.defs.ts", "_102050_/l2/cafeFlow/web/contracts/manageTables.ts", "_102050_/l2/cafeFlow/web/desktop/page11/manageTables.defs.ts"];
        readonly dependsOn: readonly ["manageTables__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/openDailyShift.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "openDailyShift.section.main.title": string;
            "openDailyShift.organism.createDailyShift.title": string;
            "openDailyShift.intention.createDailyShift.form.title": string;
            "openDailyShift.field.createDailyShift.shiftDate.label": string;
            "openDailyShift.field.createDailyShift.status.label": string;
            "openDailyShift.field.createDailyShift.openedAt.label": string;
            "openDailyShift.field.createDailyShift.openingCashBalance.label": string;
            "openDailyShift.action.createDailyShift.submit.label": string;
            "openDailyShift.organism.recordOpeningCashMovement.title": string;
            "openDailyShift.intention.recordOpeningCashMovement.form.title": string;
            "openDailyShift.field.recordOpeningCashMovement.movementType.label": string;
            "openDailyShift.field.recordOpeningCashMovement.amount.label": string;
            "openDailyShift.field.recordOpeningCashMovement.reason.label": string;
            "openDailyShift.action.recordOpeningCashMovement.submit.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "openDailyShift__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/openDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/openDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/openDailyShift.defs.ts", "_102050_/l2/cafeFlow/web/contracts/openDailyShift.ts", "_102050_/l2/cafeFlow/web/desktop/page11/openDailyShift.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/recordPayment.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "recordPayment.section.title": string;
            "recordPayment.organism.title": string;
            "recordPayment.form.title": string;
            "recordPayment.field.method": string;
            "recordPayment.field.amount": string;
            "recordPayment.field.status": string;
            "recordPayment.action.submit": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "recordPayment__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/recordPayment.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/recordPayment.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/recordPayment.defs.ts", "_102050_/l2/cafeFlow/web/contracts/recordPayment.ts", "_102050_/l2/cafeFlow/web/desktop/page11/recordPayment.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/takeoutOrderLifecycle.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "takeoutOrderLifecycle.section.main.title": string;
            "takeoutOrderLifecycle.organism.createOrder.title": string;
            "takeoutOrderLifecycle.organism.addOrderItem.title": string;
            "takeoutOrderLifecycle.organism.createKitchenTicket.title": string;
            "takeoutOrderLifecycle.organism.updateOrderStatus.title": string;
            "takeoutOrderLifecycle.organism.reviewSummary.title": string;
            "takeoutOrderLifecycle.intent.createOrderForm.title": string;
            "takeoutOrderLifecycle.intent.addOrderItemForm.title": string;
            "takeoutOrderLifecycle.intent.createKitchenTicketForm.title": string;
            "takeoutOrderLifecycle.intent.updateOrderStatusForm.title": string;
            "takeoutOrderLifecycle.intent.reviewSummary.title": string;
            "takeoutOrderLifecycle.field.orderType.label": string;
            "takeoutOrderLifecycle.field.status.label": string;
            "takeoutOrderLifecycle.field.totalAmount.label": string;
            "takeoutOrderLifecycle.field.notes.label": string;
            "takeoutOrderLifecycle.field.customerName.label": string;
            "takeoutOrderLifecycle.field.customerPhone.label": string;
            "takeoutOrderLifecycle.field.numberOfGuests.label": string;
            "takeoutOrderLifecycle.field.closedAt.label": string;
            "takeoutOrderLifecycle.field.cancelledAt.label": string;
            "takeoutOrderLifecycle.field.cancellationReason.label": string;
            "takeoutOrderLifecycle.field.quantity.label": string;
            "takeoutOrderLifecycle.field.unitPrice.label": string;
            "takeoutOrderLifecycle.field.totalPrice.label": string;
            "takeoutOrderLifecycle.field.observations.label": string;
            "takeoutOrderLifecycle.field.itemStatus.label": string;
            "takeoutOrderLifecycle.field.kitchenTicketStatus.label": string;
            "takeoutOrderLifecycle.field.orderId.label": string;
            "takeoutOrderLifecycle.action.createOrder.label": string;
            "takeoutOrderLifecycle.action.addOrderItem.label": string;
            "takeoutOrderLifecycle.action.createKitchenTicket.label": string;
            "takeoutOrderLifecycle.action.updateOrderStatus.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "takeoutOrderLifecycle__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/takeoutOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/takeoutOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.defs.ts", "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.ts", "_102050_/l2/cafeFlow/web/desktop/page11/takeoutOrderLifecycle.defs.ts"];
        readonly dependsOn: readonly ["takeoutOrderLifecycle__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/viewOperationalDashboard.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        navigationRefs: any[];
        i18n: {
            "viewOperationalDashboard.section.title": string;
            "viewOperationalDashboard.organism.title": string;
            "viewOperationalDashboard.filters.title": string;
            "viewOperationalDashboard.field.dailyShiftId": string;
            "viewOperationalDashboard.field.shiftDate": string;
            "viewOperationalDashboard.field.status": string;
            "viewOperationalDashboard.field.openedAt": string;
            "viewOperationalDashboard.field.closedAt": string;
            "viewOperationalDashboard.field.createdAt": string;
            "viewOperationalDashboard.action.run": string;
            "viewOperationalDashboard.summary.title": string;
            "viewOperationalDashboard.summary.dailyShiftId": string;
            "viewOperationalDashboard.summary.shiftDate": string;
            "viewOperationalDashboard.summary.status": string;
            "viewOperationalDashboard.summary.openedAt": string;
            "viewOperationalDashboard.summary.closedAt": string;
            "viewOperationalDashboard.summary.openingCashBalance": string;
            "viewOperationalDashboard.summary.closingCashBalance": string;
            "viewOperationalDashboard.summary.totalSales": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "viewOperationalDashboard__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/viewOperationalDashboard.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/viewOperationalDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.defs.ts", "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.ts", "_102050_/l2/cafeFlow/web/desktop/page11/viewOperationalDashboard.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
