declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/aiPromotionSuggestions.defs" {
    export const aiPromotionSuggestionsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "aiPromotionSuggestions";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "aiPromotionSuggestions";
            readonly controllerName: "AiPromotionSuggestionsController";
            readonly handlers: readonly [];
            readonly routes: readonly [];
        };
    };
    export default aiPromotionSuggestionsController;
    export const pipeline: readonly [{
        readonly id: "aiPromotionSuggestions__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/aiPromotionSuggestions.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/aiPromotionSuggestions.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/aiSalesSummary.defs" {
    export const aiSalesSummaryController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "aiSalesSummary";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "aiSalesSummary";
            readonly controllerName: "AiSalesSummaryController";
            readonly handlers: readonly [];
            readonly routes: readonly [];
        };
    };
    export default aiSalesSummaryController;
    export const pipeline: readonly [{
        readonly id: "aiSalesSummary__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/aiSalesSummary.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/aiSalesSummary.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseMenuForPos.defs" {
    export const browseMenuForPosController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "browseMenuForPos";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "browseMenuForPos";
            readonly controllerName: "BrowseMenuForPosController";
            readonly handlers: readonly [];
            readonly routes: readonly [];
        };
    };
    export default browseMenuForPosController;
    export const pipeline: readonly [{
        readonly id: "browseMenuForPos__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseMenuForPos.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseMenuForPos.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/closeDailyShift.defs" {
    export const closeDailyShiftController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "closeDailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "closeDailyShift";
            readonly controllerName: "CloseDailyShiftController";
            readonly handlers: readonly [];
            readonly routes: readonly [];
        };
    };
    export default closeDailyShiftController;
    export const pipeline: readonly [{
        readonly id: "closeDailyShift__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/closeDailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/closeDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/closeDailyShift.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/consumeIngredientsOnConfirmation.defs" {
    export const consumeIngredientsOnConfirmationController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "consumeIngredientsOnConfirmation";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "consumeIngredientsOnConfirmation";
            readonly controllerName: "ConsumeIngredientsOnConfirmationController";
            readonly handlers: readonly [];
            readonly routes: readonly [];
        };
    };
    export default consumeIngredientsOnConfirmationController;
    export const pipeline: readonly [{
        readonly id: "consumeIngredientsOnConfirmation__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/consumeIngredientsOnConfirmation.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/consumeIngredientsOnConfirmation.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/dineInOrderLifecycle.defs" {
    export const dineInOrderLifecycleController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "dineInOrderLifecycle";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "dineInOrderLifecycle";
            readonly controllerName: "DineInOrderLifecycleController";
            readonly handlers: readonly [];
            readonly routes: readonly [];
        };
    };
    export default dineInOrderLifecycleController;
    export const pipeline: readonly [{
        readonly id: "dineInOrderLifecycle__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/dineInOrderLifecycle.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/dineInOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/generateShiftCloseReport.defs" {
    export const generateShiftCloseReportController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "generateShiftCloseReport";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "generateShiftCloseReport";
            readonly controllerName: "GenerateShiftCloseReportController";
            readonly handlers: readonly [];
            readonly routes: readonly [];
        };
    };
    export default generateShiftCloseReportController;
    export const pipeline: readonly [{
        readonly id: "generateShiftCloseReport__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/generateShiftCloseReport.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/generateShiftCloseReport.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/kitchenProductionFlow.defs" {
    export const kitchenProductionFlowController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "kitchenProductionFlow";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "kitchenProductionFlow";
            readonly controllerName: "KitchenProductionFlowController";
            readonly handlers: readonly [];
            readonly routes: readonly [];
        };
    };
    export default kitchenProductionFlowController;
    export const pipeline: readonly [{
        readonly id: "kitchenProductionFlow__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/kitchenProductionFlow.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/kitchenProductionFlow.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageInventoryItems.defs" {
    export const manageInventoryItemsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "manageInventoryItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "manageInventoryItems";
            readonly controllerName: "ManageInventoryItemsController";
            readonly handlers: readonly [];
            readonly routes: readonly [];
        };
    };
    export default manageInventoryItemsController;
    export const pipeline: readonly [{
        readonly id: "manageInventoryItems__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageInventoryItems.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageInventoryItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuCategories.defs" {
    export const manageMenuCategoriesController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "manageMenuCategories";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "manageMenuCategories";
            readonly controllerName: "ManageMenuCategoriesController";
            readonly handlers: readonly [];
            readonly routes: readonly [];
        };
    };
    export default manageMenuCategoriesController;
    export const pipeline: readonly [{
        readonly id: "manageMenuCategories__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuCategories.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuCategories.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuItems.defs" {
    export const manageMenuItemsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "manageMenuItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "manageMenuItems";
            readonly controllerName: "ManageMenuItemsController";
            readonly handlers: readonly [];
            readonly routes: readonly [];
        };
    };
    export default manageMenuItemsController;
    export const pipeline: readonly [{
        readonly id: "manageMenuItems__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuItems.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/manageMenuItems.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageTables.defs" {
    export const manageTablesController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "manageTables";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "manageTables";
            readonly controllerName: "ManageTablesController";
            readonly handlers: readonly [];
            readonly routes: readonly [];
        };
    };
    export default manageTablesController;
    export const pipeline: readonly [{
        readonly id: "manageTables__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageTables.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageTables.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/manageTables.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/openDailyShift.defs" {
    export const openDailyShiftController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "openDailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "openDailyShift";
            readonly controllerName: "OpenDailyShiftController";
            readonly handlers: readonly [];
            readonly routes: readonly [];
        };
    };
    export default openDailyShiftController;
    export const pipeline: readonly [{
        readonly id: "openDailyShift__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/openDailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/openDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/openDailyShift.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/recordPayment.defs" {
    export const recordPaymentController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "recordPayment";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "recordPayment";
            readonly controllerName: "RecordPaymentController";
            readonly handlers: readonly [];
            readonly routes: readonly [];
        };
    };
    export default recordPaymentController;
    export const pipeline: readonly [{
        readonly id: "recordPayment__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/recordPayment.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/recordPayment.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/recordPayment.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/takeoutOrderLifecycle.defs" {
    export const takeoutOrderLifecycleController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "takeoutOrderLifecycle";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "takeoutOrderLifecycle";
            readonly controllerName: "TakeoutOrderLifecycleController";
            readonly handlers: readonly [];
            readonly routes: readonly [];
        };
    };
    export default takeoutOrderLifecycleController;
    export const pipeline: readonly [{
        readonly id: "takeoutOrderLifecycle__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/takeoutOrderLifecycle.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/takeoutOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewOperationalDashboard.defs" {
    export const viewOperationalDashboardController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "viewOperationalDashboard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "viewOperationalDashboard";
            readonly controllerName: "ViewOperationalDashboardController";
            readonly handlers: readonly [];
            readonly routes: readonly [];
        };
    };
    export default viewOperationalDashboardController;
    export const pipeline: readonly [{
        readonly id: "viewOperationalDashboard__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewOperationalDashboard.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewOperationalDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShift.defs" {
    export const dailyShiftTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "DailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "DailyShift";
            readonly tableName: "daily_shift";
            readonly columns: readonly [{
                readonly name: "daily_shift_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "PK/FK identifier for daily shift";
            }, {
                readonly name: "status";
                readonly type: "varchar";
                readonly nullable: false;
                readonly description: "Status of the daily shift";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "Creation timestamp for ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "Contains shiftDate, openedAt, closedAt, openingCashBalance, closingCashBalance, totalSales, totalPayments, closingNotes, updatedAt and child collection CashMovement";
            }];
            readonly primaryKey: readonly ["daily_shift_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_daily_shift_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_daily_shift_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly ["CashMovement"];
            };
        };
    };
    export default dailyShiftTableDefinition;
    export const pipeline: readonly [{
        readonly id: "dailyShift__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShiftRepositoryAdapter.defs" {
    export const dailyShiftRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "DailyShiftRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "DailyShiftRepository";
            readonly entityId: "DailyShift";
            readonly portRef: "IDailyShiftRepository";
            readonly tableRef: "daily_shifts";
            readonly notes: readonly ["Real columns: daily_shift_id, status, created_at", "Details JSONB: shift_date, opened_at, closed_at, opening_cash_balance, closing_cash_balance, total_sales, total_payments, closing_notes, updated_at, cash_movements (embedded CashMovement[])", "ctx.data used for row<->domain mapping"];
        };
    };
    export default dailyShiftRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "dailyShiftRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShiftRepositoryAdapter.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShiftRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShift.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItem.defs" {
    export const inventoryItemTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "InventoryItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "InventoryItem";
            readonly tableName: "inventory_item";
            readonly columns: readonly [{
                readonly name: "inventory_item_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "PK/FK identifier for inventory item";
            }, {
                readonly name: "status";
                readonly type: "varchar";
                readonly nullable: false;
                readonly description: "Status of the inventory item";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "Creation timestamp for ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "Contains name, description, unit, currentQuantity, minimumLevel, updatedAt";
            }];
            readonly primaryKey: readonly ["inventory_item_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_inventory_item_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_inventory_item_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
        };
    };
    export default inventoryItemTableDefinition;
    export const pipeline: readonly [{
        readonly id: "inventoryItem__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItem.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItem.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItemRepositoryAdapter.defs" {
    export const inventoryItemRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "InventoryItemRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "InventoryItemRepository";
            readonly entityId: "InventoryItem";
            readonly portRef: "IInventoryItemRepository";
            readonly tableRef: "inventory_items";
            readonly notes: readonly ["Real columns: inventory_item_id, status, created_at", "Details JSONB: name, description, unit, current_quantity, minimum_level, updated_at", "ctx.data used for row<->domain mapping"];
        };
    };
    export default inventoryItemRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "inventoryItemRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItemRepositoryAdapter.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItemRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/inventoryItem.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItem.defs" {
    export const menuItemTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "MenuItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "MenuItem";
            readonly tableName: "menu_item";
            readonly columns: readonly [{
                readonly name: "menu_item_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "PK/FK identifier for menu item";
            }, {
                readonly name: "menu_category_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "FK to menu category";
            }, {
                readonly name: "status";
                readonly type: "varchar";
                readonly nullable: false;
                readonly description: "Status of the menu item";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "Creation timestamp for ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "Contains name, description, price, updatedAt and child collection RecipeComponent";
            }];
            readonly primaryKey: readonly ["menu_item_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_menu_item_menu_category_id";
                readonly columns: readonly ["menu_category_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_menu_item_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_menu_item_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly ["RecipeComponent"];
            };
        };
    };
    export default menuItemTableDefinition;
    export const pipeline: readonly [{
        readonly id: "menuItem__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItem.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItem.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemRepositoryAdapter.defs" {
    export const menuItemRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "MenuItemRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "MenuItemRepository";
            readonly entityId: "MenuItem";
            readonly portRef: "IMenuItemRepository";
            readonly tableRef: "menu_items";
            readonly mdmReads: readonly ["MenuCategory"];
            readonly notes: readonly ["Real columns: menu_item_id, menu_category_id, status, created_at", "Details JSONB: name, description, price, updated_at, recipe_components (embedded RecipeComponent[])", "Resolves MenuCategory via MDM 102034 using menu_category_id; ctx.data used for MDM fetch and domain mapping"];
        };
    };
    export default menuItemRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "menuItemRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemRepositoryAdapter.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItem.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/order.defs" {
    export const orderTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Order";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Order";
            readonly tableName: "order";
            readonly columns: readonly [{
                readonly name: "order_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "PK/FK identifier for order";
            }, {
                readonly name: "daily_shift_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "FK to daily shift";
            }, {
                readonly name: "table_id";
                readonly type: "uuid";
                readonly nullable: true;
                readonly description: "FK to table";
            }, {
                readonly name: "kitchen_ticket_id";
                readonly type: "uuid";
                readonly nullable: true;
                readonly description: "FK to kitchen ticket";
            }, {
                readonly name: "order_type";
                readonly type: "varchar";
                readonly nullable: false;
                readonly description: "Order type (dine-in, takeaway, delivery, etc.)";
            }, {
                readonly name: "status";
                readonly type: "varchar";
                readonly nullable: false;
                readonly description: "Status of the order";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "Creation timestamp for ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "Contains totalAmount, notes, customerName, customerPhone, numberOfGuests, closedAt, cancelledAt, cancellationReason, updatedAt and child collections OrderItem, KitchenTicket";
            }];
            readonly primaryKey: readonly ["order_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_order_daily_shift_id";
                readonly columns: readonly ["daily_shift_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_table_id";
                readonly columns: readonly ["table_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_kitchen_ticket_id";
                readonly columns: readonly ["kitchen_ticket_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_order_type";
                readonly columns: readonly ["order_type"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly ["OrderItem", "KitchenTicket"];
            };
        };
    };
    export default orderTableDefinition;
    export const pipeline: readonly [{
        readonly id: "order__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/order.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/order.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter.defs" {
    export const orderRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "OrderRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "OrderRepository";
            readonly entityId: "Order";
            readonly portRef: "IOrderRepository";
            readonly tableRef: "orders";
            readonly mdmReads: readonly ["Table"];
            readonly notes: readonly ["Real columns: order_id, daily_shift_id, table_id, kitchen_ticket_id, order_type, status, created_at", "Details JSONB: total_amount, notes, customer_name, customer_phone, number_of_guests, closed_at, cancelled_at, cancellation_reason, updated_at, order_items (embedded OrderItem[]), kitchen_tickets (embedded KitchenTicket[])", "Resolves Table via MDM 102034 using table_id; ctx.data used for MDM fetch and domain mapping"];
        };
    };
    export default orderRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "orderRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/payment.defs" {
    export const paymentTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Payment";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Payment";
            readonly tableName: "payment";
            readonly columns: readonly [{
                readonly name: "payment_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "PK/FK identifier for payment";
            }, {
                readonly name: "order_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "FK to order";
            }, {
                readonly name: "daily_shift_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "FK to daily shift";
            }, {
                readonly name: "status";
                readonly type: "varchar";
                readonly nullable: false;
                readonly description: "Status of the payment";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "Creation timestamp for ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "Contains method, amount, updatedAt";
            }];
            readonly primaryKey: readonly ["payment_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_payment_order_id";
                readonly columns: readonly ["order_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_payment_daily_shift_id";
                readonly columns: readonly ["daily_shift_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_payment_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_payment_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
        };
    };
    export default paymentTableDefinition;
    export const pipeline: readonly [{
        readonly id: "payment__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/payment.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/payment.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/paymentRepositoryAdapter.defs" {
    export const paymentRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "PaymentRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "PaymentRepository";
            readonly entityId: "Payment";
            readonly portRef: "IPaymentRepository";
            readonly tableRef: "payments";
            readonly notes: readonly ["Real columns: payment_id, order_id, daily_shift_id, status, created_at", "Details JSONB: method, amount, updated_at", "ctx.data used for row<->domain mapping"];
        };
    };
    export default paymentRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "paymentRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/paymentRepositoryAdapter.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/paymentRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.d.ts", "_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/payment.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.defs" {
    export const dailyShiftRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "DailyShiftRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "DailyShift";
            readonly interfaceName: "IDailyShiftRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "DailyShift | null";
                readonly params: readonly ["shiftId: ShiftId"];
            }, {
                readonly name: "list";
                readonly returns: "DailyShift[]";
                readonly params: readonly ["filter: DailyShiftFilter"];
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["dailyShift: DailyShift"];
            }, {
                readonly name: "findByDate";
                readonly returns: "DailyShift[]";
                readonly params: readonly ["date: LocalDate"];
            }, {
                readonly name: "findOpenShift";
                readonly returns: "DailyShift | null";
                readonly params: readonly [];
            }];
        };
    };
    export default dailyShiftRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "dailyShiftRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.defs" {
    export const inventoryItemRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "InventoryItemRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "InventoryItem";
            readonly interfaceName: "IInventoryItemRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "InventoryItem | null";
                readonly params: readonly ["inventoryItemId: InventoryItemId"];
            }, {
                readonly name: "list";
                readonly returns: "InventoryItem[]";
                readonly params: readonly ["filter: InventoryItemFilter"];
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["inventoryItem: InventoryItem"];
            }, {
                readonly name: "findBySku";
                readonly returns: "InventoryItem | null";
                readonly params: readonly ["sku: Sku"];
            }, {
                readonly name: "findBelowReorderLevel";
                readonly returns: "InventoryItem[]";
                readonly params: readonly [];
            }];
        };
    };
    export default inventoryItemRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "inventoryItemRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.defs" {
    export const menuItemRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "MenuItemRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "MenuItem";
            readonly interfaceName: "IMenuItemRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "MenuItem | null";
                readonly params: readonly ["menuItemId: MenuItemId"];
            }, {
                readonly name: "list";
                readonly returns: "MenuItem[]";
                readonly params: readonly ["filter: MenuItemFilter"];
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["menuItem: MenuItem"];
            }, {
                readonly name: "findByCategory";
                readonly returns: "MenuItem[]";
                readonly params: readonly ["categoryId: CategoryId"];
            }, {
                readonly name: "findAvailable";
                readonly returns: "MenuItem[]";
                readonly params: readonly [];
            }];
        };
    };
    export default menuItemRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "menuItemRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.defs" {
    export const orderRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "OrderRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Order";
            readonly interfaceName: "IOrderRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "Order | null";
                readonly params: readonly ["orderId: OrderId"];
            }, {
                readonly name: "list";
                readonly returns: "Order[]";
                readonly params: readonly ["filter: OrderFilter"];
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["order: Order"];
            }, {
                readonly name: "findByTable";
                readonly returns: "Order[]";
                readonly params: readonly ["tableId: TableId"];
            }, {
                readonly name: "findByStatus";
                readonly returns: "Order[]";
                readonly params: readonly ["status: OrderStatus"];
            }, {
                readonly name: "findOpenByTable";
                readonly returns: "Order | null";
                readonly params: readonly ["tableId: TableId"];
            }];
        };
    };
    export default orderRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "orderRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.defs" {
    export const paymentRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "PaymentRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Payment";
            readonly interfaceName: "IPaymentRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "Payment | null";
                readonly params: readonly ["paymentId: PaymentId"];
            }, {
                readonly name: "list";
                readonly returns: "Payment[]";
                readonly params: readonly ["filter: PaymentFilter"];
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["payment: Payment"];
            }, {
                readonly name: "findByOrder";
                readonly returns: "Payment[]";
                readonly params: readonly ["orderId: OrderId"];
            }, {
                readonly name: "findByDateRange";
                readonly returns: "Payment[]";
                readonly params: readonly ["start: LocalDateTime", "end: LocalDateTime"];
            }];
        };
    };
    export default paymentRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "paymentRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/addOrderItem.defs" {
    export const addOrderItemUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "addOrderItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "addOrderItem";
            readonly functionName: "addOrderItem";
            readonly inputTypeName: "AddOrderItemInput";
            readonly outputTypeName: "AddOrderItemOutput";
            readonly ports: readonly ["MenuItem", "Order"];
            readonly rulesApplied: readonly ["orderStatusTransitions", "ingredientConsumptionTrigger"];
            readonly transactional: true;
            readonly steps: readonly ["Validate order exists and is in a status that allows adding items (OPEN or similar) via Order port", "Validate referenced MenuItem exists and is available via MenuItem port", "Create OrderItem entity with quantity, notes, and unit price from MenuItem", "Add OrderItem to Order aggregate and recalculate Order.totalAmount", "Persist Order (with new OrderItem) via Order port within transaction", "If ingredientConsumptionTrigger applies, enqueue or create StockConsumption for the new item", "Return created OrderItem with id and computed totals"];
        };
    };
    export default addOrderItemUsecase;
    export const pipeline: readonly [{
        readonly id: "addOrderItem__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/addOrderItem.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/addOrderItem.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "ingredientConsumptionTrigger"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/aiPromotionSuggestions.defs" {
    export const aiPromotionSuggestionsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "aiPromotionSuggestions";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "aiPromotionSuggestions";
            readonly functionName: "aiPromotionSuggestions";
            readonly inputTypeName: "AiPromotionSuggestionsInput";
            readonly outputTypeName: "AiPromotionSuggestionsOutput";
            readonly ports: readonly ["Order", "MenuItem"];
            readonly rulesApplied: readonly [];
            readonly transactional: false;
            readonly steps: readonly ["Read recent OrderItem history via Order port to identify top-selling and slow-moving items", "Read MenuItem catalog via MenuItem port for pricing and category context", "Aggregate sales data by MenuItem and time window", "Generate promotion suggestions (bundles, discounts, featured items) based on sales patterns", "Return structured list of promotion suggestions with rationale"];
        };
    };
    export default aiPromotionSuggestionsUsecase;
    export const pipeline: readonly [{
        readonly id: "aiPromotionSuggestions__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/aiPromotionSuggestions.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/aiPromotionSuggestions.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/aiSalesSummary.defs" {
    export const aiSalesSummaryUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "aiSalesSummary";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "aiSalesSummary";
            readonly functionName: "aiSalesSummary";
            readonly inputTypeName: "AiSalesSummaryInput";
            readonly outputTypeName: "AiSalesSummaryOutput";
            readonly ports: readonly ["Order", "DailyShift", "MenuItem"];
            readonly rulesApplied: readonly ["aiOutputLanguageSelection"];
            readonly transactional: false;
            readonly steps: readonly ["Read DailyShift for the requested period via DailyShift port", "Read closed Orders within the shift date range via Order port", "Read OrderItem details and MenuItem info for breakdown via MenuItem port", "Apply aiOutputLanguageSelection rule to determine output language", "Compute total sales, order count, average ticket, top items, sales by category", "Generate natural-language summary in selected language", "Return structured summary with metrics and narrative text"];
        };
    };
    export default aiSalesSummaryUsecase;
    export const pipeline: readonly [{
        readonly id: "aiSalesSummary__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/aiSalesSummary.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/aiSalesSummary.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/browseMenuForPos.defs" {
    export const browseMenuForPosUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "browseMenuForPos";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "browseMenuForPos";
            readonly functionName: "browseMenuForPos";
            readonly inputTypeName: "BrowseMenuForPosInput";
            readonly outputTypeName: "BrowseMenuForPosOutput";
            readonly ports: readonly ["MenuItem"];
            readonly rulesApplied: readonly ["aiOutputLanguageSelection"];
            readonly transactional: false;
            readonly steps: readonly ["Read all active MenuItem entries grouped by MenuCategory via MenuItem port", "Apply aiOutputLanguageSelection rule to localize item names and descriptions", "Filter out unavailable or inactive items", "Return categorized menu tree with prices, images, and availability flags"];
        };
    };
    export default browseMenuForPosUsecase;
    export const pipeline: readonly [{
        readonly id: "browseMenuForPos__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/browseMenuForPos.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/browseMenuForPos.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/closeDailyShift.defs" {
    export const closeDailyShiftUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "closeDailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "closeDailyShift";
            readonly functionName: "closeDailyShift";
            readonly inputTypeName: "CloseDailyShiftInput";
            readonly outputTypeName: "CloseDailyShiftOutput";
            readonly ports: readonly ["DailyShift", "Order", "Payment"];
            readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
            readonly transactional: true;
            readonly steps: readonly ["Read DailyShift by id via DailyShift port and validate it is OPEN", "Read all Orders for the shift via Order port and validate all are CLOSED or CANCELLED", "Read all Payments and CashMovements for the shift via Payment port", "Apply paymentTimingByOrderType rule to reconcile payments by order type", "Compute closingCashBalance, totalSales, totalPayments, and variance", "Apply aiOutputLanguageSelection rule for closing notes language", "Update DailyShift: status=CLOSED, closedAt, closingCashBalance, closingNotes, totals", "Persist DailyShift within transaction", "Return closed DailyShift with reconciliation summary"];
        };
    };
    export default closeDailyShiftUsecase;
    export const pipeline: readonly [{
        readonly id: "closeDailyShift__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/closeDailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/closeDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/consumeIngredientsOnConfirmation.defs" {
    export const consumeIngredientsOnConfirmationUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "consumeIngredientsOnConfirmation";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "consumeIngredientsOnConfirmation";
            readonly functionName: "consumeIngredientsOnConfirmation";
            readonly inputTypeName: "ConsumeIngredientsOnConfirmationInput";
            readonly outputTypeName: "ConsumeIngredientsOnConfirmationOutput";
            readonly ports: readonly ["Order", "MenuItem", "InventoryItem"];
            readonly rulesApplied: readonly ["ingredientConsumptionTrigger"];
            readonly transactional: true;
            readonly steps: readonly ["Read Order and all OrderItems via Order port after status changed to CONFIRMED", "For each OrderItem, read MenuItem recipe components via MenuItem port", "Apply ingredientConsumptionTrigger rule to compute total ingredient quantities needed", "Read current InventoryItem stock levels via InventoryItem port", "Validate sufficient stock exists for all ingredients", "Create StockConsumption entries for each ingredient deduction", "Decrement InventoryItem.currentQuantity and update status per inventoryLowStockThreshold", "Persist all StockConsumption and InventoryItem updates within transaction", "Return consumption summary with per-ingredient deductions and updated stock levels"];
        };
    };
    export default consumeIngredientsOnConfirmationUsecase;
    export const pipeline: readonly [{
        readonly id: "consumeIngredientsOnConfirmation__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/consumeIngredientsOnConfirmation.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/consumeIngredientsOnConfirmation.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["ingredientConsumptionTrigger"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/createDailyShift.defs" {
    export const createDailyShiftUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createDailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createDailyShift";
            readonly functionName: "createDailyShift";
            readonly inputTypeName: "CreateDailyShiftInput";
            readonly outputTypeName: "CreateDailyShiftOutput";
            readonly ports: readonly ["DailyShift"];
            readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
            readonly transactional: true;
            readonly steps: readonly ["Check no open DailyShift exists for the same shiftDate via DailyShift port", "Create DailyShift entity with shiftDate, openingCashBalance, openedAt, status=OPEN", "Apply paymentTimingByOrderType rule to set expected payment flow configuration", "Apply aiOutputLanguageSelection rule for default shift language", "Persist DailyShift via DailyShift port within transaction", "Return created DailyShift with generated dailyShiftId"];
        };
    };
    export default createDailyShiftUsecase;
    export const pipeline: readonly [{
        readonly id: "createDailyShift__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createDailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/createKitchenTicket.defs" {
    export const createKitchenTicketUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createKitchenTicket";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createKitchenTicket";
            readonly functionName: "createKitchenTicket";
            readonly inputTypeName: "CreateKitchenTicketInput";
            readonly outputTypeName: "CreateKitchenTicketOutput";
            readonly ports: readonly ["Order"];
            readonly rulesApplied: readonly ["orderStatusTransitions"];
            readonly transactional: true;
            readonly steps: readonly ["Read Order and its OrderItems via Order port", "Validate Order status allows kitchen ticket creation per orderStatusTransitions rule", "Filter OrderItems that require kitchen preparation", "Create KitchenTicket entity with items, order reference, and initial status=PENDING", "Persist KitchenTicket within transaction", "Return created KitchenTicket with id and item list"];
        };
    };
    export default createKitchenTicketUsecase;
    export const pipeline: readonly [{
        readonly id: "createKitchenTicket__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createKitchenTicket.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createKitchenTicket.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/createOrder.defs" {
    export const createOrderUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createOrder";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createOrder";
            readonly functionName: "createOrder";
            readonly inputTypeName: "CreateOrderInput";
            readonly outputTypeName: "CreateOrderOutput";
            readonly ports: readonly ["Order", "DailyShift"];
            readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "aiOutputLanguageSelection", "tableOccupancyConsistency"];
            readonly transactional: true;
            readonly steps: readonly ["Validate an open DailyShift exists via DailyShift port", "Apply orderStatusTransitions rule to set initial Order status (OPEN)", "Apply paymentTimingByOrderType rule based on orderType (DINE_IN, TAKEOUT, DELIVERY)", "If DINE_IN, validate Table availability and apply tableOccupancyConsistency rule", "Apply aiOutputLanguageSelection rule for order language", "Create Order entity with orderType, tableId (if dine-in), dailyShiftId, totalAmount=0", "If ingredientConsumptionTrigger applies at creation, prepare StockConsumption entries", "Persist Order (and update Table status if dine-in) within transaction", "Return created Order with generated orderId"];
        };
    };
    export default createOrderUsecase;
    export const pipeline: readonly [{
        readonly id: "createOrder__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createOrder.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createOrder.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "aiOutputLanguageSelection", "tableOccupancyConsistency"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/createStockConsumption.defs" {
    export const createStockConsumptionUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createStockConsumption";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createStockConsumption";
            readonly functionName: "createStockConsumption";
            readonly inputTypeName: "CreateStockConsumptionInput";
            readonly outputTypeName: "CreateStockConsumptionOutput";
            readonly ports: readonly ["Order", "MenuItem", "InventoryItem"];
            readonly rulesApplied: readonly ["ingredientConsumptionTrigger"];
            readonly transactional: true;
            readonly steps: readonly ["Read Order and its OrderItems via Order port", "Read MenuItem recipes (RecipeComponent) via MenuItem port for each OrderItem", "Apply ingredientConsumptionTrigger rule to compute required quantities per InventoryItem", "Read current InventoryItem quantities via InventoryItem port", "Create StockConsumption entries for each consumed ingredient", "Decrement InventoryItem.currentQuantity and update status if below minimumLevel", "Persist StockConsumption and updated InventoryItem within transaction", "Return list of created StockConsumption entries with updated inventory levels"];
        };
    };
    export default createStockConsumptionUsecase;
    export const pipeline: readonly [{
        readonly id: "createStockConsumption__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createStockConsumption.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/createStockConsumption.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["ingredientConsumptionTrigger"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/dineInOrderLifecycle.defs" {
    export const dineInOrderLifecycleUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "dineInOrderLifecycle";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "dineInOrderLifecycle";
            readonly functionName: "dineInOrderLifecycle";
            readonly inputTypeName: "DineInOrderLifecycleInput";
            readonly outputTypeName: "DineInOrderLifecycleOutput";
            readonly ports: readonly ["Order", "DailyShift"];
            readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "tableOccupancyConsistency"];
            readonly transactional: true;
            readonly steps: readonly ["Step 1 - Create Order: validate open DailyShift, assign Table (tableOccupancyConsistency), set orderType=DINE_IN, status=OPEN", "Step 2 - Add Items: add OrderItems with MenuItem references, recalculate totals", "Step 3 - Confirm Order: transition status OPEN -> CONFIRMED (orderStatusTransitions), trigger ingredientConsumptionTrigger", "Step 4 - Kitchen: create KitchenTicket, track preparation through statuses", "Step 5 - Serve: update OrderItem statuses to SERVED as kitchen completes items", "Step 6 - Payment: apply paymentTimingByOrderType (DINE_IN pays at end), record Payment(s)", "Step 7 - Close: validate all items served and payments complete, transition to CLOSED, free Table (tableOccupancyConsistency)", "Return final Order state with full lifecycle summary"];
        };
    };
    export default dineInOrderLifecycleUsecase;
    export const pipeline: readonly [{
        readonly id: "dineInOrderLifecycle__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/dineInOrderLifecycle.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/dineInOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "tableOccupancyConsistency"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/generateShiftCloseReport.defs" {
    export const generateShiftCloseReportUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "generateShiftCloseReport";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "generateShiftCloseReport";
            readonly functionName: "generateShiftCloseReport";
            readonly inputTypeName: "GenerateShiftCloseReportInput";
            readonly outputTypeName: "GenerateShiftCloseReportOutput";
            readonly ports: readonly ["DailyShift", "Payment", "Order"];
            readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
            readonly transactional: false;
            readonly steps: readonly ["Read DailyShift by id via DailyShift port", "Read all Payments for the shift period via Payment port", "Read all closed Orders for the shift via Order port", "Apply paymentTimingByOrderType rule to categorize payments by order type", "Apply aiOutputLanguageSelection rule for report language", "Compute totalSales, totalPayments, cash reconciliation, and variance", "Generate structured report with sections: sales summary, payment breakdown, cash movements, notes", "Return report with metrics and narrative summary"];
        };
    };
    export default generateShiftCloseReportUsecase;
    export const pipeline: readonly [{
        readonly id: "generateShiftCloseReport__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/generateShiftCloseReport.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/generateShiftCloseReport.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/kitchenProductionFlow.defs" {
    export const kitchenProductionFlowUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "kitchenProductionFlow";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "kitchenProductionFlow";
            readonly functionName: "kitchenProductionFlow";
            readonly inputTypeName: "KitchenProductionFlowInput";
            readonly outputTypeName: "KitchenProductionFlowOutput";
            readonly ports: readonly ["Order"];
            readonly rulesApplied: readonly ["orderStatusTransitions"];
            readonly transactional: true;
            readonly steps: readonly ["Step 1 - Receive: read confirmed Order and its OrderItems via Order port", "Step 2 - Create Tickets: generate KitchenTicket(s) grouped by preparation station", "Step 3 - Start Production: transition KitchenTicket status PENDING -> IN_PROGRESS (orderStatusTransitions)", "Step 4 - Item Completion: as each item finishes, update OrderItem status to READY", "Step 5 - Ticket Completion: when all items on a ticket are READY, transition ticket to READY", "Step 6 - Serve: transition OrderItem READY -> SERVED, mark KitchenTicket COMPLETED", "Step 7 - Verify: confirm all KitchenTickets are COMPLETED before allowing Order to close", "Return production flow summary with ticket and item status timeline"];
        };
    };
    export default kitchenProductionFlowUsecase;
    export const pipeline: readonly [{
        readonly id: "kitchenProductionFlow__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/kitchenProductionFlow.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/kitchenProductionFlow.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/manageInventoryItems.defs" {
    export const manageInventoryItemsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "manageInventoryItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "manageInventoryItems";
            readonly functionName: "manageInventoryItems";
            readonly inputTypeName: "ManageInventoryItemsInput";
            readonly outputTypeName: "ManageInventoryItemsOutput";
            readonly ports: readonly ["InventoryItem"];
            readonly rulesApplied: readonly ["inventoryLowStockThreshold", "ingredientConsumptionTrigger"];
            readonly transactional: true;
            readonly steps: readonly ["Read existing InventoryItem by id (for update) or list all (for browse) via InventoryItem port", "For create/update: validate name, unit, minimumLevel, currentQuantity fields", "Apply inventoryLowStockThreshold rule to set status (OK, LOW, CRITICAL) based on currentQuantity vs minimumLevel", "If ingredientConsumptionTrigger context applies, validate no pending consumptions conflict", "Persist InventoryItem changes within transaction", "Return created/updated InventoryItem with computed status"];
        };
    };
    export default manageInventoryItemsUsecase;
    export const pipeline: readonly [{
        readonly id: "manageInventoryItems__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageInventoryItems.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageInventoryItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["inventoryLowStockThreshold", "ingredientConsumptionTrigger"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuCategories.defs" {
    export const manageMenuCategoriesUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "manageMenuCategories";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "manageMenuCategories";
            readonly functionName: "manageMenuCategories";
            readonly inputTypeName: "ManageMenuCategoriesInput";
            readonly outputTypeName: "ManageMenuCategoriesOutput";
            readonly ports: readonly [];
            readonly transactional: true;
            readonly steps: readonly ["Validate MenuCategory name is non-empty and unique", "For update: verify category exists and no orphan MenuItem references remain if deleting", "Create/Update/Delete MenuCategory entity", "Persist within transaction", "Return created/updated/deleted MenuCategory confirmation"];
        };
    };
    export default manageMenuCategoriesUsecase;
    export const pipeline: readonly [{
        readonly id: "manageMenuCategories__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuCategories.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuCategories.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuItems.defs" {
    export const manageMenuItemsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "manageMenuItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "manageMenuItems";
            readonly functionName: "manageMenuItems";
            readonly inputTypeName: "ManageMenuItemsInput";
            readonly outputTypeName: "ManageMenuItemsOutput";
            readonly ports: readonly ["MenuItem"];
            readonly rulesApplied: readonly ["aiOutputLanguageSelection"];
            readonly transactional: true;
            readonly steps: readonly ["Read existing MenuItem by id (for update) or list all (for browse) via MenuItem port", "Validate MenuItem fields: name, price, category, availability", "Apply aiOutputLanguageSelection rule for localized name/description fields", "For create: assign to MenuCategory and set initial availability", "For update: validate category exists and price is positive", "Persist MenuItem within transaction", "Return created/updated MenuItem with category reference"];
        };
    };
    export default manageMenuItemsUsecase;
    export const pipeline: readonly [{
        readonly id: "manageMenuItems__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuItems.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageMenuItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/menuItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/manageTables.defs" {
    export const manageTablesUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "manageTables";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "manageTables";
            readonly functionName: "manageTables";
            readonly inputTypeName: "ManageTablesInput";
            readonly outputTypeName: "ManageTablesOutput";
            readonly ports: readonly [];
            readonly transactional: true;
            readonly steps: readonly ["Validate Table fields: number/label, capacity, area/zone", "Apply tableOccupancyConsistency rule: ensure no active Orders reference a table being deleted or deactivated", "Create/Update/Delete Table entity", "Persist within transaction", "Return created/updated Table with current status"];
        };
    };
    export default manageTablesUsecase;
    export const pipeline: readonly [{
        readonly id: "manageTables__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageTables.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/manageTables.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/openDailyShift.defs" {
    export const openDailyShiftUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "openDailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "openDailyShift";
            readonly functionName: "openDailyShift";
            readonly inputTypeName: "OpenDailyShiftInput";
            readonly outputTypeName: "OpenDailyShiftOutput";
            readonly ports: readonly ["DailyShift"];
            readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
            readonly transactional: true;
            readonly steps: readonly ["Step 1 - Validate: check no other DailyShift is OPEN for the same or overlapping date via DailyShift port", "Step 2 - Create Shift: create DailyShift with shiftDate, status=OPEN, openedAt=now, openingCashBalance", "Step 3 - Configure: apply paymentTimingByOrderType rule to set payment flow defaults for the shift", "Step 4 - Language: apply aiOutputLanguageSelection rule for shift default language", "Step 5 - Record Cash: record opening CashMovement (movementType=OPENING) linked to the shift", "Step 6 - Persist: save DailyShift and CashMovement within transaction", "Return opened DailyShift with dailyShiftId and initial cash balance"];
        };
    };
    export default openDailyShiftUsecase;
    export const pipeline: readonly [{
        readonly id: "openDailyShift__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/openDailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/openDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/recordOpeningCashMovement.defs" {
    export const recordOpeningCashMovementUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "recordOpeningCashMovement";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "recordOpeningCashMovement";
            readonly functionName: "recordOpeningCashMovement";
            readonly inputTypeName: "RecordOpeningCashMovementInput";
            readonly outputTypeName: "RecordOpeningCashMovementOutput";
            readonly ports: readonly ["DailyShift"];
            readonly transactional: true;
            readonly steps: readonly ["Validate DailyShift exists and is OPEN via DailyShift port", "Create CashMovement entity with movementType=OPENING, amount, reason, dailyShiftId", "Update DailyShift.openingCashBalance with the movement amount", "Persist CashMovement and updated DailyShift within transaction", "Return created CashMovement with id and updated shift balance"];
        };
    };
    export default recordOpeningCashMovementUsecase;
    export const pipeline: readonly [{
        readonly id: "recordOpeningCashMovement__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/recordOpeningCashMovement.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/recordOpeningCashMovement.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/recordPayment.defs" {
    export const recordPaymentUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "recordPayment";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "recordPayment";
            readonly functionName: "recordPayment";
            readonly inputTypeName: "RecordPaymentInput";
            readonly outputTypeName: "RecordPaymentOutput";
            readonly ports: readonly ["Payment", "Order", "DailyShift"];
            readonly rulesApplied: readonly ["paymentTimingByOrderType"];
            readonly transactional: true;
            readonly steps: readonly ["Read Order by id via Order port to validate it exists and is payable", "Read DailyShift via DailyShift port to validate shift is OPEN", "Apply paymentTimingByOrderType rule to validate payment is allowed at this stage for the order type", "Create Payment entity with amount, method, order reference, dailyShift reference", "Validate payment amount does not exceed Order.totalAmount (or remaining balance)", "Persist Payment within transaction", "Return created Payment with id and updated order balance"];
        };
    };
    export default recordPaymentUsecase;
    export const pipeline: readonly [{
        readonly id: "recordPayment__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/recordPayment.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/recordPayment.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/takeoutOrderLifecycle.defs" {
    export const takeoutOrderLifecycleUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "takeoutOrderLifecycle";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "takeoutOrderLifecycle";
            readonly functionName: "takeoutOrderLifecycle";
            readonly inputTypeName: "TakeoutOrderLifecycleInput";
            readonly outputTypeName: "TakeoutOrderLifecycleOutput";
            readonly ports: readonly ["Order", "DailyShift"];
            readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger"];
            readonly transactional: true;
            readonly steps: readonly ["Step 1 - Create Order: validate open DailyShift, set orderType=TAKEOUT, status=OPEN (no Table assignment needed)", "Step 2 - Add Items: add OrderItems with MenuItem references, recalculate totals", "Step 3 - Payment: apply paymentTimingByOrderType (TAKEOUT may require payment upfront), record Payment(s)", "Step 4 - Confirm Order: transition status OPEN -> CONFIRMED (orderStatusTransitions), trigger ingredientConsumptionTrigger", "Step 5 - Kitchen: create KitchenTicket, track preparation through statuses", "Step 6 - Ready: transition all OrderItems to READY, notify customer for pickup", "Step 7 - Close: transition Order to CLOSED after pickup confirmation", "Return final Order state with full lifecycle summary"];
        };
    };
    export default takeoutOrderLifecycleUsecase;
    export const pipeline: readonly [{
        readonly id: "takeoutOrderLifecycle__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/takeoutOrderLifecycle.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/takeoutOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/updateKitchenTicketStatus.defs" {
    export const updateKitchenTicketStatusUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateKitchenTicketStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateKitchenTicketStatus";
            readonly functionName: "updateKitchenTicketStatus";
            readonly inputTypeName: "UpdateKitchenTicketStatusInput";
            readonly outputTypeName: "UpdateKitchenTicketStatusOutput";
            readonly ports: readonly [];
            readonly transactional: true;
            readonly steps: readonly ["Read KitchenTicket by id", "Apply orderStatusTransitions rule to validate the status transition (PENDING -> IN_PROGRESS -> READY -> COMPLETED)", "Update KitchenTicket.status and updatedAt", "Persist within transaction", "Return updated KitchenTicket with new status"];
        };
    };
    export default updateKitchenTicketStatusUsecase;
    export const pipeline: readonly [{
        readonly id: "updateKitchenTicketStatus__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateKitchenTicketStatus.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateKitchenTicketStatus.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderItemStatus.defs" {
    export const updateOrderItemStatusUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateOrderItemStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateOrderItemStatus";
            readonly functionName: "updateOrderItemStatus";
            readonly inputTypeName: "UpdateOrderItemStatusInput";
            readonly outputTypeName: "UpdateOrderItemStatusOutput";
            readonly ports: readonly [];
            readonly transactional: true;
            readonly steps: readonly ["Read OrderItem by id", "Apply orderStatusTransitions rule to validate item status transition (PENDING -> PREPARING -> READY -> SERVED)", "Update OrderItem.status and updatedAt", "If ingredientConsumptionTrigger applies on status change to READY/SERVED, enqueue stock consumption", "Persist within transaction", "Return updated OrderItem with new status"];
        };
    };
    export default updateOrderItemStatusUsecase;
    export const pipeline: readonly [{
        readonly id: "updateOrderItemStatus__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderItemStatus.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderItemStatus.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.defs" {
    export const updateOrderStatusUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateOrderStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateOrderStatus";
            readonly functionName: "updateOrderStatus";
            readonly inputTypeName: "UpdateOrderStatusInput";
            readonly outputTypeName: "UpdateOrderStatusOutput";
            readonly ports: readonly ["Order", "Payment", "InventoryItem"];
            readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "aiOutputLanguageSelection", "tableOccupancyConsistency"];
            readonly transactional: true;
            readonly steps: readonly ["Read Order with OrderItems via Order port", "Apply orderStatusTransitions rule to validate the requested status transition", "If transitioning to CLOSED: validate all OrderItems are SERVED/COMPLETED via Order port", "If transitioning to CLOSED: validate payments cover totalAmount via Payment port", "Apply paymentTimingByOrderType rule to ensure payment timing constraints are met", "If ingredientConsumptionTrigger applies (e.g., on CONFIRMED): create StockConsumption and update InventoryItem via InventoryItem port", "If DINE_IN and closing/cancelling: apply tableOccupancyConsistency rule to free the Table", "Apply aiOutputLanguageSelection rule for any notification messages", "Update Order.status, updatedAt, closedAt or cancelledAt + cancellationReason", "Persist Order (and Table, StockConsumption) within transaction", "Return updated Order with new status and side-effect summary"];
        };
    };
    export default updateOrderStatusUsecase;
    export const pipeline: readonly [{
        readonly id: "updateOrderStatus__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/inventoryItemRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "aiOutputLanguageSelection", "tableOccupancyConsistency"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/updateTableStatus.defs" {
    export const updateTableStatusUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateTableStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateTableStatus";
            readonly functionName: "updateTableStatus";
            readonly inputTypeName: "UpdateTableStatusInput";
            readonly outputTypeName: "UpdateTableStatusOutput";
            readonly ports: readonly [];
            readonly transactional: true;
            readonly steps: readonly ["Read Table by id", "Apply tableOccupancyConsistency rule: validate no conflicting active Orders if setting to AVAILABLE", "Update Table.status (AVAILABLE, OCCUPIED, RESERVED, CLEANING) and updatedAt", "Persist within transaction", "Return updated Table with new status"];
        };
    };
    export default updateTableStatusUsecase;
    export const pipeline: readonly [{
        readonly id: "updateTableStatus__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateTableStatus.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/updateTableStatus.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/viewKitchenTickets.defs" {
    export const viewKitchenTicketsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "viewKitchenTickets";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "viewKitchenTickets";
            readonly functionName: "viewKitchenTickets";
            readonly inputTypeName: "ViewKitchenTicketsInput";
            readonly outputTypeName: "ViewKitchenTicketsOutput";
            readonly ports: readonly [];
            readonly transactional: false;
            readonly steps: readonly ["Read KitchenTickets filtered by status, date, or station", "Sort by priority and creation time", "Return list of KitchenTickets with item details and current status"];
        };
    };
    export default viewKitchenTicketsUsecase;
    export const pipeline: readonly [{
        readonly id: "viewKitchenTickets__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/viewKitchenTickets.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/viewKitchenTickets.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_2_application/usecases/viewOperationalDashboard.defs" {
    export const viewOperationalDashboardUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "viewOperationalDashboard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "viewOperationalDashboard";
            readonly functionName: "viewOperationalDashboard";
            readonly inputTypeName: "ViewOperationalDashboardInput";
            readonly outputTypeName: "ViewOperationalDashboardOutput";
            readonly ports: readonly ["DailyShift", "Order", "Payment"];
            readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
            readonly transactional: false;
            readonly steps: readonly ["Read current open DailyShift via DailyShift port", "Read active and recent Orders for the shift via Order port", "Read Payments for the shift via Payment port", "Apply paymentTimingByOrderType rule to categorize revenue by order type", "Apply aiOutputLanguageSelection rule for dashboard labels and language", "Compute real-time metrics: open orders, kitchen load, revenue, table occupancy, payment totals", "Return dashboard data structure with KPIs and breakdowns"];
        };
    };
    export default viewOperationalDashboardUsecase;
    export const pipeline: readonly [{
        readonly id: "viewOperationalDashboard__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/viewOperationalDashboard.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_2_application/usecases/viewOperationalDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102050_/l1/cafeFlow/layer_2_application/ports/paymentRepository.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.defs" {
    export const dailyShiftDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "DailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "DailyShift";
            readonly fields: readonly [{
                readonly fieldId: "dailyShiftId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do turno diário.";
            }, {
                readonly fieldId: "shiftDate";
                readonly type: "date";
                readonly required: true;
                readonly description: "Data operacional do turno.";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Estado atual do turno.";
                readonly enum: readonly ["open", "closed"];
            }, {
                readonly fieldId: "openedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de abertura do turno.";
            }, {
                readonly fieldId: "closedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora de fechamento do turno.";
            }, {
                readonly fieldId: "openingCashBalance";
                readonly type: "money";
                readonly required: false;
                readonly description: "Valor inicial em caixa ao abrir o turno.";
            }, {
                readonly fieldId: "closingCashBalance";
                readonly type: "money";
                readonly required: false;
                readonly description: "Valor final em caixa ao fechar o turno.";
            }, {
                readonly fieldId: "totalSales";
                readonly type: "money";
                readonly required: false;
                readonly description: "Total consolidado de vendas no turno.";
            }, {
                readonly fieldId: "totalPayments";
                readonly type: "money";
                readonly required: false;
                readonly description: "Total consolidado de pagamentos recebidos no turno.";
            }, {
                readonly fieldId: "closingNotes";
                readonly type: "text";
                readonly required: false;
                readonly description: "Observações e relatório de fechamento do turno.";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro.";
            }];
            readonly statusEnum: readonly ["open", "closed"];
            readonly invariants: readonly ["only one DailyShift per shiftDate may be open at a time", "status can only transition from open to closed", "closedAt must be set when status is closed", "closedAt must be after openedAt", "openingCashBalance must be set when status is open", "closingCashBalance and totalSales must be set when status is closed", "cannot add CashMovements to a closed shift"];
            readonly valueObjects: readonly [{
                readonly name: "CashMovement";
                readonly fields: readonly [{
                    readonly fieldId: "cashMovementId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do movimento de caixa";
                }, {
                    readonly fieldId: "dailyShiftId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao turno (DailyShift) ao qual o movimento pertence";
                }, {
                    readonly fieldId: "movementType";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Tipo do movimento: entrada ou saída de caixa";
                    readonly enum: readonly ["entrada", "saída"];
                }, {
                    readonly fieldId: "amount";
                    readonly type: "money";
                    readonly required: true;
                    readonly description: "Valor do movimento";
                }, {
                    readonly fieldId: "reason";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Motivo do movimento (ex.: sangria, reforço, estorno)";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data/hora de criação do registro";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data/hora da última atualização do registro";
                }];
                readonly collection: true;
            }];
        };
    };
    export default dailyShiftDomainEntity;
    export const pipeline: readonly [{
        readonly id: "dailyShift__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/dailyShift.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.defs" {
    export const inventoryItemDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "InventoryItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "InventoryItem";
            readonly fields: readonly [{
                readonly fieldId: "inventoryItemId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do item de estoque";
            }, {
                readonly fieldId: "name";
                readonly type: "string";
                readonly required: true;
                readonly description: "Nome do ingrediente ou insumo";
            }, {
                readonly fieldId: "description";
                readonly type: "text";
                readonly required: false;
                readonly description: "Descrição detalhada do item";
            }, {
                readonly fieldId: "unit";
                readonly type: "string";
                readonly required: true;
                readonly description: "Unidade de medida (ex.: kg, L, unidade, gramas)";
            }, {
                readonly fieldId: "currentQuantity";
                readonly type: "number";
                readonly required: true;
                readonly description: "Quantidade atual disponível em estoque";
            }, {
                readonly fieldId: "minimumLevel";
                readonly type: "number";
                readonly required: true;
                readonly description: "Nível mínimo para geração de alerta de baixo estoque";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Estado do ciclo de vida do item";
                readonly enum: readonly ["active", "inactive"];
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro";
            }];
            readonly statusEnum: readonly ["active", "inactive"];
            readonly invariants: readonly ["currentQuantity must not be negative", "minimumLevel must be greater than or equal to zero", "name must not be empty", "unit must not be empty", "status can only transition between active and inactive"];
            readonly valueObjects: readonly [];
        };
    };
    export default inventoryItemDomainEntity;
    export const pipeline: readonly [{
        readonly id: "inventoryItem__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/inventoryItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.defs" {
    export const menuItemDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "MenuItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "MenuItem";
            readonly fields: readonly [{
                readonly fieldId: "menuItemId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do item do cardápio";
            }, {
                readonly fieldId: "menuCategoryId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência à categoria do cardápio à qual o item pertence";
            }, {
                readonly fieldId: "name";
                readonly type: "string";
                readonly required: true;
                readonly description: "Nome do item (ex.: cappuccino, pão de queijo)";
            }, {
                readonly fieldId: "description";
                readonly type: "text";
                readonly required: false;
                readonly description: "Descrição detalhada do item";
            }, {
                readonly fieldId: "price";
                readonly type: "money";
                readonly required: true;
                readonly description: "Preço de venda do item";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Estado do ciclo de vida do item";
                readonly enum: readonly ["draft", "active", "inactive"];
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro";
            }];
            readonly statusEnum: readonly ["draft", "active", "inactive"];
            readonly invariants: readonly ["price must be greater than zero", "name must not be empty", "status can only transition from draft to active, active to inactive, and inactive to active", "cannot delete a MenuItem referenced by active OrderItems"];
            readonly valueObjects: readonly [{
                readonly name: "RecipeComponent";
                readonly fields: readonly [{
                    readonly fieldId: "recipeComponentId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do componente de receita";
                }, {
                    readonly fieldId: "menuItemId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao item de menu ao qual este componente pertence";
                }, {
                    readonly fieldId: "inventoryItemId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao item de inventário utilizado como ingrediente";
                }, {
                    readonly fieldId: "quantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade consumida do item de inventário por unidade vendida do menu item";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do registro";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do registro";
                }];
                readonly collection: true;
            }];
        };
    };
    export default menuItemDomainEntity;
    export const pipeline: readonly [{
        readonly id: "menuItem__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/menuItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_3_domain/entities/order.defs" {
    export const orderDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Order";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Order";
            readonly fields: readonly [{
                readonly fieldId: "orderId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do pedido";
            }, {
                readonly fieldId: "dailyShiftId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Turno diário em que o pedido foi registrado";
            }, {
                readonly fieldId: "tableId";
                readonly type: "uuid";
                readonly required: false;
                readonly description: "Referência à mesa associada (para pedidos do tipo mesa)";
            }, {
                readonly fieldId: "kitchenTicketId";
                readonly type: "uuid";
                readonly required: false;
                readonly description: "Ticket de cozinha gerado para fila de preparo";
            }, {
                readonly fieldId: "orderType";
                readonly type: "string";
                readonly required: true;
                readonly description: "Tipo do pedido: mesa ou takeout";
                readonly enum: readonly ["mesa", "takeout"];
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Status atual do pedido na coordenação com a cozinha";
                readonly enum: readonly ["draft", "sentToKitchen", "inPreparation", "ready", "served", "closed", "cancelled"];
            }, {
                readonly fieldId: "totalAmount";
                readonly type: "money";
                readonly required: true;
                readonly description: "Valor total do pedido com preços no momento da venda";
            }, {
                readonly fieldId: "notes";
                readonly type: "text";
                readonly required: false;
                readonly description: "Observações gerais do pedido";
            }, {
                readonly fieldId: "customerName";
                readonly type: "string";
                readonly required: false;
                readonly description: "Nome do cliente para identificação do pedido";
            }, {
                readonly fieldId: "customerPhone";
                readonly type: "string";
                readonly required: false;
                readonly description: "Telefone de contato do cliente";
            }, {
                readonly fieldId: "numberOfGuests";
                readonly type: "number";
                readonly required: false;
                readonly description: "Número de pessoas na mesa";
            }, {
                readonly fieldId: "closedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora do fechamento do pedido";
            }, {
                readonly fieldId: "cancelledAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora do cancelamento do pedido";
            }, {
                readonly fieldId: "cancellationReason";
                readonly type: "text";
                readonly required: false;
                readonly description: "Motivo do cancelamento";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro";
            }];
            readonly statusEnum: readonly ["draft", "sentToKitchen", "inPreparation", "ready", "served", "closed", "cancelled"];
            readonly invariants: readonly ["totalAmount must equal the sum of all OrderItem.totalPrice", "when orderType is mesa, tableId is required", "when orderType is takeout, tableId must be null", "status transitions must follow: draft -> sentToKitchen -> inPreparation -> ready -> served -> closed; any state can go to cancelled", "closedAt must be set when status is closed", "cancelledAt and cancellationReason must be set when status is cancelled", "cannot add or modify OrderItems after status is sentToKitchen or beyond", "numberOfGuests must be greater than zero when provided"];
            readonly valueObjects: readonly [{
                readonly name: "OrderItem";
                readonly fields: readonly [{
                    readonly fieldId: "id";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do item do pedido";
                }, {
                    readonly fieldId: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao pedido (Order) ao qual este item pertence";
                }, {
                    readonly fieldId: "menuItemId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao item do cardápio (MenuItem) solicitado";
                }, {
                    readonly fieldId: "kitchenTicketId";
                    readonly type: "uuid";
                    readonly required: false;
                    readonly description: "Referência ao ticket de cozinha (KitchenTicket) quando o item exige preparo";
                }, {
                    readonly fieldId: "quantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade solicitada do item";
                }, {
                    readonly fieldId: "unitPrice";
                    readonly type: "money";
                    readonly required: true;
                    readonly description: "Preço unitário do item no momento do pedido";
                }, {
                    readonly fieldId: "totalPrice";
                    readonly type: "money";
                    readonly required: true;
                    readonly description: "Preço total do item (quantidade × preço unitário)";
                }, {
                    readonly fieldId: "observations";
                    readonly type: "text";
                    readonly required: false;
                    readonly description: "Observações ou instruções especiais para o item";
                }, {
                    readonly fieldId: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Status de produção/atendimento do item";
                    readonly enum: readonly ["new", "sentToKitchen", "inPreparation", "ready", "served", "cancelled"];
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do registro";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do registro";
                }];
                readonly collection: true;
            }, {
                readonly name: "KitchenTicket";
                readonly fields: readonly [{
                    readonly fieldId: "kitchenTicketId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do ticket de cozinha";
                }, {
                    readonly fieldId: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao pedido que gerou este ticket para a fila de preparo";
                }, {
                    readonly fieldId: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Status atual do ticket na fila de preparo da cozinha";
                    readonly enum: readonly ["open", "inProgress", "done", "void"];
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do ticket";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do ticket";
                }];
                readonly collection: true;
            }];
        };
    };
    export default orderDomainEntity;
    export const pipeline: readonly [{
        readonly id: "order__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/order.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/order.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.defs" {
    export const paymentDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Payment";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Payment";
            readonly fields: readonly [{
                readonly fieldId: "paymentId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do pagamento.";
            }, {
                readonly fieldId: "orderId";
                readonly type: "uuid";
                readonly required: false;
                readonly description: "Referência ao pedido associado ao pagamento, quando aplicável.";
            }, {
                readonly fieldId: "dailyShiftId";
                readonly type: "uuid";
                readonly required: false;
                readonly description: "Referência ao turno diário de fechamento ao qual o pagamento será consolidado.";
            }, {
                readonly fieldId: "method";
                readonly type: "string";
                readonly required: true;
                readonly description: "Método de pagamento utilizado (ex.: dinheiro, cartão de crédito, PIX).";
            }, {
                readonly fieldId: "amount";
                readonly type: "money";
                readonly required: true;
                readonly description: "Valor recebido/pago.";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Situação atual do pagamento no ciclo de vida.";
                readonly enum: readonly ["authorized", "captured", "voided", "refunded"];
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro.";
            }];
            readonly statusEnum: readonly ["authorized", "captured", "voided", "refunded"];
            readonly invariants: readonly ["amount must be greater than zero", "method must not be empty", "status transitions must follow: authorized -> captured; captured -> refunded; authorized -> voided; captured -> voided", "dailyShiftId must reference an open DailyShift when set", "orderId must reference a non-cancelled Order when set", "a voided or refunded Payment cannot transition to any other status"];
            readonly valueObjects: readonly [];
        };
    };
    export default paymentDomainEntity;
    export const pipeline: readonly [{
        readonly id: "payment__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.ts";
        readonly defPath: "_102050_/l1/cafeFlow/layer_3_domain/entities/payment.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            description: string;
            sourceType: string;
            enum?: undefined;
            lifecycleStates?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            enum: string[];
            lifecycleStates: string[];
            description: string;
            sourceType?: undefined;
        })[];
        output: ({
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            description: string;
            sourceType: string;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            description: string;
            sourceType?: undefined;
        })[];
        readsEntities: string[];
        writesEntities: any[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "aiPromotionSuggestions__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            description: string;
            sourceType: string;
            enum?: undefined;
            lifecycleStates?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            enum: string[];
            lifecycleStates: string[];
            description: string;
            sourceType?: undefined;
        })[];
        output: ({
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            description: string;
            sourceType: string;
            enum?: undefined;
            lifecycleStates?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            enum: string[];
            lifecycleStates: string[];
            description: string;
            sourceType?: undefined;
        })[];
        readsEntities: string[];
        writesEntities: any[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "aiSalesSummary__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            description: string;
            sourceType: string;
            enum?: undefined;
            lifecycleStates?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            description: string;
            sourceType?: undefined;
            enum?: undefined;
            lifecycleStates?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            enum: string[];
            lifecycleStates: string[];
            description: string;
            sourceType?: undefined;
        })[];
        output: ({
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            description: string;
            sourceType: string;
            enum?: undefined;
            lifecycleStates?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            description: string;
            sourceType?: undefined;
            enum?: undefined;
            lifecycleStates?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            enum: string[];
            lifecycleStates: string[];
            description: string;
            sourceType?: undefined;
        })[];
        readsEntities: string[];
        writesEntities: any[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "browseMenuForPos__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            description: string;
            sourceType: string;
            enum?: undefined;
            lifecycleStates?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            description: string;
            sourceType?: undefined;
            enum?: undefined;
            lifecycleStates?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            enum: string[];
            lifecycleStates: string[];
            description: string;
            sourceType?: undefined;
        })[];
        output: {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            description: string;
            sourceType: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "closeDailyShift__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            description: string;
            enum?: undefined;
            sourceType?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            enum: string[];
            description: string;
            sourceType?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            description: string;
            sourceType: string;
            enum?: undefined;
        })[];
        output: {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            description: string;
            sourceType: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "consumeIngredientsOnConfirmation__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            enum: string[];
            description: string;
            lifecycleStates?: undefined;
            sourceType?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            enum: string[];
            lifecycleStates: string[];
            description: string;
            sourceType?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            description: string;
            sourceType: string;
            enum?: undefined;
            lifecycleStates?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            description: string;
            enum?: undefined;
            lifecycleStates?: undefined;
            sourceType?: undefined;
        })[];
        output: {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            description: string;
            sourceType: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "dineInOrderLifecycle__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            enum: string[];
            lifecycleStates: string[];
            description: string;
            sourceType?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            description: string;
            sourceType: string;
            enum?: undefined;
            lifecycleStates?: undefined;
        })[];
        output: ({
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            enum: string[];
            lifecycleStates: string[];
            description: string;
            sourceType?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            description: string;
            sourceType: string;
            enum?: undefined;
            lifecycleStates?: undefined;
        })[];
        readsEntities: string[];
        writesEntities: any[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "generateShiftCloseReport__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.defs" {
    export const definition: ({
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            description: string;
            sourceType: string;
            enum?: undefined;
            lifecycleStates?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            enum: string[];
            lifecycleStates: string[];
            description: string;
            sourceType?: undefined;
        })[];
        output: ({
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            description: string;
            sourceType: string;
            enum?: undefined;
            lifecycleStates?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            enum: string[];
            lifecycleStates: string[];
            description: string;
            sourceType?: undefined;
        })[];
        readsEntities: string[];
        writesEntities: any[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    } | {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            enum: string[];
            lifecycleStates: string[];
            description: string;
        }[];
        output: {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            description: string;
            sourceType: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    })[];
    export const pipeline: readonly [{
        readonly id: "kitchenProductionFlow__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            description: string;
            sourceType?: undefined;
            enum?: undefined;
            lifecycleStates?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            description: string;
            sourceType: string;
            enum?: undefined;
            lifecycleStates?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            enum: string[];
            lifecycleStates: string[];
            description: string;
            sourceType?: undefined;
        })[];
        output: {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            description: string;
            sourceType: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "manageInventoryItems__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            description: string;
            sourceType: string;
            enum?: undefined;
            lifecycleStates?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            description: string;
            sourceType?: undefined;
            enum?: undefined;
            lifecycleStates?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            enum: string[];
            lifecycleStates: string[];
            description: string;
            sourceType?: undefined;
        })[];
        output: {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            description: string;
            sourceType: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: any[];
    }[];
    export const pipeline: readonly [{
        readonly id: "manageMenuCategories__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageMenuItems.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            description: string;
            sourceType: string;
            enum?: undefined;
            lifecycleStates?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            description: string;
            sourceType?: undefined;
            enum?: undefined;
            lifecycleStates?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            enum: string[];
            lifecycleStates: string[];
            description: string;
            sourceType?: undefined;
        })[];
        output: {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            description: string;
            sourceType: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "manageMenuItems__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/manageMenuItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/manageMenuItems.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/manageTables.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            description: string;
            sourceType: string;
            enum?: undefined;
            lifecycleStates?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            description: string;
            sourceType?: undefined;
            enum?: undefined;
            lifecycleStates?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            enum: string[];
            lifecycleStates: string[];
            description: string;
            sourceType?: undefined;
        })[];
        output: {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            description: string;
            sourceType: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "manageTables__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/manageTables.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/manageTables.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/openDailyShift.defs" {
    export const definition: ({
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            description: string;
            enum?: undefined;
            lifecycleStates?: undefined;
            sourceType?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            enum: string[];
            lifecycleStates: string[];
            description: string;
            sourceType?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            description: string;
            sourceType: string;
            enum?: undefined;
            lifecycleStates?: undefined;
        })[];
        output: {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            description: string;
            sourceType: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    } | {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            enum: string[];
            description: string;
            sourceType?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            description: string;
            sourceType: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            description: string;
            enum?: undefined;
            sourceType?: undefined;
        })[];
        output: {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            description: string;
            sourceType: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: any[];
    })[];
    export const pipeline: readonly [{
        readonly id: "openDailyShift__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/openDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/openDailyShift.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/recordPayment.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            description: string;
            sourceType?: undefined;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            description: string;
            sourceType: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            enum: string[];
            description: string;
            sourceType?: undefined;
        })[];
        output: {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            description: string;
            sourceType: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "recordPayment__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/recordPayment.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/recordPayment.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            enum: string[];
            description: string;
            lifecycleStates?: undefined;
            sourceType?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            enum: string[];
            lifecycleStates: string[];
            description: string;
            sourceType?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            description: string;
            sourceType: string;
            enum?: undefined;
            lifecycleStates?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            description: string;
            enum?: undefined;
            lifecycleStates?: undefined;
            sourceType?: undefined;
        })[];
        output: {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            description: string;
            sourceType: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "takeoutOrderLifecycle__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            description: string;
            sourceType: string;
            enum?: undefined;
            lifecycleStates?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            description: string;
            sourceType?: undefined;
            enum?: undefined;
            lifecycleStates?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            required: boolean;
            enum: string[];
            lifecycleStates: string[];
            description: string;
            sourceType?: undefined;
        })[];
        output: ({
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            description: string;
            sourceType: string;
            enum?: undefined;
            lifecycleStates?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            description: string;
            sourceType?: undefined;
            enum?: undefined;
            lifecycleStates?: undefined;
        } | {
            name: string;
            type: string;
            sourceEntity: string;
            sourceField: string;
            enum: string[];
            lifecycleStates: string[];
            description: string;
            sourceType?: undefined;
        })[];
        readsEntities: string[];
        writesEntities: any[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "viewOperationalDashboard__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/aiPromotionSuggestions.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                moleculeRefs: {
                    id: string;
                    type: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    molecules: ({
                        id: string;
                        type: string;
                        order: number;
                        titleKey: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        stateKey: string;
                        emptyKey?: undefined;
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        titleKey: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    })[];
                }[];
            }[];
        };
        i18n: {
            "section.aiPromotionSuggestions.title": string;
            "organism.aiPromotionSuggestions.title": string;
            "molecule.actionBar.title": string;
            "action.aiPromotionSuggestions.label": string;
            "molecule.table.title": string;
            "table.aiPromotionSuggestions.empty": string;
            "column.id": string;
            "column.orderId": string;
            "column.menuItemId": string;
            "column.kitchenTicketId": string;
            "column.quantity": string;
            "column.unitPrice": string;
            "column.totalPrice": string;
            "column.observations": string;
        };
        dataBindings: {
            id: string;
            source: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "aiPromotionSuggestions__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/aiPromotionSuggestions.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/aiPromotionSuggestions.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/aiPromotionSuggestions.ts", "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/aiSalesSummary.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                moleculeRefs: {
                    id: string;
                    type: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    molecules: ({
                        id: string;
                        type: string;
                        order: number;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        stateKey: string;
                    })[];
                }[];
            }[];
        };
        i18n: {
            "page.aiSalesSummary.title": string;
            "organism.aiSalesSummary.title": string;
            "field.dailyShiftId.label": string;
            "field.status.label": string;
            "field.closedAt.label": string;
            "field.totalAmount.label": string;
            "action.aiSalesSummary.run": string;
            "summary.aiSalesSummary.empty": string;
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "aiSalesSummary__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/aiSalesSummary.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/aiSalesSummary.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/aiSalesSummary.ts", "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/browseMenuForPos.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                moleculeRefs: {
                    id: string;
                    type: string;
                    stateKey: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: any[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                moleculeRefs: {
                    id: string;
                    type: string;
                    stateKey: string;
                    order: number;
                }[];
            })[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    molecules: ({
                        id: string;
                        type: string;
                        order: number;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            source?: undefined;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        stateKey: string;
                    })[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: any[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    molecules: {
                        id: string;
                        type: string;
                        order: number;
                        source: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                        })[];
                        filters: any[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                })[];
            }[];
        };
        i18n: {
            "section.browseMenu.title": string;
            "organism.filters.title": string;
            "organism.results.title": string;
            "field.menuCategoryId": string;
            "field.name": string;
            "field.status": string;
            "column.name": string;
            "column.description": string;
            "column.price": string;
            "column.status": string;
            "column.menuCategoryId": string;
            "action.browseMenuForPos": string;
            "action.refresh": string;
            "table.empty": string;
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "browseMenuForPos__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/browseMenuForPos.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/browseMenuForPos.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/browseMenuForPos.ts", "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/closeDailyShift.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                moleculeRefs: {
                    id: string;
                    type: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    molecules: ({
                        id: string;
                        type: string;
                        order: number;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    })[];
                }[];
            }[];
        };
        i18n: {
            "closeDailyShift.section.title": string;
            "closeDailyShift.org.updateDailyShiftStatus.title": string;
            "closeDailyShift.org.recordClosingCashMovement.title": string;
            "closeDailyShift.field.shiftDate": string;
            "closeDailyShift.field.status": string;
            "closeDailyShift.field.openedAt": string;
            "closeDailyShift.field.openingCashBalance": string;
            "closeDailyShift.field.closingCashBalance": string;
            "closeDailyShift.field.totalSales": string;
            "closeDailyShift.field.totalPayments": string;
            "closeDailyShift.field.closingNotes": string;
            "closeDailyShift.field.closedAt": string;
            "closeDailyShift.action.updateDailyShiftStatus": string;
            "closeDailyShift.action.recordClosingCashMovement": string;
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "closeDailyShift__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/closeDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/closeDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/closeDailyShift.ts", "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/consumeIngredientsOnConfirmation.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                moleculeRefs: {
                    id: string;
                    type: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: any[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    molecules: {
                        id: string;
                        type: string;
                        order: number;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format?: undefined;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: any[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    molecules: {
                        id: string;
                        type: string;
                        order: number;
                        emptyKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format?: undefined;
                        })[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    molecules: ({
                        id: string;
                        type: string;
                        order: number;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            source?: undefined;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                            source?: undefined;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    })[];
                })[];
            }[];
        };
        i18n: {
            "page.consumeIngredientsOnConfirmation.title": string;
            "organism.orderSummary.title": string;
            "organism.orderItemsReview.title": string;
            "organism.recipeComponentsPreview.title": string;
            "organism.createStockConsumption.title": string;
            "field.order.orderId": string;
            "field.order.orderType": string;
            "field.order.status": string;
            "field.order.totalAmount": string;
            "field.order.customerName": string;
            "field.order.numberOfGuests": string;
            "field.order.createdAt": string;
            "column.orderItem.id": string;
            "column.orderItem.menuItemName": string;
            "column.orderItem.quantity": string;
            "column.orderItem.unitPrice": string;
            "column.orderItem.totalPrice": string;
            "column.orderItem.status": string;
            "column.recipe.inventoryItemName": string;
            "column.recipe.unit": string;
            "column.recipe.quantityPerUnit": string;
            "column.recipe.currentStock": string;
            "column.recipe.minimumLevel": string;
            "field.stockConsumption.quantity": string;
            "field.stockConsumption.status": string;
            "field.stockConsumption.consumedAt": string;
            "action.createStockConsumption.label": string;
            "empty.orderItems.noData": string;
            "empty.recipeComponents.noData": string;
        };
        dataBindings: ({
            id: string;
            source: string;
            entity: string;
            description: string;
            stateKey: string;
            command?: undefined;
            inputStateKeys?: undefined;
        } | {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        })[];
    };
    export const pipeline: readonly [{
        readonly id: "consumeIngredientsOnConfirmation__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/consumeIngredientsOnConfirmation.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/consumeIngredientsOnConfirmation.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/consumeIngredientsOnConfirmation.ts", "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/dineInOrderLifecycle.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                moleculeRefs: ({
                    id: string;
                    type: string;
                    stateKey: string;
                    order: number;
                } | {
                    id: string;
                    type: string;
                    order: number;
                    stateKey?: undefined;
                })[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    molecules: ({
                        id: string;
                        type: string;
                        order: number;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        binding?: undefined;
                        emptyKey?: undefined;
                        displayHint?: undefined;
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        binding?: undefined;
                        emptyKey?: undefined;
                        displayHint?: undefined;
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        binding: string;
                        emptyKey: string;
                        displayHint: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    })[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    molecules: ({
                        id: string;
                        type: string;
                        order: number;
                        binding: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        binding?: undefined;
                        displayHint?: undefined;
                        stateKey?: undefined;
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        binding?: undefined;
                        displayHint?: undefined;
                        stateKey?: undefined;
                    })[];
                })[];
            }[];
        };
        i18n: {
            "section.dineInLifecycle.title": string;
            "organism.createOrder.title": string;
            "organism.addOrderItem.title": string;
            "organism.createKitchenTicket.title": string;
            "organism.updateOrderStatus.title": string;
            "organism.updateTableStatus.title": string;
            "field.orderType.label": string;
            "field.tableId.label": string;
            "field.numberOfGuests.label": string;
            "field.customerName.label": string;
            "field.customerPhone.label": string;
            "field.notes.label": string;
            "field.totalAmount.label": string;
            "field.orderStatus.label": string;
            "field.menuItemId.label": string;
            "field.quantity.label": string;
            "field.unitPrice.label": string;
            "field.totalPrice.label": string;
            "field.observations.label": string;
            "field.itemStatus.label": string;
            "field.orderId.label": string;
            "field.kitchenTicketStatus.label": string;
            "field.updateStatus.label": string;
            "field.cancellationReason.label": string;
            "field.tableStatus.label": string;
            "column.menuItemId.label": string;
            "column.quantity.label": string;
            "column.unitPrice.label": string;
            "column.totalPrice.label": string;
            "column.observations.label": string;
            "column.itemStatus.label": string;
            "action.createOrder.label": string;
            "action.addOrderItem.label": string;
            "action.createKitchenTicket.label": string;
            "action.updateOrderStatus.label": string;
            "action.cancelOrder.label": string;
            "action.updateTableStatus.label": string;
            "empty.orderItems": string;
        };
        dataBindings: ({
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        } | {
            id: string;
            source: string;
            entity: string;
            description: string;
            stateKey: string;
            command?: undefined;
            inputStateKeys?: undefined;
        })[];
    };
    export const pipeline: readonly [{
        readonly id: "dineInOrderLifecycle__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/dineInOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/dineInOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/dineInOrderLifecycle.ts", "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/generateShiftCloseReport.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                moleculeRefs: {
                    id: string;
                    type: string;
                    stateKey: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: any[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                moleculeRefs: {
                    id: string;
                    type: string;
                    order: number;
                }[];
            }[];
        })[];
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    molecules: {
                        id: string;
                        type: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        stateKey: string;
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: any[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    molecules: {
                        id: string;
                        type: string;
                        order: number;
                        titleKey: string;
                        binding: string;
                        emptyKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            })[];
        };
        i18n: {
            "page.title": string;
            "section.filters.title": string;
            "section.report.title": string;
            "organism.shiftFilter.title": string;
            "organism.shiftCloseReport.title": string;
            "molecule.filterForm.title": string;
            "molecule.summaryPanel.title": string;
            "field.status.label": string;
            "field.openedAt.label": string;
            "field.closedAt.label": string;
            "field.openingCashBalance.label": string;
            "field.closingCashBalance.label": string;
            "field.totalSales.label": string;
            "field.totalPayments.label": string;
            "field.closingNotes.label": string;
            "action.generateShiftCloseReport.label": string;
            "empty.report": string;
        };
        dataBindings: {
            id: string;
            source: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "generateShiftCloseReport__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/generateShiftCloseReport.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/generateShiftCloseReport.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/generateShiftCloseReport.ts", "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/kitchenProductionFlow.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                moleculeRefs: {
                    id: string;
                    type: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    molecules: ({
                        id: string;
                        type: string;
                        order: number;
                        fields: any[];
                        columns: any[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        stateKey: string;
                        binding?: undefined;
                        emptyKey?: undefined;
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        binding: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        filters: any[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                    })[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    molecules: ({
                        id: string;
                        type: string;
                        order: number;
                        emptyKey: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        stateKey: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        emptyKey?: undefined;
                    })[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    molecules: ({
                        id: string;
                        type: string;
                        order: number;
                        binding: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        stateKey: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        binding?: undefined;
                        emptyKey?: undefined;
                    })[];
                })[];
            }[];
        };
        i18n: {
            "section.kitchenProductionFlow.title": string;
            "organism.viewKitchenTickets.title": string;
            "organism.updateKitchenTicketStatus.title": string;
            "organism.updateOrderItemStatus.title": string;
            "filter.status.label": string;
            "filter.orderId.label": string;
            "action.applyFilters.label": string;
            "column.kitchenTicketId.label": string;
            "column.orderId.label": string;
            "column.status.label": string;
            "column.createdAt.label": string;
            "column.updatedAt.label": string;
            "toolbar.refresh.label": string;
            "rowAction.selectTicket.label": string;
            "empty.tickets.label": string;
            "field.kitchenTicketId.label": string;
            "field.orderId.label": string;
            "field.status.label": string;
            "field.createdAt.label": string;
            "empty.selectedTicket.label": string;
            "action.startPreparation.label": string;
            "action.finishPreparation.label": string;
            "action.cancelTicket.label": string;
            "column.itemId.label": string;
            "column.menuItemId.label": string;
            "column.quantity.label": string;
            "column.observations.label": string;
            "column.itemStatus.label": string;
            "column.itemUpdatedAt.label": string;
            "rowAction.selectItem.label": string;
            "empty.orderItems.label": string;
            "action.markInPreparation.label": string;
            "action.markReady.label": string;
            "action.markServed.label": string;
            "action.cancelItem.label": string;
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "kitchenProductionFlow__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/kitchenProductionFlow.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/kitchenProductionFlow.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/kitchenProductionFlow.ts", "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/manageInventoryItems.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                moleculeRefs: {
                    id: string;
                    type: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    molecules: ({
                        id: string;
                        type: string;
                        order: number;
                        fields: any[];
                        columns: any[];
                        filters: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            source?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        })[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                            source?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                            source?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        })[];
                        filters: any[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                            source?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                            source?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    })[];
                }[];
            }[];
        };
        i18n: {
            "page.manageInventoryItems.title": string;
            "organism.manageInventoryItems.title": string;
            "filter.name.label": string;
            "filter.status.label": string;
            "column.name.label": string;
            "column.unit.label": string;
            "column.currentQuantity.label": string;
            "column.minimumLevel.label": string;
            "column.status.label": string;
            "column.updatedAt.label": string;
            "toolbar.new.label": string;
            "toolbar.refresh.label": string;
            "rowAction.edit.label": string;
            "rowAction.deactivate.label": string;
            "summary.totalItems.label": string;
            "summary.lowStockItems.label": string;
            "summary.activeItems.label": string;
            "field.name.label": string;
            "field.description.label": string;
            "field.unit.label": string;
            "field.currentQuantity.label": string;
            "field.minimumLevel.label": string;
            "field.status.label": string;
            "action.save.label": string;
            "action.cancel.label": string;
            "table.empty": string;
        };
        dataBindings: ({
            id: string;
            source: string;
            entity: string;
            description: string;
            stateKey: string;
            command?: undefined;
            inputStateKeys?: undefined;
        } | {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        })[];
    };
    export const pipeline: readonly [{
        readonly id: "manageInventoryItems__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageInventoryItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageInventoryItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/manageInventoryItems.ts", "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuCategories.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: any[];
                order: number;
                moleculeRefs: ({
                    id: string;
                    type: string;
                    stateKey: string;
                    order: number;
                    submitAction?: undefined;
                } | {
                    id: string;
                    type: string;
                    stateKey: string;
                    submitAction: string;
                    order: number;
                })[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: any[];
                    order: number;
                    molecules: ({
                        id: string;
                        type: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            source?: undefined;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                            source?: undefined;
                        })[];
                        filters: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            source?: undefined;
                        })[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                        submitAction?: undefined;
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        titleKey: string;
                        binding: string;
                        submitAction: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            source?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        source?: undefined;
                        emptyKey?: undefined;
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        titleKey: string;
                        stateKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        source?: undefined;
                        binding?: undefined;
                        emptyKey?: undefined;
                        submitAction?: undefined;
                    })[];
                }[];
            }[];
        };
        i18n: {
            "page.manageMenuCategories.title": string;
            "organism.manageMenuCategories.title": string;
            "molecule.categoriesTable.title": string;
            "molecule.categoriesTable.empty": string;
            "molecule.categoryForm.title": string;
            "molecule.summaryPanel.title": string;
            "field.menuCategory.menuCategoryId": string;
            "field.menuCategory.name": string;
            "field.menuCategory.description": string;
            "field.menuCategory.status": string;
            "field.menuCategory.createdAt": string;
            "field.menuCategory.updatedAt": string;
            "filter.menuCategory.status": string;
            "filter.menuCategory.name": string;
            "action.manageMenuCategories.new": string;
            "action.manageMenuCategories.edit": string;
            "action.manageMenuCategories.toggleStatus": string;
            "action.manageMenuCategories.delete": string;
            "action.manageMenuCategories.save": string;
            "action.manageMenuCategories.cancel": string;
            "summary.menuCategory.total": string;
            "summary.menuCategory.active": string;
            "summary.menuCategory.inactive": string;
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "manageMenuCategories__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuCategories.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuCategories.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/manageMenuCategories.ts", "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuItems.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                moleculeRefs: ({
                    id: string;
                    type: string;
                    order: number;
                    stateKey?: undefined;
                } | {
                    id: string;
                    type: string;
                    stateKey: string;
                    order: number;
                })[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                moleculeRefs: ({
                    id: string;
                    type: string;
                    stateKey: string;
                    submitAction: string;
                    order: number;
                } | {
                    id: string;
                    type: string;
                    order: number;
                    stateKey?: undefined;
                    submitAction?: undefined;
                })[];
            })[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    molecules: ({
                        id: string;
                        type: string;
                        order: number;
                        fields: any[];
                        columns: any[];
                        filters: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            source?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        })[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        source?: undefined;
                        binding?: undefined;
                        emptyKey?: undefined;
                        stateKey?: undefined;
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            source?: undefined;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                            source?: undefined;
                        })[];
                        filters: any[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                    })[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    molecules: ({
                        id: string;
                        type: string;
                        order: number;
                        binding: string;
                        submitAction: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            source?: undefined;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                            source?: undefined;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        binding?: undefined;
                        submitAction?: undefined;
                        stateKey?: undefined;
                    })[];
                })[];
            }[];
        };
        i18n: {
            "section.manageMenuItems.title": string;
            "organism.menuItemsList.title": string;
            "organism.menuItemForm.title": string;
            "filter.name.label": string;
            "filter.status.label": string;
            "filter.menuCategoryId.label": string;
            "column.name.label": string;
            "column.menuCategoryId.label": string;
            "column.price.label": string;
            "column.status.label": string;
            "column.updatedAt.label": string;
            "toolbar.new.label": string;
            "rowAction.edit.label": string;
            "rowAction.deactivate.label": string;
            "empty.menuItemsTable": string;
            "field.menuItemId.label": string;
            "field.menuCategoryId.label": string;
            "field.name.label": string;
            "field.description.label": string;
            "field.price.label": string;
            "field.status.label": string;
            "action.save.label": string;
            "action.cancel.label": string;
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "manageMenuItems__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/manageMenuItems.ts", "_102050_/l2/cafeFlow/web/contracts/manageMenuItems.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/manageTables.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                moleculeRefs: ({
                    id: string;
                    type: string;
                    order: number;
                    stateKey?: undefined;
                } | {
                    id: string;
                    type: string;
                    stateKey: string;
                    order: number;
                })[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                moleculeRefs: ({
                    id: string;
                    type: string;
                    stateKey: string;
                    submitAction: string;
                    order: number;
                } | {
                    id: string;
                    type: string;
                    order: number;
                    stateKey?: undefined;
                    submitAction?: undefined;
                })[];
            })[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    molecules: ({
                        id: string;
                        type: string;
                        order: number;
                        fields: any[];
                        columns: any[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        binding?: undefined;
                        emptyKey?: undefined;
                        stateKey?: undefined;
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        binding: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            source?: undefined;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                            source?: undefined;
                        })[];
                        filters: any[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                    })[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    molecules: ({
                        id: string;
                        type: string;
                        order: number;
                        binding: string;
                        submitAction: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            source?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        binding?: undefined;
                        submitAction?: undefined;
                        stateKey?: undefined;
                    })[];
                })[];
            }[];
        };
        i18n: {
            "page.manageTables.section.title": string;
            "page.manageTables.organism.tableList.title": string;
            "page.manageTables.organism.form.title": string;
            "page.manageTables.filter.status": string;
            "page.manageTables.column.number": string;
            "page.manageTables.column.status": string;
            "page.manageTables.column.createdAt": string;
            "page.manageTables.column.updatedAt": string;
            "page.manageTables.toolbar.newTable": string;
            "page.manageTables.rowAction.edit": string;
            "page.manageTables.rowAction.delete": string;
            "page.manageTables.table.empty": string;
            "page.manageTables.field.tableId": string;
            "page.manageTables.field.number": string;
            "page.manageTables.field.status": string;
            "page.manageTables.action.save": string;
            "page.manageTables.action.cancel": string;
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "manageTables__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageTables.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/manageTables.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/manageTables.ts", "_102050_/l2/cafeFlow/web/contracts/manageTables.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/openDailyShift.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                moleculeRefs: ({
                    id: string;
                    type: string;
                    stateKey: string;
                    order: number;
                    submitAction?: undefined;
                } | {
                    id: string;
                    type: string;
                    submitAction: string;
                    order: number;
                    stateKey?: undefined;
                } | {
                    id: string;
                    type: string;
                    order: number;
                    stateKey?: undefined;
                    submitAction?: undefined;
                })[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: any[];
                order: number;
                moleculeRefs: ({
                    id: string;
                    type: string;
                    stateKey: string;
                    order: number;
                    submitAction?: undefined;
                } | {
                    id: string;
                    type: string;
                    submitAction: string;
                    order: number;
                    stateKey?: undefined;
                } | {
                    id: string;
                    type: string;
                    order: number;
                    stateKey?: undefined;
                    submitAction?: undefined;
                })[];
            })[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    molecules: ({
                        id: string;
                        type: string;
                        order: number;
                        titleKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        binding?: undefined;
                        submitAction?: undefined;
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        titleKey: string;
                        binding: string;
                        submitAction: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                            source?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        displayHint?: undefined;
                        stateKey?: undefined;
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        titleKey: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        displayHint?: undefined;
                        stateKey?: undefined;
                        binding?: undefined;
                        submitAction?: undefined;
                    })[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: any[];
                    order: number;
                    molecules: ({
                        id: string;
                        type: string;
                        order: number;
                        titleKey: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        binding?: undefined;
                        submitAction?: undefined;
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        titleKey: string;
                        binding: string;
                        submitAction: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                            source?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            source?: undefined;
                            format?: undefined;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        emptyKey?: undefined;
                        stateKey?: undefined;
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        titleKey: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        emptyKey?: undefined;
                        stateKey?: undefined;
                        binding?: undefined;
                        submitAction?: undefined;
                    })[];
                })[];
            }[];
        };
        i18n: {
            "section.openDailyShift.title": string;
            "organism.createDailyShift.title": string;
            "organism.recordOpeningCashMovement.title": string;
            "molecule.createDailyShift.timeline.title": string;
            "molecule.createDailyShift.form.title": string;
            "molecule.createDailyShift.actionBar.title": string;
            "molecule.recordOpening.summary.title": string;
            "molecule.recordOpening.summary.empty": string;
            "molecule.recordOpening.form.title": string;
            "molecule.recordOpening.actionBar.title": string;
            "field.shiftDate.label": string;
            "field.status.label": string;
            "field.openedAt.label": string;
            "field.openingCashBalance.label": string;
            "field.dailyShiftId.label": string;
            "field.movementType.label": string;
            "field.amount.label": string;
            "field.reason.label": string;
            "action.createDailyShift.label": string;
            "action.recordOpeningCashMovement.label": string;
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "openDailyShift__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/openDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/openDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/openDailyShift.ts", "_102050_/l2/cafeFlow/web/contracts/openDailyShift.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/recordPayment.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                moleculeRefs: ({
                    id: string;
                    type: string;
                    order: number;
                    stateKey?: undefined;
                    submitAction?: undefined;
                } | {
                    id: string;
                    type: string;
                    stateKey: string;
                    order: number;
                    submitAction?: undefined;
                } | {
                    id: string;
                    type: string;
                    submitAction: string;
                    order: number;
                    stateKey?: undefined;
                })[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    molecules: ({
                        id: string;
                        type: string;
                        order: number;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        titleKey?: undefined;
                        source?: undefined;
                        binding?: undefined;
                        emptyKey?: undefined;
                        displayHint?: undefined;
                        stateKey?: undefined;
                        submitAction?: undefined;
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        }[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        }[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        submitAction?: undefined;
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        titleKey: string;
                        emptyKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        source?: undefined;
                        binding?: undefined;
                        displayHint?: undefined;
                        stateKey?: undefined;
                        submitAction?: undefined;
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        source?: undefined;
                        binding?: undefined;
                        emptyKey?: undefined;
                        displayHint?: undefined;
                        stateKey?: undefined;
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        titleKey: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        source?: undefined;
                        binding?: undefined;
                        emptyKey?: undefined;
                        displayHint?: undefined;
                        stateKey?: undefined;
                        submitAction?: undefined;
                    })[];
                }[];
            }[];
        };
        i18n: {
            "section.recordPayment.title": string;
            "organism.recordPayment.title": string;
            "molecule.shiftSummary.title": string;
            "molecule.orderSelection.title": string;
            "molecule.orderSummary.title": string;
            "molecule.paymentForm.title": string;
            "molecule.actionBar.title": string;
            "field.shiftDate.label": string;
            "field.dailyShiftStatus.label": string;
            "field.totalSales.label": string;
            "field.totalPayments.label": string;
            "field.orderId.label": string;
            "field.orderType.label": string;
            "field.orderStatus.label": string;
            "field.totalAmount.label": string;
            "field.customerName.label": string;
            "field.method.label": string;
            "field.amount.label": string;
            "field.paymentStatus.label": string;
            "action.recordPayment.label": string;
            "empty.orderList": string;
            "empty.noOrderSelected": string;
        };
        dataBindings: ({
            id: string;
            source: string;
            entity: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
            command?: undefined;
        } | {
            id: string;
            source: string;
            entity: string;
            description: string;
            stateKey: string;
            inputStateKeys?: undefined;
            command?: undefined;
        } | {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        })[];
    };
    export const pipeline: readonly [{
        readonly id: "recordPayment__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/recordPayment.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/recordPayment.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/recordPayment.ts", "_102050_/l2/cafeFlow/web/contracts/recordPayment.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/takeoutOrderLifecycle.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                moleculeRefs: ({
                    id: string;
                    type: string;
                    order: number;
                    stateKey?: undefined;
                } | {
                    id: string;
                    type: string;
                    stateKey: string;
                    order: number;
                })[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    molecules: ({
                        id: string;
                        type: string;
                        order: number;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        binding?: undefined;
                        emptyKey?: undefined;
                        stateKey?: undefined;
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        binding: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        binding?: undefined;
                        emptyKey?: undefined;
                        stateKey?: undefined;
                    })[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    molecules: ({
                        id: string;
                        type: string;
                        order: number;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        displayHint?: undefined;
                        stateKey?: undefined;
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        displayHint?: undefined;
                        stateKey?: undefined;
                    })[];
                })[];
            }[];
        };
        i18n: {
            "section.title": string;
            "organism.createOrder.title": string;
            "organism.addOrderItem.title": string;
            "organism.createKitchenTicket.title": string;
            "organism.updateOrderStatus.title": string;
            "field.orderType": string;
            "field.customerName": string;
            "field.customerPhone": string;
            "field.numberOfGuests": string;
            "field.notes": string;
            "field.menuItemId": string;
            "field.quantity": string;
            "field.observations": string;
            "field.unitPrice": string;
            "field.totalPrice": string;
            "field.itemStatus": string;
            "field.orderId": string;
            "field.kitchenTicketStatus": string;
            "field.status": string;
            "field.cancellationReason": string;
            "action.createOrder": string;
            "action.addOrderItem": string;
            "action.createKitchenTicket": string;
            "action.updateOrderStatus": string;
            "empty.orderItems": string;
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "takeoutOrderLifecycle__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/takeoutOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/takeoutOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/takeoutOrderLifecycle.ts", "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/desktop/page11/viewOperationalDashboard.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                moleculeRefs: {
                    id: string;
                    type: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    molecules: ({
                        id: string;
                        type: string;
                        order: number;
                        fields: any[];
                        columns: any[];
                        filters: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                            source?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        })[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                        source?: undefined;
                        emptyKey?: undefined;
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                        source?: undefined;
                        emptyKey?: undefined;
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        source: string;
                        emptyKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                    } | {
                        id: string;
                        type: string;
                        order: number;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                        source?: undefined;
                        emptyKey?: undefined;
                    })[];
                }[];
            }[];
        };
        i18n: {
            "page.viewOperationalDashboard.title": string;
            "organism.viewOperationalDashboard.title": string;
            "filter.shiftDate.label": string;
            "filter.status.label": string;
            "field.shiftDate.label": string;
            "field.status.label": string;
            "field.openedAt.label": string;
            "field.closedAt.label": string;
            "field.openingCashBalance.label": string;
            "field.closingCashBalance.label": string;
            "field.totalSales.label": string;
            "field.totalPayments.label": string;
            "column.orderId.label": string;
            "column.orderType.label": string;
            "column.orderStatus.label": string;
            "column.totalAmount.label": string;
            "column.customerName.label": string;
            "column.orderCreatedAt.label": string;
            "column.paymentId.label": string;
            "column.paymentMethod.label": string;
            "column.paymentAmount.label": string;
            "column.paymentStatus.label": string;
            "column.paymentCreatedAt.label": string;
            "column.cashMovementId.label": string;
            "column.movementType.label": string;
            "column.movementAmount.label": string;
            "column.movementReason.label": string;
            "column.movementCreatedAt.label": string;
            "empty.orders": string;
            "empty.payments": string;
            "empty.cashMovements": string;
            "action.refreshDashboard.label": string;
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "viewOperationalDashboard__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102050_/l2/cafeFlow/web/desktop/page11/viewOperationalDashboard.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/desktop/page11/viewOperationalDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/shared/viewOperationalDashboard.ts", "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, low-latency, status-driven UI";
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/aiPromotionSuggestions.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        navigationRefs: any[];
        i18n: {
            "section.aiPromotionSuggestions.title": string;
            "organism.aiPromotionSuggestions.title": string;
            "molecule.actionBar.title": string;
            "action.aiPromotionSuggestions.label": string;
            "molecule.table.title": string;
            "table.aiPromotionSuggestions.empty": string;
            "column.id": string;
            "column.orderId": string;
            "column.menuItemId": string;
            "column.kitchenTicketId": string;
            "column.quantity": string;
            "column.unitPrice": string;
            "column.totalPrice": string;
            "column.observations": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "aiPromotionSuggestions__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/aiPromotionSuggestions.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/aiPromotionSuggestions.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.defs.ts", "_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.ts", "_102050_/l2/cafeFlow/web/desktop/page11/aiPromotionSuggestions.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "ingredientConsumptionTrigger"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/aiSalesSummary.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        navigationRefs: any[];
        i18n: {
            "page.aiSalesSummary.title": string;
            "organism.aiSalesSummary.title": string;
            "field.dailyShiftId.label": string;
            "field.status.label": string;
            "field.closedAt.label": string;
            "field.totalAmount.label": string;
            "action.aiSalesSummary.run": string;
            "summary.aiSalesSummary.empty": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "aiSalesSummary__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/aiSalesSummary.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/aiSalesSummary.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.defs.ts", "_102050_/l2/cafeFlow/web/contracts/aiSalesSummary.ts", "_102050_/l2/cafeFlow/web/desktop/page11/aiSalesSummary.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["aiOutputLanguageSelection", "orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "tableOccupancyConsistency"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/browseMenuForPos.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        navigationRefs: any[];
        i18n: {
            "section.browseMenu.title": string;
            "organism.filters.title": string;
            "organism.results.title": string;
            "field.menuCategoryId": string;
            "field.name": string;
            "field.status": string;
            "column.name": string;
            "column.description": string;
            "column.price": string;
            "column.status": string;
            "column.menuCategoryId": string;
            "action.browseMenuForPos": string;
            "action.refresh": string;
            "table.empty": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "browseMenuForPos__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/browseMenuForPos.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/browseMenuForPos.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.defs.ts", "_102050_/l2/cafeFlow/web/contracts/browseMenuForPos.ts", "_102050_/l2/cafeFlow/web/desktop/page11/browseMenuForPos.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/closeDailyShift.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "closeDailyShift.section.title": string;
            "closeDailyShift.org.updateDailyShiftStatus.title": string;
            "closeDailyShift.org.recordClosingCashMovement.title": string;
            "closeDailyShift.field.shiftDate": string;
            "closeDailyShift.field.status": string;
            "closeDailyShift.field.openedAt": string;
            "closeDailyShift.field.openingCashBalance": string;
            "closeDailyShift.field.closingCashBalance": string;
            "closeDailyShift.field.totalSales": string;
            "closeDailyShift.field.totalPayments": string;
            "closeDailyShift.field.closingNotes": string;
            "closeDailyShift.field.closedAt": string;
            "closeDailyShift.action.updateDailyShiftStatus": string;
            "closeDailyShift.action.recordClosingCashMovement": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "closeDailyShift__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/closeDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/closeDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/closeDailyShift.defs.ts", "_102050_/l2/cafeFlow/web/contracts/closeDailyShift.ts", "_102050_/l2/cafeFlow/web/desktop/page11/closeDailyShift.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/consumeIngredientsOnConfirmation.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "page.consumeIngredientsOnConfirmation.title": string;
            "organism.orderSummary.title": string;
            "organism.orderItemsReview.title": string;
            "organism.recipeComponentsPreview.title": string;
            "organism.createStockConsumption.title": string;
            "field.order.orderId": string;
            "field.order.orderType": string;
            "field.order.status": string;
            "field.order.totalAmount": string;
            "field.order.customerName": string;
            "field.order.numberOfGuests": string;
            "field.order.createdAt": string;
            "column.orderItem.id": string;
            "column.orderItem.menuItemName": string;
            "column.orderItem.quantity": string;
            "column.orderItem.unitPrice": string;
            "column.orderItem.totalPrice": string;
            "column.orderItem.status": string;
            "column.recipe.inventoryItemName": string;
            "column.recipe.unit": string;
            "column.recipe.quantityPerUnit": string;
            "column.recipe.currentStock": string;
            "column.recipe.minimumLevel": string;
            "field.stockConsumption.quantity": string;
            "field.stockConsumption.status": string;
            "field.stockConsumption.consumedAt": string;
            "action.createStockConsumption.label": string;
            "empty.orderItems.noData": string;
            "empty.recipeComponents.noData": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "consumeIngredientsOnConfirmation__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/consumeIngredientsOnConfirmation.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/consumeIngredientsOnConfirmation.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.defs.ts", "_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.ts", "_102050_/l2/cafeFlow/web/desktop/page11/consumeIngredientsOnConfirmation.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["ingredientConsumptionTrigger"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/dineInOrderLifecycle.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "section.dineInLifecycle.title": string;
            "organism.createOrder.title": string;
            "organism.addOrderItem.title": string;
            "organism.createKitchenTicket.title": string;
            "organism.updateOrderStatus.title": string;
            "organism.updateTableStatus.title": string;
            "field.orderType.label": string;
            "field.tableId.label": string;
            "field.numberOfGuests.label": string;
            "field.customerName.label": string;
            "field.customerPhone.label": string;
            "field.notes.label": string;
            "field.totalAmount.label": string;
            "field.orderStatus.label": string;
            "field.menuItemId.label": string;
            "field.quantity.label": string;
            "field.unitPrice.label": string;
            "field.totalPrice.label": string;
            "field.observations.label": string;
            "field.itemStatus.label": string;
            "field.orderId.label": string;
            "field.kitchenTicketStatus.label": string;
            "field.updateStatus.label": string;
            "field.cancellationReason.label": string;
            "field.tableStatus.label": string;
            "column.menuItemId.label": string;
            "column.quantity.label": string;
            "column.unitPrice.label": string;
            "column.totalPrice.label": string;
            "column.observations.label": string;
            "column.itemStatus.label": string;
            "action.createOrder.label": string;
            "action.addOrderItem.label": string;
            "action.createKitchenTicket.label": string;
            "action.updateOrderStatus.label": string;
            "action.cancelOrder.label": string;
            "action.updateTableStatus.label": string;
            "empty.orderItems": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "dineInOrderLifecycle__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/dineInOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/dineInOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.defs.ts", "_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.ts", "_102050_/l2/cafeFlow/web/desktop/page11/dineInOrderLifecycle.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "aiOutputLanguageSelection", "tableOccupancyConsistency"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/generateShiftCloseReport.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        navigationRefs: any[];
        i18n: {
            "page.title": string;
            "section.filters.title": string;
            "section.report.title": string;
            "organism.shiftFilter.title": string;
            "organism.shiftCloseReport.title": string;
            "molecule.filterForm.title": string;
            "molecule.summaryPanel.title": string;
            "field.status.label": string;
            "field.openedAt.label": string;
            "field.closedAt.label": string;
            "field.openingCashBalance.label": string;
            "field.closingCashBalance.label": string;
            "field.totalSales.label": string;
            "field.totalPayments.label": string;
            "field.closingNotes.label": string;
            "action.generateShiftCloseReport.label": string;
            "empty.report": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "generateShiftCloseReport__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/generateShiftCloseReport.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/generateShiftCloseReport.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.defs.ts", "_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.ts", "_102050_/l2/cafeFlow/web/desktop/page11/generateShiftCloseReport.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/kitchenProductionFlow.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        navigationRefs: any[];
        i18n: {
            "section.kitchenProductionFlow.title": string;
            "organism.viewKitchenTickets.title": string;
            "organism.updateKitchenTicketStatus.title": string;
            "organism.updateOrderItemStatus.title": string;
            "filter.status.label": string;
            "filter.orderId.label": string;
            "action.applyFilters.label": string;
            "column.kitchenTicketId.label": string;
            "column.orderId.label": string;
            "column.status.label": string;
            "column.createdAt.label": string;
            "column.updatedAt.label": string;
            "toolbar.refresh.label": string;
            "rowAction.selectTicket.label": string;
            "empty.tickets.label": string;
            "field.kitchenTicketId.label": string;
            "field.orderId.label": string;
            "field.status.label": string;
            "field.createdAt.label": string;
            "empty.selectedTicket.label": string;
            "action.startPreparation.label": string;
            "action.finishPreparation.label": string;
            "action.cancelTicket.label": string;
            "column.itemId.label": string;
            "column.menuItemId.label": string;
            "column.quantity.label": string;
            "column.observations.label": string;
            "column.itemStatus.label": string;
            "column.itemUpdatedAt.label": string;
            "rowAction.selectItem.label": string;
            "empty.orderItems.label": string;
            "action.markInPreparation.label": string;
            "action.markReady.label": string;
            "action.markServed.label": string;
            "action.cancelItem.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "kitchenProductionFlow__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/kitchenProductionFlow.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/kitchenProductionFlow.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.defs.ts", "_102050_/l2/cafeFlow/web/contracts/kitchenProductionFlow.ts", "_102050_/l2/cafeFlow/web/desktop/page11/kitchenProductionFlow.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "ingredientConsumptionTrigger"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/manageInventoryItems.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "page.manageInventoryItems.title": string;
            "organism.manageInventoryItems.title": string;
            "filter.name.label": string;
            "filter.status.label": string;
            "column.name.label": string;
            "column.unit.label": string;
            "column.currentQuantity.label": string;
            "column.minimumLevel.label": string;
            "column.status.label": string;
            "column.updatedAt.label": string;
            "toolbar.new.label": string;
            "toolbar.refresh.label": string;
            "rowAction.edit.label": string;
            "rowAction.deactivate.label": string;
            "summary.totalItems.label": string;
            "summary.lowStockItems.label": string;
            "summary.activeItems.label": string;
            "field.name.label": string;
            "field.description.label": string;
            "field.unit.label": string;
            "field.currentQuantity.label": string;
            "field.minimumLevel.label": string;
            "field.status.label": string;
            "action.save.label": string;
            "action.cancel.label": string;
            "table.empty": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "manageInventoryItems__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/manageInventoryItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/manageInventoryItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.defs.ts", "_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.ts", "_102050_/l2/cafeFlow/web/desktop/page11/manageInventoryItems.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["inventoryLowStockThreshold", "ingredientConsumptionTrigger"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/manageMenuCategories.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "page.manageMenuCategories.title": string;
            "organism.manageMenuCategories.title": string;
            "molecule.categoriesTable.title": string;
            "molecule.categoriesTable.empty": string;
            "molecule.categoryForm.title": string;
            "molecule.summaryPanel.title": string;
            "field.menuCategory.menuCategoryId": string;
            "field.menuCategory.name": string;
            "field.menuCategory.description": string;
            "field.menuCategory.status": string;
            "field.menuCategory.createdAt": string;
            "field.menuCategory.updatedAt": string;
            "filter.menuCategory.status": string;
            "filter.menuCategory.name": string;
            "action.manageMenuCategories.new": string;
            "action.manageMenuCategories.edit": string;
            "action.manageMenuCategories.toggleStatus": string;
            "action.manageMenuCategories.delete": string;
            "action.manageMenuCategories.save": string;
            "action.manageMenuCategories.cancel": string;
            "summary.menuCategory.total": string;
            "summary.menuCategory.active": string;
            "summary.menuCategory.inactive": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "manageMenuCategories__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/manageMenuCategories.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/manageMenuCategories.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.defs.ts", "_102050_/l2/cafeFlow/web/contracts/manageMenuCategories.ts", "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuCategories.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/manageMenuItems.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "section.manageMenuItems.title": string;
            "organism.menuItemsList.title": string;
            "organism.menuItemForm.title": string;
            "filter.name.label": string;
            "filter.status.label": string;
            "filter.menuCategoryId.label": string;
            "column.name.label": string;
            "column.menuCategoryId.label": string;
            "column.price.label": string;
            "column.status.label": string;
            "column.updatedAt.label": string;
            "toolbar.new.label": string;
            "rowAction.edit.label": string;
            "rowAction.deactivate.label": string;
            "empty.menuItemsTable": string;
            "field.menuItemId.label": string;
            "field.menuCategoryId.label": string;
            "field.name.label": string;
            "field.description.label": string;
            "field.price.label": string;
            "field.status.label": string;
            "action.save.label": string;
            "action.cancel.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "manageMenuItems__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/manageMenuItems.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/manageMenuItems.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/manageMenuItems.defs.ts", "_102050_/l2/cafeFlow/web/contracts/manageMenuItems.ts", "_102050_/l2/cafeFlow/web/desktop/page11/manageMenuItems.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/manageTables.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "page.manageTables.section.title": string;
            "page.manageTables.organism.tableList.title": string;
            "page.manageTables.organism.form.title": string;
            "page.manageTables.filter.status": string;
            "page.manageTables.column.number": string;
            "page.manageTables.column.status": string;
            "page.manageTables.column.createdAt": string;
            "page.manageTables.column.updatedAt": string;
            "page.manageTables.toolbar.newTable": string;
            "page.manageTables.rowAction.edit": string;
            "page.manageTables.rowAction.delete": string;
            "page.manageTables.table.empty": string;
            "page.manageTables.field.tableId": string;
            "page.manageTables.field.number": string;
            "page.manageTables.field.status": string;
            "page.manageTables.action.save": string;
            "page.manageTables.action.cancel": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "manageTables__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/manageTables.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/manageTables.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/manageTables.defs.ts", "_102050_/l2/cafeFlow/web/contracts/manageTables.ts", "_102050_/l2/cafeFlow/web/desktop/page11/manageTables.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["tableOccupancyConsistency"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/openDailyShift.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "section.openDailyShift.title": string;
            "organism.createDailyShift.title": string;
            "organism.recordOpeningCashMovement.title": string;
            "molecule.createDailyShift.timeline.title": string;
            "molecule.createDailyShift.form.title": string;
            "molecule.createDailyShift.actionBar.title": string;
            "molecule.recordOpening.summary.title": string;
            "molecule.recordOpening.summary.empty": string;
            "molecule.recordOpening.form.title": string;
            "molecule.recordOpening.actionBar.title": string;
            "field.shiftDate.label": string;
            "field.status.label": string;
            "field.openedAt.label": string;
            "field.openingCashBalance.label": string;
            "field.dailyShiftId.label": string;
            "field.movementType.label": string;
            "field.amount.label": string;
            "field.reason.label": string;
            "action.createDailyShift.label": string;
            "action.recordOpeningCashMovement.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "openDailyShift__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/openDailyShift.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/openDailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/openDailyShift.defs.ts", "_102050_/l2/cafeFlow/web/contracts/openDailyShift.ts", "_102050_/l2/cafeFlow/web/desktop/page11/openDailyShift.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/recordPayment.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "section.recordPayment.title": string;
            "organism.recordPayment.title": string;
            "molecule.shiftSummary.title": string;
            "molecule.orderSelection.title": string;
            "molecule.orderSummary.title": string;
            "molecule.paymentForm.title": string;
            "molecule.actionBar.title": string;
            "field.shiftDate.label": string;
            "field.dailyShiftStatus.label": string;
            "field.totalSales.label": string;
            "field.totalPayments.label": string;
            "field.orderId.label": string;
            "field.orderType.label": string;
            "field.orderStatus.label": string;
            "field.totalAmount.label": string;
            "field.customerName.label": string;
            "field.method.label": string;
            "field.amount.label": string;
            "field.paymentStatus.label": string;
            "action.recordPayment.label": string;
            "empty.orderList": string;
            "empty.noOrderSelected": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "recordPayment__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/recordPayment.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/recordPayment.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/recordPayment.defs.ts", "_102050_/l2/cafeFlow/web/contracts/recordPayment.ts", "_102050_/l2/cafeFlow/web/desktop/page11/recordPayment.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/takeoutOrderLifecycle.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18n: {
            "section.title": string;
            "organism.createOrder.title": string;
            "organism.addOrderItem.title": string;
            "organism.createKitchenTicket.title": string;
            "organism.updateOrderStatus.title": string;
            "field.orderType": string;
            "field.customerName": string;
            "field.customerPhone": string;
            "field.numberOfGuests": string;
            "field.notes": string;
            "field.menuItemId": string;
            "field.quantity": string;
            "field.observations": string;
            "field.unitPrice": string;
            "field.totalPrice": string;
            "field.itemStatus": string;
            "field.orderId": string;
            "field.kitchenTicketStatus": string;
            "field.status": string;
            "field.cancellationReason": string;
            "action.createOrder": string;
            "action.addOrderItem": string;
            "action.createKitchenTicket": string;
            "action.updateOrderStatus": string;
            "empty.orderItems": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "takeoutOrderLifecycle__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/takeoutOrderLifecycle.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/takeoutOrderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.defs.ts", "_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.ts", "_102050_/l2/cafeFlow/web/desktop/page11/takeoutOrderLifecycle.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["orderStatusTransitions", "paymentTimingByOrderType", "ingredientConsumptionTrigger", "aiOutputLanguageSelection", "tableOccupancyConsistency"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102050_/l2/cafeFlow/web/shared/viewOperationalDashboard.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        navigationRefs: any[];
        i18n: {
            "page.viewOperationalDashboard.title": string;
            "organism.viewOperationalDashboard.title": string;
            "filter.shiftDate.label": string;
            "filter.status.label": string;
            "field.shiftDate.label": string;
            "field.status.label": string;
            "field.openedAt.label": string;
            "field.closedAt.label": string;
            "field.openingCashBalance.label": string;
            "field.closingCashBalance.label": string;
            "field.totalSales.label": string;
            "field.totalPayments.label": string;
            "column.orderId.label": string;
            "column.orderType.label": string;
            "column.orderStatus.label": string;
            "column.totalAmount.label": string;
            "column.customerName.label": string;
            "column.orderCreatedAt.label": string;
            "column.paymentId.label": string;
            "column.paymentMethod.label": string;
            "column.paymentAmount.label": string;
            "column.paymentStatus.label": string;
            "column.paymentCreatedAt.label": string;
            "column.cashMovementId.label": string;
            "column.movementType.label": string;
            "column.movementAmount.label": string;
            "column.movementReason.label": string;
            "column.movementCreatedAt.label": string;
            "empty.orders": string;
            "empty.payments": string;
            "empty.cashMovements": string;
            "action.refreshDashboard.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "viewOperationalDashboard__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102050_/l2/cafeFlow/web/shared/viewOperationalDashboard.ts";
        readonly defPath: "_102050_/l2/cafeFlow/web/shared/viewOperationalDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.defs.ts", "_102050_/l2/cafeFlow/web/contracts/viewOperationalDashboard.ts", "_102050_/l2/cafeFlow/web/desktop/page11/viewOperationalDashboard.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesApplied: readonly ["paymentTimingByOrderType", "aiOutputLanguageSelection"];
        readonly agent: "agentMaterializeGen";
    }];
}
