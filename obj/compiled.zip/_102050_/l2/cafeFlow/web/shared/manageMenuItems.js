/// <mls fileReference="_102050_/l2/cafeFlow/web/shared/manageMenuItems.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "manageMenuItems.section.title": "Gerenciar itens do cardápio",
    "manageMenuItems.organism.title": "Gerenciar itens do cardápio",
    "manageMenuItems.form.title": "Detalhes do item",
    "manageMenuItems.field.menuItemId": "ID do item",
    "manageMenuItems.field.menuCategoryId": "Categoria",
    "manageMenuItems.field.name": "Nome",
    "manageMenuItems.field.description": "Descrição",
    "manageMenuItems.field.price": "Preço",
    "manageMenuItems.field.status": "Status",
    "manageMenuItems.status.draft": "Rascunho",
    "manageMenuItems.status.active": "Ativo",
    "manageMenuItems.status.inactive": "Inativo",
    "manageMenuItems.action.submit": "Salvar alterações"
};
const message_en = {
    "manageMenuItems.section.title": "Manage menu items",
    "manageMenuItems.organism.title": "Manage menu items",
    "manageMenuItems.form.title": "Item details",
    "manageMenuItems.field.menuItemId": "Item ID",
    "manageMenuItems.field.menuCategoryId": "Category",
    "manageMenuItems.field.name": "Name",
    "manageMenuItems.field.description": "Description",
    "manageMenuItems.field.price": "Price",
    "manageMenuItems.field.status": "Status",
    "manageMenuItems.status.draft": "Draft",
    "manageMenuItems.status.active": "Active",
    "manageMenuItems.status.inactive": "Inactive",
    "manageMenuItems.action.submit": "Save changes"
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowManageMenuItemsBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.manageMenuItemsState = 'idle';
        this.manageMenuItemsMenuItemId = '';
        this.manageMenuItemsMenuCategoryId = '';
        this.manageMenuItemsName = '';
        this.manageMenuItemsDescription = '';
        this.manageMenuItemsPrice = '';
        this.manageMenuItemsStatus = '';
        this.stateKeys = [
            'ui.manageMenuItems.status',
            'ui.manageMenuItems.action.manageMenuItems.status',
            'ui.manageMenuItems.input.manageMenuItems.menuItemId',
            'ui.manageMenuItems.input.manageMenuItems.menuCategoryId',
            'ui.manageMenuItems.input.manageMenuItems.name',
            'ui.manageMenuItems.input.manageMenuItems.description',
            'ui.manageMenuItems.input.manageMenuItems.price',
            'ui.manageMenuItems.input.manageMenuItems.status'
        ];
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || messages['en'];
    }
    connectedCallback() {
        super.connectedCallback();
        const storedStatus = getState('ui.manageMenuItems.status');
        if (storedStatus !== undefined) {
            this.status = storedStatus;
        }
        const storedManageMenuItemsState = getState('ui.manageMenuItems.action.manageMenuItems.status');
        if (storedManageMenuItemsState !== undefined) {
            this.manageMenuItemsState = storedManageMenuItemsState;
        }
        const storedMenuItemId = getState('ui.manageMenuItems.input.manageMenuItems.menuItemId');
        if (storedMenuItemId !== undefined) {
            this.manageMenuItemsMenuItemId = storedMenuItemId;
        }
        const storedMenuCategoryId = getState('ui.manageMenuItems.input.manageMenuItems.menuCategoryId');
        if (storedMenuCategoryId !== undefined) {
            this.manageMenuItemsMenuCategoryId = storedMenuCategoryId;
        }
        const storedName = getState('ui.manageMenuItems.input.manageMenuItems.name');
        if (storedName !== undefined) {
            this.manageMenuItemsName = storedName;
        }
        const storedDescription = getState('ui.manageMenuItems.input.manageMenuItems.description');
        if (storedDescription !== undefined) {
            this.manageMenuItemsDescription = storedDescription;
        }
        const storedPrice = getState('ui.manageMenuItems.input.manageMenuItems.price');
        if (storedPrice !== undefined) {
            this.manageMenuItemsPrice = storedPrice;
        }
        const storedStatusValue = getState('ui.manageMenuItems.input.manageMenuItems.status');
        if (storedStatusValue !== undefined) {
            this.manageMenuItemsStatus = storedStatusValue;
        }
        subscribe(this.stateKeys, this);
    }
    disconnectedCallback() {
        unsubscribe(this.stateKeys, this);
        super.disconnectedCallback();
    }
    setManageMenuItemsMenuItemId(value) {
        this.manageMenuItemsMenuItemId = value;
        setState('ui.manageMenuItems.input.manageMenuItems.menuItemId', value);
        this.requestUpdate();
    }
    handleManageMenuItemsMenuItemIdChange(event) {
        const target = event.target;
        this.setManageMenuItemsMenuItemId(target.value);
    }
    setManageMenuItemsMenuCategoryId(value) {
        this.manageMenuItemsMenuCategoryId = value;
        setState('ui.manageMenuItems.input.manageMenuItems.menuCategoryId', value);
        this.requestUpdate();
    }
    handleManageMenuItemsMenuCategoryIdChange(event) {
        const target = event.target;
        this.setManageMenuItemsMenuCategoryId(target.value);
    }
    setManageMenuItemsName(value) {
        this.manageMenuItemsName = value;
        setState('ui.manageMenuItems.input.manageMenuItems.name', value);
        this.requestUpdate();
    }
    handleManageMenuItemsNameChange(event) {
        const target = event.target;
        this.setManageMenuItemsName(target.value);
    }
    setManageMenuItemsDescription(value) {
        this.manageMenuItemsDescription = value;
        setState('ui.manageMenuItems.input.manageMenuItems.description', value);
        this.requestUpdate();
    }
    handleManageMenuItemsDescriptionChange(event) {
        const target = event.target;
        this.setManageMenuItemsDescription(target.value);
    }
    setManageMenuItemsPrice(value) {
        this.manageMenuItemsPrice = value;
        setState('ui.manageMenuItems.input.manageMenuItems.price', value);
        this.requestUpdate();
    }
    handleManageMenuItemsPriceChange(event) {
        const target = event.target;
        const value = Number(target.value);
        this.setManageMenuItemsPrice(value);
    }
    setManageMenuItemsStatus(value) {
        this.manageMenuItemsStatus = value;
        setState('ui.manageMenuItems.input.manageMenuItems.status', value);
        this.requestUpdate();
    }
    handleManageMenuItemsStatusChange(event) {
        const target = event.target;
        this.setManageMenuItemsStatus(target.value);
    }
    async manageMenuItems() {
        this.manageMenuItemsState = 'loading';
        setState('ui.manageMenuItems.action.manageMenuItems.status', 'loading');
        const params = {
            menuItemId: this.manageMenuItemsMenuItemId || undefined,
            menuCategoryId: this.manageMenuItemsMenuCategoryId || undefined,
            name: this.manageMenuItemsName,
            description: this.manageMenuItemsDescription || undefined,
            price: this.manageMenuItemsPrice,
            status: this.manageMenuItemsStatus
        };
        const options = { mode: 'blocking' };
        try {
            const response = await execBff('cafeFlow.manageMenuItems.manageMenuItems', params, options);
            if (!response.ok) {
                this.manageMenuItemsState = 'error';
                setState('ui.manageMenuItems.action.manageMenuItems.status', 'error');
                return;
            }
            this.manageMenuItemsState = 'success';
            setState('ui.manageMenuItems.action.manageMenuItems.status', 'success');
        }
        catch (error) {
            this.manageMenuItemsState = 'error';
            setState('ui.manageMenuItems.action.manageMenuItems.status', 'error');
        }
    }
    async handleManageMenuItemsClick() {
        await runBlockingUiAction(async () => {
            await this.manageMenuItems();
        });
    }
}
__decorate([
    property()
], CafeFlowManageMenuItemsBase.prototype, "status", void 0);
__decorate([
    property()
], CafeFlowManageMenuItemsBase.prototype, "manageMenuItemsState", void 0);
__decorate([
    property()
], CafeFlowManageMenuItemsBase.prototype, "manageMenuItemsMenuItemId", void 0);
__decorate([
    property()
], CafeFlowManageMenuItemsBase.prototype, "manageMenuItemsMenuCategoryId", void 0);
__decorate([
    property()
], CafeFlowManageMenuItemsBase.prototype, "manageMenuItemsName", void 0);
__decorate([
    property()
], CafeFlowManageMenuItemsBase.prototype, "manageMenuItemsDescription", void 0);
__decorate([
    property()
], CafeFlowManageMenuItemsBase.prototype, "manageMenuItemsPrice", void 0);
__decorate([
    property()
], CafeFlowManageMenuItemsBase.prototype, "manageMenuItemsStatus", void 0);
