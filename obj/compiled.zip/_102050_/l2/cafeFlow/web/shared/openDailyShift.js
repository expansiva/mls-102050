/// <mls fileReference="_102050_/l2/cafeFlow/web/shared/openDailyShift.ts" enhancement="_blank"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
const message_pt = {
    'openDailyShift.section.main.title': 'Abrir turno diário',
    'openDailyShift.organism.createDailyShift.title': 'Criar turno diário',
    'openDailyShift.intention.createDailyShift.form.title': 'Command Form',
    'openDailyShift.field.createDailyShift.shiftDate.label': 'Shift Date',
    'openDailyShift.field.createDailyShift.status.label': 'Status',
    'openDailyShift.field.createDailyShift.openedAt.label': 'Opened At',
    'openDailyShift.field.createDailyShift.openingCashBalance.label': 'Opening Cash Balance',
    'openDailyShift.action.createDailyShift.submit.label': 'Create Daily Shift',
    'openDailyShift.organism.recordOpeningCashMovement.title': 'Registrar movimento de caixa de abertura',
    'openDailyShift.intention.recordOpeningCashMovement.form.title': 'Command Form',
    'openDailyShift.field.recordOpeningCashMovement.movementType.label': 'Movement Type',
    'openDailyShift.field.recordOpeningCashMovement.amount.label': 'Amount',
    'openDailyShift.field.recordOpeningCashMovement.reason.label': 'Reason',
    'openDailyShift.action.recordOpeningCashMovement.submit.label': 'Record Opening Cash Movement',
};
const message_en = {
    'openDailyShift.section.main.title': 'Open Daily Shift',
    'openDailyShift.organism.createDailyShift.title': 'Create Daily Shift',
    'openDailyShift.intention.createDailyShift.form.title': 'Command Form',
    'openDailyShift.field.createDailyShift.shiftDate.label': 'Shift Date',
    'openDailyShift.field.createDailyShift.status.label': 'Status',
    'openDailyShift.field.createDailyShift.openedAt.label': 'Opened At',
    'openDailyShift.field.createDailyShift.openingCashBalance.label': 'Opening Cash Balance',
    'openDailyShift.action.createDailyShift.submit.label': 'Create Daily Shift',
    'openDailyShift.organism.recordOpeningCashMovement.title': 'Record Opening Cash Movement',
    'openDailyShift.intention.recordOpeningCashMovement.form.title': 'Command Form',
    'openDailyShift.field.recordOpeningCashMovement.movementType.label': 'Movement Type',
    'openDailyShift.field.recordOpeningCashMovement.amount.label': 'Amount',
    'openDailyShift.field.recordOpeningCashMovement.reason.label': 'Reason',
    'openDailyShift.action.recordOpeningCashMovement.submit.label': 'Record Opening Cash Movement',
};
export class CafeFlowOpenDailyShiftBase extends CollabLitElement {
    constructor() {
        // ── State properties ──────────────────────────────────────────────
        super(...arguments);
        this.status = '';
        this.createDailyShiftState = 'idle';
        this.createDailyShiftShiftDate = '';
        this.createDailyShiftStatus = '';
        this.createDailyShiftOpenedAt = '';
        this.createDailyShiftOpeningCashBalance = '';
        this.recordOpeningCashMovementState = 'idle';
        this.recordOpeningCashMovementMovementType = '';
        this.recordOpeningCashMovementAmount = '';
        this.recordOpeningCashMovementReason = '';
    }
    // ── i18n ──────────────────────────────────────────────────────────
    get msg() {
        const lang = (typeof document !== 'undefined' && document.documentElement?.lang) || 'pt';
        return lang === 'en' ? message_en : message_pt;
    }
    // ── State setters ─────────────────────────────────────────────────
    setCreateDailyShiftShiftDate(value) {
        this.createDailyShiftShiftDate = value;
        setState('ui.openDailyShift.input.createDailyShift.shiftDate', value);
        this.requestUpdate();
    }
    handleCreateDailyShiftShiftDateChange(e) {
        const target = e.target;
        this.setCreateDailyShiftShiftDate(target.value);
    }
    setCreateDailyShiftStatus(value) {
        this.createDailyShiftStatus = value;
        setState('ui.openDailyShift.input.createDailyShift.status', value);
        this.requestUpdate();
    }
    handleCreateDailyShiftStatusChange(e) {
        const target = e.target;
        this.setCreateDailyShiftStatus(target.value);
    }
    setCreateDailyShiftOpenedAt(value) {
        this.createDailyShiftOpenedAt = value;
        setState('ui.openDailyShift.input.createDailyShift.openedAt', value);
        this.requestUpdate();
    }
    handleCreateDailyShiftOpenedAtChange(e) {
        const target = e.target;
        this.setCreateDailyShiftOpenedAt(target.value);
    }
    setCreateDailyShiftOpeningCashBalance(value) {
        this.createDailyShiftOpeningCashBalance = value;
        setState('ui.openDailyShift.input.createDailyShift.openingCashBalance', value);
        this.requestUpdate();
    }
    handleCreateDailyShiftOpeningCashBalanceChange(e) {
        const target = e.target;
        this.setCreateDailyShiftOpeningCashBalance(target.value);
    }
    setRecordOpeningCashMovementMovementType(value) {
        this.recordOpeningCashMovementMovementType = value;
        setState('ui.openDailyShift.input.recordOpeningCashMovement.movementType', value);
        this.requestUpdate();
    }
    handleRecordOpeningCashMovementMovementTypeChange(e) {
        const target = e.target;
        this.setRecordOpeningCashMovementMovementType(target.value);
    }
    setRecordOpeningCashMovementAmount(value) {
        this.recordOpeningCashMovementAmount = value;
        setState('ui.openDailyShift.input.recordOpeningCashMovement.amount', value);
        this.requestUpdate();
    }
    handleRecordOpeningCashMovementAmountChange(e) {
        const target = e.target;
        this.setRecordOpeningCashMovementAmount(target.value);
    }
    setRecordOpeningCashMovementReason(value) {
        this.recordOpeningCashMovementReason = value;
        setState('ui.openDailyShift.input.recordOpeningCashMovement.reason', value);
        this.requestUpdate();
    }
    handleRecordOpeningCashMovementReasonChange(e) {
        const target = e.target;
        this.setRecordOpeningCashMovementReason(target.value);
    }
    // ── Command: createDailyShift ─────────────────────────────────────
    async createDailyShift() {
        this.createDailyShiftState = 'loading';
        setState('ui.openDailyShift.action.createDailyShift.status', 'loading');
        this.requestUpdate();
        const params = {
            shiftDate: this.createDailyShiftShiftDate,
            status: this.createDailyShiftStatus,
            openedAt: this.createDailyShiftOpenedAt,
            openingCashBalance: this.createDailyShiftOpeningCashBalance
                ? Number(this.createDailyShiftOpeningCashBalance)
                : undefined,
        };
        const options = { mode: 'blocking' };
        try {
            const response = await execBff('cafeFlow.openDailyShift.createDailyShift', params, options);
            if (response.ok) {
                this.createDailyShiftState = 'success';
                setState('ui.openDailyShift.action.createDailyShift.status', 'success');
            }
            else {
                this.createDailyShiftState = 'error';
                setState('ui.openDailyShift.action.createDailyShift.status', 'error');
            }
        }
        catch {
            this.createDailyShiftState = 'error';
            setState('ui.openDailyShift.action.createDailyShift.status', 'error');
        }
        this.requestUpdate();
    }
    handleCreateDailyShiftClick() {
        runBlockingUiAction(async () => {
            await this.createDailyShift();
        });
    }
    // ── Command: recordOpeningCashMovement ────────────────────────────
    async recordOpeningCashMovement() {
        this.recordOpeningCashMovementState = 'loading';
        setState('ui.openDailyShift.action.recordOpeningCashMovement.status', 'loading');
        this.requestUpdate();
        const params = {
            movementType: this.recordOpeningCashMovementMovementType,
            amount: Number(this.recordOpeningCashMovementAmount),
            reason: this.recordOpeningCashMovementReason,
        };
        const options = { mode: 'blocking' };
        try {
            const response = await execBff('cafeFlow.openDailyShift.recordOpeningCashMovement', params, options);
            if (response.ok) {
                this.recordOpeningCashMovementState = 'success';
                setState('ui.openDailyShift.action.recordOpeningCashMovement.status', 'success');
            }
            else {
                this.recordOpeningCashMovementState = 'error';
                setState('ui.openDailyShift.action.recordOpeningCashMovement.status', 'error');
            }
        }
        catch {
            this.recordOpeningCashMovementState = 'error';
            setState('ui.openDailyShift.action.recordOpeningCashMovement.status', 'error');
        }
        this.requestUpdate();
    }
    handleRecordOpeningCashMovementClick() {
        runBlockingUiAction(async () => {
            await this.recordOpeningCashMovement();
        });
    }
    // ── Lifecycle ─────────────────────────────────────────────────────
    connectedCallback() {
        super.connectedCallback();
        // Restore shared state if available, otherwise keep defaults
        this.status = getState('ui.openDailyShift.status') ?? this.status;
        this.createDailyShiftState =
            getState('ui.openDailyShift.action.createDailyShift.status') ??
                this.createDailyShiftState;
        this.createDailyShiftShiftDate =
            getState('ui.openDailyShift.input.createDailyShift.shiftDate') ??
                this.createDailyShiftShiftDate;
        this.createDailyShiftStatus =
            getState('ui.openDailyShift.input.createDailyShift.status') ??
                this.createDailyShiftStatus;
        this.createDailyShiftOpenedAt =
            getState('ui.openDailyShift.input.createDailyShift.openedAt') ??
                this.createDailyShiftOpenedAt;
        this.createDailyShiftOpeningCashBalance =
            getState('ui.openDailyShift.input.createDailyShift.openingCashBalance') ??
                this.createDailyShiftOpeningCashBalance;
        this.recordOpeningCashMovementState =
            getState('ui.openDailyShift.action.recordOpeningCashMovement.status') ??
                this.recordOpeningCashMovementState;
        this.recordOpeningCashMovementMovementType =
            getState('ui.openDailyShift.input.recordOpeningCashMovement.movementType') ??
                this.recordOpeningCashMovementMovementType;
        this.recordOpeningCashMovementAmount =
            getState('ui.openDailyShift.input.recordOpeningCashMovement.amount') ??
                this.recordOpeningCashMovementAmount;
        this.recordOpeningCashMovementReason =
            getState('ui.openDailyShift.input.recordOpeningCashMovement.reason') ??
                this.recordOpeningCashMovementReason;
        // No initialLoads defined for this page
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
}
__decorate([
    property({ type: String })
], CafeFlowOpenDailyShiftBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowOpenDailyShiftBase.prototype, "createDailyShiftState", void 0);
__decorate([
    property({ type: String })
], CafeFlowOpenDailyShiftBase.prototype, "createDailyShiftShiftDate", void 0);
__decorate([
    property({ type: String })
], CafeFlowOpenDailyShiftBase.prototype, "createDailyShiftStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowOpenDailyShiftBase.prototype, "createDailyShiftOpenedAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowOpenDailyShiftBase.prototype, "createDailyShiftOpeningCashBalance", void 0);
__decorate([
    property({ type: String })
], CafeFlowOpenDailyShiftBase.prototype, "recordOpeningCashMovementState", void 0);
__decorate([
    property({ type: String })
], CafeFlowOpenDailyShiftBase.prototype, "recordOpeningCashMovementMovementType", void 0);
__decorate([
    property({ type: String })
], CafeFlowOpenDailyShiftBase.prototype, "recordOpeningCashMovementAmount", void 0);
__decorate([
    property({ type: String })
], CafeFlowOpenDailyShiftBase.prototype, "recordOpeningCashMovementReason", void 0);
