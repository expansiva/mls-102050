/// <mls fileReference="_102050_/l2/cafeFlow/web/shared/recordPayment.ts" enhancement="_blank"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
const message_pt = {
    'recordPayment.section.title': 'Registrar pagamento/recebimento',
    'recordPayment.organism.title': 'Registrar pagamento/recebimento',
    'recordPayment.form.title': 'Command Form',
    'recordPayment.field.method': 'Method',
    'recordPayment.field.amount': 'Amount',
    'recordPayment.field.status': 'Status',
    'recordPayment.action.submit': 'Record Payment',
};
const message_en = {
    'recordPayment.section.title': 'Register payment/receipt',
    'recordPayment.organism.title': 'Register payment/receipt',
    'recordPayment.form.title': 'Command Form',
    'recordPayment.field.method': 'Method',
    'recordPayment.field.amount': 'Amount',
    'recordPayment.field.status': 'Status',
    'recordPayment.action.submit': 'Record Payment',
};
export class CafeFlowRecordPaymentBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.recordPaymentState = 'idle';
        this.recordPaymentMethod = '';
        this.recordPaymentAmount = '';
        this.recordPaymentStatus = '';
    }
    get msg() {
        const lang = this.__lang ?? 'pt';
        return lang === 'en' ? message_en : message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        this.status = getState('ui.recordPayment.status') ?? '';
        this.recordPaymentState = getState('ui.recordPayment.action.recordPayment.status') ?? 'idle';
        this.recordPaymentMethod = getState('ui.recordPayment.input.recordPayment.method') ?? '';
        this.recordPaymentAmount = getState('ui.recordPayment.input.recordPayment.amount') ?? '';
        this.recordPaymentStatus = getState('ui.recordPayment.input.recordPayment.status') ?? '';
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
    // --- State setters ---
    setRecordPaymentMethod(value) {
        this.recordPaymentMethod = value;
        setState('ui.recordPayment.input.recordPayment.method', value);
        this.requestUpdate();
    }
    handleRecordPaymentMethodChange(e) {
        const target = e.target;
        this.setRecordPaymentMethod(target.value);
    }
    setRecordPaymentAmount(value) {
        this.recordPaymentAmount = value;
        setState('ui.recordPayment.input.recordPayment.amount', value);
        this.requestUpdate();
    }
    handleRecordPaymentAmountChange(e) {
        const target = e.target;
        this.setRecordPaymentAmount(target.value);
    }
    setRecordPaymentStatus(value) {
        this.recordPaymentStatus = value;
        setState('ui.recordPayment.input.recordPayment.status', value);
        this.requestUpdate();
    }
    handleRecordPaymentStatusChange(e) {
        const target = e.target;
        this.setRecordPaymentStatus(target.value);
    }
    // --- Command action: recordPayment ---
    async recordPayment() {
        this.recordPaymentState = 'loading';
        setState('ui.recordPayment.action.recordPayment.status', 'loading');
        this.requestUpdate();
        const params = {
            method: this.recordPaymentMethod,
            amount: Number(this.recordPaymentAmount) || 0,
            status: this.recordPaymentStatus,
        };
        const options = { mode: 'blocking' };
        try {
            const response = await execBff('cafeFlow.recordPayment.recordPayment', params, options);
            if (response.ok) {
                this.recordPaymentState = 'success';
                setState('ui.recordPayment.action.recordPayment.status', 'success');
            }
            else {
                this.recordPaymentState = 'error';
                setState('ui.recordPayment.action.recordPayment.status', 'error');
            }
        }
        catch {
            this.recordPaymentState = 'error';
            setState('ui.recordPayment.action.recordPayment.status', 'error');
        }
        this.requestUpdate();
    }
    handleRecordPaymentClick(e) {
        e.preventDefault();
        runBlockingUiAction(async () => {
            await this.recordPayment();
        });
    }
}
__decorate([
    property({ type: String })
], CafeFlowRecordPaymentBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowRecordPaymentBase.prototype, "recordPaymentState", void 0);
__decorate([
    property({ type: String })
], CafeFlowRecordPaymentBase.prototype, "recordPaymentMethod", void 0);
__decorate([
    property({ type: String })
], CafeFlowRecordPaymentBase.prototype, "recordPaymentAmount", void 0);
__decorate([
    property({ type: String })
], CafeFlowRecordPaymentBase.prototype, "recordPaymentStatus", void 0);
