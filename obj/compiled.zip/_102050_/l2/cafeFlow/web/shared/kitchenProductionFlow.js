/// <mls fileReference="_102050_/l2/cafeFlow/web/shared/kitchenProductionFlow.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "kitchenProductionFlow.section.main.title": "Fluxo de produção da cozinha",
    "kitchenProductionFlow.organism.viewKitchenTickets.title": "Consultar tickets da cozinha",
    "kitchenProductionFlow.intention.viewKitchenTickets.list.title": "Query List",
    "kitchenProductionFlow.field.kitchenTicketId": "Kitchen Ticket Id",
    "kitchenProductionFlow.field.orderId": "Order Id",
    "kitchenProductionFlow.field.status": "Status",
    "kitchenProductionFlow.field.createdAt": "Created At",
    "kitchenProductionFlow.field.updatedAt": "Updated At",
    "kitchenProductionFlow.filter.kitchenTicketId": "Kitchen Ticket Id",
    "kitchenProductionFlow.filter.orderId": "Order Id",
    "kitchenProductionFlow.filter.status": "Status",
    "kitchenProductionFlow.filter.createdAt": "Created At",
    "kitchenProductionFlow.filter.updatedAt": "Updated At",
    "kitchenProductionFlow.action.viewKitchenTickets": "View Kitchen Tickets",
    "kitchenProductionFlow.organism.updateKitchenTicketStatus.title": "Atualizar status do ticket de cozinha",
    "kitchenProductionFlow.intention.updateKitchenTicketStatus.form.title": "Command Form",
    "kitchenProductionFlow.field.kitchenTicket.status": "Status",
    "kitchenProductionFlow.action.updateKitchenTicketStatus": "Update Kitchen Ticket Status",
    "kitchenProductionFlow.organism.updateOrderItemStatus.title": "Atualizar status de item do pedido",
    "kitchenProductionFlow.intention.updateOrderItemStatus.form.title": "Command Form",
    "kitchenProductionFlow.field.orderItem.status": "Status",
    "kitchenProductionFlow.action.updateOrderItemStatus": "Update Order Item Status",
    "kitchenProductionFlow.organism.summary.title": "Revisar o contexto e o resultado das ações principais da página",
    "kitchenProductionFlow.intention.summary.title": "Summary"
};
const message_en = {
    "kitchenProductionFlow.section.main.title": "Kitchen production flow",
    "kitchenProductionFlow.organism.viewKitchenTickets.title": "View kitchen tickets",
    "kitchenProductionFlow.intention.viewKitchenTickets.list.title": "Query List",
    "kitchenProductionFlow.field.kitchenTicketId": "Kitchen Ticket Id",
    "kitchenProductionFlow.field.orderId": "Order Id",
    "kitchenProductionFlow.field.status": "Status",
    "kitchenProductionFlow.field.createdAt": "Created At",
    "kitchenProductionFlow.field.updatedAt": "Updated At",
    "kitchenProductionFlow.filter.kitchenTicketId": "Kitchen Ticket Id",
    "kitchenProductionFlow.filter.orderId": "Order Id",
    "kitchenProductionFlow.filter.status": "Status",
    "kitchenProductionFlow.filter.createdAt": "Created At",
    "kitchenProductionFlow.filter.updatedAt": "Updated At",
    "kitchenProductionFlow.action.viewKitchenTickets": "View Kitchen Tickets",
    "kitchenProductionFlow.organism.updateKitchenTicketStatus.title": "Update kitchen ticket status",
    "kitchenProductionFlow.intention.updateKitchenTicketStatus.form.title": "Command Form",
    "kitchenProductionFlow.field.kitchenTicket.status": "Status",
    "kitchenProductionFlow.action.updateKitchenTicketStatus": "Update Kitchen Ticket Status",
    "kitchenProductionFlow.organism.updateOrderItemStatus.title": "Update order item status",
    "kitchenProductionFlow.intention.updateOrderItemStatus.form.title": "Command Form",
    "kitchenProductionFlow.field.orderItem.status": "Status",
    "kitchenProductionFlow.action.updateOrderItemStatus": "Update Order Item Status",
    "kitchenProductionFlow.organism.summary.title": "Review the context and the result of the page main actions",
    "kitchenProductionFlow.intention.summary.title": "Summary"
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowKitchenProductionFlowBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.viewKitchenTicketsState = 'idle';
        this.viewKitchenTicketsKitchenTicketId = '';
        this.viewKitchenTicketsOrderId = '';
        this.viewKitchenTicketsStatus = '';
        this.viewKitchenTicketsCreatedAt = '';
        this.viewKitchenTicketsUpdatedAt = '';
        this.viewKitchenTicketsData = [];
        this.updateKitchenTicketStatusState = 'idle';
        this.updateKitchenTicketStatusStatus = '';
        this.updateOrderItemStatusState = 'idle';
        this.updateOrderItemStatusStatus = '';
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || messages['en'];
    }
    connectedCallback() {
        super.connectedCallback();
        const storedStatus = getState('ui.kitchenProductionFlow.status');
        this.status = storedStatus ?? '';
        const storedViewKitchenTicketsState = getState('ui.kitchenProductionFlow.action.viewKitchenTickets.status');
        this.viewKitchenTicketsState = storedViewKitchenTicketsState ?? 'idle';
        const storedViewKitchenTicketsKitchenTicketId = getState('ui.kitchenProductionFlow.input.viewKitchenTickets.kitchenTicketId');
        this.viewKitchenTicketsKitchenTicketId = storedViewKitchenTicketsKitchenTicketId ?? '';
        const storedViewKitchenTicketsOrderId = getState('ui.kitchenProductionFlow.input.viewKitchenTickets.orderId');
        this.viewKitchenTicketsOrderId = storedViewKitchenTicketsOrderId ?? '';
        const storedViewKitchenTicketsStatus = getState('ui.kitchenProductionFlow.input.viewKitchenTickets.status');
        this.viewKitchenTicketsStatus = storedViewKitchenTicketsStatus ?? '';
        const storedViewKitchenTicketsCreatedAt = getState('ui.kitchenProductionFlow.input.viewKitchenTickets.createdAt');
        this.viewKitchenTicketsCreatedAt = storedViewKitchenTicketsCreatedAt ?? '';
        const storedViewKitchenTicketsUpdatedAt = getState('ui.kitchenProductionFlow.input.viewKitchenTickets.updatedAt');
        this.viewKitchenTicketsUpdatedAt = storedViewKitchenTicketsUpdatedAt ?? '';
        const storedViewKitchenTicketsData = getState('ui.kitchenProductionFlow.data.viewKitchenTickets');
        this.viewKitchenTicketsData = storedViewKitchenTicketsData ?? [];
        const storedUpdateKitchenTicketStatusState = getState('ui.kitchenProductionFlow.action.updateKitchenTicketStatus.status');
        this.updateKitchenTicketStatusState = storedUpdateKitchenTicketStatusState ?? 'idle';
        const storedUpdateKitchenTicketStatusStatus = getState('ui.kitchenProductionFlow.input.updateKitchenTicketStatus.status');
        this.updateKitchenTicketStatusStatus = storedUpdateKitchenTicketStatusStatus ?? '';
        const storedUpdateOrderItemStatusState = getState('ui.kitchenProductionFlow.action.updateOrderItemStatus.status');
        this.updateOrderItemStatusState = storedUpdateOrderItemStatusState ?? 'idle';
        const storedUpdateOrderItemStatusStatus = getState('ui.kitchenProductionFlow.input.updateOrderItemStatus.status');
        this.updateOrderItemStatusStatus = storedUpdateOrderItemStatusStatus ?? '';
        void this.loadViewKitchenTickets();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
    setViewKitchenTicketsKitchenTicketId(value) {
        this.viewKitchenTicketsKitchenTicketId = value;
        setState('ui.kitchenProductionFlow.input.viewKitchenTickets.kitchenTicketId', value);
        this.requestUpdate();
    }
    handleViewKitchenTicketsKitchenTicketIdChange(event) {
        const target = event.target;
        this.setViewKitchenTicketsKitchenTicketId(target?.value ?? '');
    }
    setViewKitchenTicketsOrderId(value) {
        this.viewKitchenTicketsOrderId = value;
        setState('ui.kitchenProductionFlow.input.viewKitchenTickets.orderId', value);
        this.requestUpdate();
    }
    handleViewKitchenTicketsOrderIdChange(event) {
        const target = event.target;
        this.setViewKitchenTicketsOrderId(target?.value ?? '');
    }
    setViewKitchenTicketsStatus(value) {
        this.viewKitchenTicketsStatus = value;
        setState('ui.kitchenProductionFlow.input.viewKitchenTickets.status', value);
        this.requestUpdate();
    }
    handleViewKitchenTicketsStatusChange(event) {
        const target = event.target;
        this.setViewKitchenTicketsStatus((target?.value ?? ''));
    }
    setViewKitchenTicketsCreatedAt(value) {
        this.viewKitchenTicketsCreatedAt = value;
        setState('ui.kitchenProductionFlow.input.viewKitchenTickets.createdAt', value);
        this.requestUpdate();
    }
    handleViewKitchenTicketsCreatedAtChange(event) {
        const target = event.target;
        this.setViewKitchenTicketsCreatedAt(target?.value ?? '');
    }
    setViewKitchenTicketsUpdatedAt(value) {
        this.viewKitchenTicketsUpdatedAt = value;
        setState('ui.kitchenProductionFlow.input.viewKitchenTickets.updatedAt', value);
        this.requestUpdate();
    }
    handleViewKitchenTicketsUpdatedAtChange(event) {
        const target = event.target;
        this.setViewKitchenTicketsUpdatedAt(target?.value ?? '');
    }
    setUpdateKitchenTicketStatusStatus(value) {
        this.updateKitchenTicketStatusStatus = value;
        setState('ui.kitchenProductionFlow.input.updateKitchenTicketStatus.status', value);
        this.requestUpdate();
    }
    handleUpdateKitchenTicketStatusStatusChange(event) {
        const target = event.target;
        this.setUpdateKitchenTicketStatusStatus((target?.value ?? ''));
    }
    setUpdateOrderItemStatusStatus(value) {
        this.updateOrderItemStatusStatus = value;
        setState('ui.kitchenProductionFlow.input.updateOrderItemStatus.status', value);
        this.requestUpdate();
    }
    handleUpdateOrderItemStatusStatusChange(event) {
        const target = event.target;
        this.setUpdateOrderItemStatusStatus((target?.value ?? ''));
    }
    async loadViewKitchenTickets() {
        this.viewKitchenTicketsState = 'loading';
        setState('ui.kitchenProductionFlow.action.viewKitchenTickets.status', 'loading');
        const params = {
            kitchenTicketId: this.viewKitchenTicketsKitchenTicketId || undefined,
            orderId: this.viewKitchenTicketsOrderId || undefined,
            status: (this.viewKitchenTicketsStatus || undefined),
            createdAt: this.viewKitchenTicketsCreatedAt || undefined,
            updatedAt: this.viewKitchenTicketsUpdatedAt || undefined
        };
        const options = { mode: 'silent' };
        const response = await execBff('cafeFlow.kitchenProductionFlow.viewKitchenTickets', params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.viewKitchenTicketsData = data;
            setState('ui.kitchenProductionFlow.data.viewKitchenTickets', data);
            this.viewKitchenTicketsState = 'success';
            setState('ui.kitchenProductionFlow.action.viewKitchenTickets.status', 'success');
        }
        else {
            this.viewKitchenTicketsState = 'error';
            setState('ui.kitchenProductionFlow.action.viewKitchenTickets.status', 'error');
            this.viewKitchenTicketsData = [];
            setState('ui.kitchenProductionFlow.data.viewKitchenTickets', []);
        }
    }
    handleViewKitchenTicketsClick() {
        void this.loadViewKitchenTickets();
    }
    async updateKitchenTicketStatus() {
        this.updateKitchenTicketStatusState = 'loading';
        setState('ui.kitchenProductionFlow.action.updateKitchenTicketStatus.status', 'loading');
        const params = {
            status: this.updateKitchenTicketStatusStatus
        };
        const options = { mode: 'blocking' };
        const response = await execBff('cafeFlow.kitchenProductionFlow.updateKitchenTicketStatus', params, options);
        if (response.ok) {
            this.updateKitchenTicketStatusState = 'success';
            setState('ui.kitchenProductionFlow.action.updateKitchenTicketStatus.status', 'success');
        }
        else {
            this.updateKitchenTicketStatusState = 'error';
            setState('ui.kitchenProductionFlow.action.updateKitchenTicketStatus.status', 'error');
        }
    }
    handleUpdateKitchenTicketStatusClick() {
        runBlockingUiAction(async () => {
            await this.updateKitchenTicketStatus();
        });
    }
    async updateOrderItemStatus() {
        this.updateOrderItemStatusState = 'loading';
        setState('ui.kitchenProductionFlow.action.updateOrderItemStatus.status', 'loading');
        const params = {
            status: this.updateOrderItemStatusStatus
        };
        const options = { mode: 'blocking' };
        const response = await execBff('cafeFlow.kitchenProductionFlow.updateOrderItemStatus', params, options);
        if (response.ok) {
            this.updateOrderItemStatusState = 'success';
            setState('ui.kitchenProductionFlow.action.updateOrderItemStatus.status', 'success');
        }
        else {
            this.updateOrderItemStatusState = 'error';
            setState('ui.kitchenProductionFlow.action.updateOrderItemStatus.status', 'error');
        }
    }
    handleUpdateOrderItemStatusClick() {
        runBlockingUiAction(async () => {
            await this.updateOrderItemStatus();
        });
    }
}
__decorate([
    property({ type: String })
], CafeFlowKitchenProductionFlowBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenProductionFlowBase.prototype, "viewKitchenTicketsState", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenProductionFlowBase.prototype, "viewKitchenTicketsKitchenTicketId", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenProductionFlowBase.prototype, "viewKitchenTicketsOrderId", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenProductionFlowBase.prototype, "viewKitchenTicketsStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenProductionFlowBase.prototype, "viewKitchenTicketsCreatedAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenProductionFlowBase.prototype, "viewKitchenTicketsUpdatedAt", void 0);
__decorate([
    property({ type: Array })
], CafeFlowKitchenProductionFlowBase.prototype, "viewKitchenTicketsData", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenProductionFlowBase.prototype, "updateKitchenTicketStatusState", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenProductionFlowBase.prototype, "updateKitchenTicketStatusStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenProductionFlowBase.prototype, "updateOrderItemStatusState", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenProductionFlowBase.prototype, "updateOrderItemStatusStatus", void 0);
