/// <mls fileReference="_102050_/l2/cafeFlow/web/shared/generateShiftCloseReport.ts" enhancement="_blank"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
const message_pt = {
    'generateShiftCloseReport.section.title': 'Gerar relatório de fechamento de turno',
    'generateShiftCloseReport.organism.title': 'Gerar relatório de fechamento de turno',
    'generateShiftCloseReport.filters.title': 'Command Form',
    'generateShiftCloseReport.filters.status': 'Status',
    'generateShiftCloseReport.filters.openedAt': 'Opened At',
    'generateShiftCloseReport.filters.closedAt': 'Closed At',
    'generateShiftCloseReport.actions.generate': 'Generate Shift Close Report',
    'generateShiftCloseReport.summary.title': 'Summary',
    'generateShiftCloseReport.summary.status': 'Status',
    'generateShiftCloseReport.summary.openedAt': 'Opened At',
    'generateShiftCloseReport.summary.closedAt': 'Closed At',
    'generateShiftCloseReport.summary.openingCashBalance': 'Opening Cash Balance',
    'generateShiftCloseReport.summary.closingCashBalance': 'Closing Cash Balance',
    'generateShiftCloseReport.summary.totalSales': 'Total Sales',
    'generateShiftCloseReport.summary.totalPayments': 'Total Payments',
    'generateShiftCloseReport.summary.closingNotes': 'Closing Notes',
};
const message_en = {
    'generateShiftCloseReport.section.title': 'Generate Shift Close Report',
    'generateShiftCloseReport.organism.title': 'Generate Shift Close Report',
    'generateShiftCloseReport.filters.title': 'Command Form',
    'generateShiftCloseReport.filters.status': 'Status',
    'generateShiftCloseReport.filters.openedAt': 'Opened At',
    'generateShiftCloseReport.filters.closedAt': 'Closed At',
    'generateShiftCloseReport.actions.generate': 'Generate Shift Close Report',
    'generateShiftCloseReport.summary.title': 'Summary',
    'generateShiftCloseReport.summary.status': 'Status',
    'generateShiftCloseReport.summary.openedAt': 'Opened At',
    'generateShiftCloseReport.summary.closedAt': 'Closed At',
    'generateShiftCloseReport.summary.openingCashBalance': 'Opening Cash Balance',
    'generateShiftCloseReport.summary.closingCashBalance': 'Closing Cash Balance',
    'generateShiftCloseReport.summary.totalSales': 'Total Sales',
    'generateShiftCloseReport.summary.totalPayments': 'Total Payments',
    'generateShiftCloseReport.summary.closingNotes': 'Closing Notes',
};
export class CafeFlowGenerateShiftCloseReportBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.generateShiftCloseReportState = 'idle';
        this.generateShiftCloseReportStatus = '';
        this.generateShiftCloseReportOpenedAt = '';
        this.generateShiftCloseReportClosedAt = '';
        this.generateShiftCloseReportData = [];
    }
    get msg() {
        const lang = this.lang ?? 'pt';
        return lang === 'en' ? message_en : message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        this.status = getState('ui.generateShiftCloseReport.status') ?? '';
        this.generateShiftCloseReportState = getState('ui.generateShiftCloseReport.action.generateShiftCloseReport.status') ?? 'idle';
        this.generateShiftCloseReportStatus = getState('ui.generateShiftCloseReport.input.generateShiftCloseReport.status') ?? '';
        this.generateShiftCloseReportOpenedAt = getState('ui.generateShiftCloseReport.input.generateShiftCloseReport.openedAt') ?? '';
        this.generateShiftCloseReportClosedAt = getState('ui.generateShiftCloseReport.input.generateShiftCloseReport.closedAt') ?? '';
        this.generateShiftCloseReportData = getState('ui.generateShiftCloseReport.data.generateShiftCloseReport') ?? [];
        this.loadGenerateShiftCloseReport();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
    // --- State setters ---
    setGenerateShiftCloseReportStatus(value) {
        this.generateShiftCloseReportStatus = value;
        setState('ui.generateShiftCloseReport.input.generateShiftCloseReport.status', value);
        this.requestUpdate();
    }
    handleGenerateShiftCloseReportStatusChange(e) {
        const target = e.target;
        this.setGenerateShiftCloseReportStatus(target.value);
    }
    setGenerateShiftCloseReportOpenedAt(value) {
        this.generateShiftCloseReportOpenedAt = value;
        setState('ui.generateShiftCloseReport.input.generateShiftCloseReport.openedAt', value);
        this.requestUpdate();
    }
    handleGenerateShiftCloseReportOpenedAtChange(e) {
        const target = e.target;
        this.setGenerateShiftCloseReportOpenedAt(target.value);
    }
    setGenerateShiftCloseReportClosedAt(value) {
        this.generateShiftCloseReportClosedAt = value;
        setState('ui.generateShiftCloseReport.input.generateShiftCloseReport.closedAt', value);
        this.requestUpdate();
    }
    handleGenerateShiftCloseReportClosedAtChange(e) {
        const target = e.target;
        this.setGenerateShiftCloseReportClosedAt(target.value);
    }
    // --- Query action ---
    async loadGenerateShiftCloseReport() {
        this.generateShiftCloseReportState = 'loading';
        setState('ui.generateShiftCloseReport.action.generateShiftCloseReport.status', 'loading');
        const params = {
            status: (this.generateShiftCloseReportStatus || undefined),
            openedAt: this.generateShiftCloseReportOpenedAt || undefined,
            closedAt: this.generateShiftCloseReportClosedAt || undefined,
        };
        const options = { mode: 'silent' };
        try {
            const response = await execBff('cafeFlow.generateShiftCloseReport.generateShiftCloseReport', params, options);
            if (response.ok) {
                const data = response.data ?? [];
                this.generateShiftCloseReportData = data;
                setState('ui.generateShiftCloseReport.data.generateShiftCloseReport', data);
                this.generateShiftCloseReportState = 'success';
                setState('ui.generateShiftCloseReport.action.generateShiftCloseReport.status', 'success');
            }
            else {
                this.generateShiftCloseReportState = 'error';
                setState('ui.generateShiftCloseReport.action.generateShiftCloseReport.status', 'error');
            }
        }
        catch {
            this.generateShiftCloseReportState = 'error';
            setState('ui.generateShiftCloseReport.action.generateShiftCloseReport.status', 'error');
        }
    }
    handleGenerateShiftCloseReportClick(e) {
        e.preventDefault();
        runBlockingUiAction(async () => {
            await this.loadGenerateShiftCloseReport();
        });
    }
}
__decorate([
    property({ type: String })
], CafeFlowGenerateShiftCloseReportBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowGenerateShiftCloseReportBase.prototype, "generateShiftCloseReportState", void 0);
__decorate([
    property({ type: String })
], CafeFlowGenerateShiftCloseReportBase.prototype, "generateShiftCloseReportStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowGenerateShiftCloseReportBase.prototype, "generateShiftCloseReportOpenedAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowGenerateShiftCloseReportBase.prototype, "generateShiftCloseReportClosedAt", void 0);
__decorate([
    property({ type: Array })
], CafeFlowGenerateShiftCloseReportBase.prototype, "generateShiftCloseReportData", void 0);
