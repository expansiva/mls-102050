/// <mls fileReference="_102050_/l2/cafeFlow/web/shared/dineInOrderLifecycle.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "dineInOrderLifecycle.section.main.title": "Ciclo de pedido (mesa)",
    "dineInOrderLifecycle.organism.createOrder.title": "Criar pedido",
    "dineInOrderLifecycle.stage.createOrder.title": "Command Form",
    "dineInOrderLifecycle.field.orderType.label": "Order Type",
    "dineInOrderLifecycle.field.status.label": "Status",
    "dineInOrderLifecycle.field.totalAmount.label": "Total Amount",
    "dineInOrderLifecycle.field.notes.label": "Notes",
    "dineInOrderLifecycle.field.customerName.label": "Customer Name",
    "dineInOrderLifecycle.field.customerPhone.label": "Customer Phone",
    "dineInOrderLifecycle.field.numberOfGuests.label": "Number Of Guests",
    "dineInOrderLifecycle.field.closedAt.label": "Closed At",
    "dineInOrderLifecycle.field.cancelledAt.label": "Cancelled At",
    "dineInOrderLifecycle.field.cancellationReason.label": "Cancellation Reason",
    "dineInOrderLifecycle.action.createOrder.label": "Create Order",
    "dineInOrderLifecycle.organism.addOrderItem.title": "Adicionar item ao pedido",
    "dineInOrderLifecycle.stage.addOrderItem.title": "Command Form",
    "dineInOrderLifecycle.field.quantity.label": "Quantity",
    "dineInOrderLifecycle.field.unitPrice.label": "Unit Price",
    "dineInOrderLifecycle.field.totalPrice.label": "Total Price",
    "dineInOrderLifecycle.field.observations.label": "Observations",
    "dineInOrderLifecycle.field.itemStatus.label": "Status",
    "dineInOrderLifecycle.action.addOrderItem.label": "Add Order Item",
    "dineInOrderLifecycle.organism.createKitchenTicket.title": "Criar ticket de cozinha",
    "dineInOrderLifecycle.stage.createKitchenTicket.title": "Command Form",
    "dineInOrderLifecycle.field.kitchenTicketStatus.label": "Status",
    "dineInOrderLifecycle.action.createKitchenTicket.label": "Create Kitchen Ticket",
    "dineInOrderLifecycle.organism.updateOrderStatus.title": "Atualizar status do pedido",
    "dineInOrderLifecycle.stage.updateOrderStatus.title": "Command Form",
    "dineInOrderLifecycle.action.updateOrderStatus.label": "Update Order Status",
    "dineInOrderLifecycle.organism.updateTableStatus.title": "Atualizar ocupação da mesa",
    "dineInOrderLifecycle.stage.updateTableStatus.title": "Command Form",
    "dineInOrderLifecycle.field.tableStatus.label": "Status",
    "dineInOrderLifecycle.field.currentChargesTotal.label": "Current Charges Total",
    "dineInOrderLifecycle.field.openedAt.label": "Opened At",
    "dineInOrderLifecycle.action.updateTableStatus.label": "Update Table Status",
    "dineInOrderLifecycle.organism.review.title": "Revisar o contexto e o resultado das ações principais da página",
    "dineInOrderLifecycle.stage.review.title": "Summary"
};
const message_en = {
    "dineInOrderLifecycle.section.main.title": "Dine-in Order Lifecycle",
    "dineInOrderLifecycle.organism.createOrder.title": "Create Order",
    "dineInOrderLifecycle.stage.createOrder.title": "Command Form",
    "dineInOrderLifecycle.field.orderType.label": "Order Type",
    "dineInOrderLifecycle.field.status.label": "Status",
    "dineInOrderLifecycle.field.totalAmount.label": "Total Amount",
    "dineInOrderLifecycle.field.notes.label": "Notes",
    "dineInOrderLifecycle.field.customerName.label": "Customer Name",
    "dineInOrderLifecycle.field.customerPhone.label": "Customer Phone",
    "dineInOrderLifecycle.field.numberOfGuests.label": "Number Of Guests",
    "dineInOrderLifecycle.field.closedAt.label": "Closed At",
    "dineInOrderLifecycle.field.cancelledAt.label": "Cancelled At",
    "dineInOrderLifecycle.field.cancellationReason.label": "Cancellation Reason",
    "dineInOrderLifecycle.action.createOrder.label": "Create Order",
    "dineInOrderLifecycle.organism.addOrderItem.title": "Add Order Item",
    "dineInOrderLifecycle.stage.addOrderItem.title": "Command Form",
    "dineInOrderLifecycle.field.quantity.label": "Quantity",
    "dineInOrderLifecycle.field.unitPrice.label": "Unit Price",
    "dineInOrderLifecycle.field.totalPrice.label": "Total Price",
    "dineInOrderLifecycle.field.observations.label": "Observations",
    "dineInOrderLifecycle.field.itemStatus.label": "Status",
    "dineInOrderLifecycle.action.addOrderItem.label": "Add Order Item",
    "dineInOrderLifecycle.organism.createKitchenTicket.title": "Create Kitchen Ticket",
    "dineInOrderLifecycle.stage.createKitchenTicket.title": "Command Form",
    "dineInOrderLifecycle.field.kitchenTicketStatus.label": "Status",
    "dineInOrderLifecycle.action.createKitchenTicket.label": "Create Kitchen Ticket",
    "dineInOrderLifecycle.organism.updateOrderStatus.title": "Update Order Status",
    "dineInOrderLifecycle.stage.updateOrderStatus.title": "Command Form",
    "dineInOrderLifecycle.action.updateOrderStatus.label": "Update Order Status",
    "dineInOrderLifecycle.organism.updateTableStatus.title": "Update Table Status",
    "dineInOrderLifecycle.stage.updateTableStatus.title": "Command Form",
    "dineInOrderLifecycle.field.tableStatus.label": "Status",
    "dineInOrderLifecycle.field.currentChargesTotal.label": "Current Charges Total",
    "dineInOrderLifecycle.field.openedAt.label": "Opened At",
    "dineInOrderLifecycle.action.updateTableStatus.label": "Update Table Status",
    "dineInOrderLifecycle.organism.review.title": "Review the context and result of the main page actions",
    "dineInOrderLifecycle.stage.review.title": "Summary"
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowDineInOrderLifecycleBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = "";
        this.createOrderState = "idle";
        this.createOrderOrderType = "";
        this.createOrderStatus = "";
        this.createOrderTotalAmount = "";
        this.createOrderNotes = "";
        this.createOrderCustomerName = "";
        this.createOrderCustomerPhone = "";
        this.createOrderNumberOfGuests = "";
        this.createOrderClosedAt = "";
        this.createOrderCancelledAt = "";
        this.createOrderCancellationReason = "";
        this.addOrderItemState = "idle";
        this.addOrderItemQuantity = "";
        this.addOrderItemUnitPrice = "";
        this.addOrderItemTotalPrice = "";
        this.addOrderItemObservations = "";
        this.addOrderItemStatus = "";
        this.createKitchenTicketState = "idle";
        this.createKitchenTicketStatus = "";
        this.updateOrderStatusState = "idle";
        this.updateOrderStatusStatus = "";
        this.updateOrderStatusClosedAt = "";
        this.updateOrderStatusCancelledAt = "";
        this.updateOrderStatusCancellationReason = "";
        this.updateTableStatusState = "idle";
        this.updateTableStatusStatus = "";
        this.updateTableStatusCurrentChargesTotal = "";
        this.updateTableStatusOpenedAt = "";
        this.updateTableStatusClosedAt = "";
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || messages['en'];
    }
    // ── State setters: createOrder ──
    setCreateOrderOrderType(value) {
        this.createOrderOrderType = value;
        setState("ui.dineInOrderLifecycle.input.createOrder.orderType", value);
        this.requestUpdate();
    }
    handleCreateOrderOrderTypeChange(e) {
        const value = e.target.value;
        this.setCreateOrderOrderType(value);
    }
    setCreateOrderStatus(value) {
        this.createOrderStatus = value;
        setState("ui.dineInOrderLifecycle.input.createOrder.status", value);
        this.requestUpdate();
    }
    handleCreateOrderStatusChange(e) {
        const value = e.target.value;
        this.setCreateOrderStatus(value);
    }
    setCreateOrderTotalAmount(value) {
        this.createOrderTotalAmount = value;
        setState("ui.dineInOrderLifecycle.input.createOrder.totalAmount", value);
        this.requestUpdate();
    }
    handleCreateOrderTotalAmountChange(e) {
        const value = e.target.value;
        this.setCreateOrderTotalAmount(value);
    }
    setCreateOrderNotes(value) {
        this.createOrderNotes = value;
        setState("ui.dineInOrderLifecycle.input.createOrder.notes", value);
        this.requestUpdate();
    }
    handleCreateOrderNotesChange(e) {
        const value = e.target.value;
        this.setCreateOrderNotes(value);
    }
    setCreateOrderCustomerName(value) {
        this.createOrderCustomerName = value;
        setState("ui.dineInOrderLifecycle.input.createOrder.customerName", value);
        this.requestUpdate();
    }
    handleCreateOrderCustomerNameChange(e) {
        const value = e.target.value;
        this.setCreateOrderCustomerName(value);
    }
    setCreateOrderCustomerPhone(value) {
        this.createOrderCustomerPhone = value;
        setState("ui.dineInOrderLifecycle.input.createOrder.customerPhone", value);
        this.requestUpdate();
    }
    handleCreateOrderCustomerPhoneChange(e) {
        const value = e.target.value;
        this.setCreateOrderCustomerPhone(value);
    }
    setCreateOrderNumberOfGuests(value) {
        this.createOrderNumberOfGuests = value;
        setState("ui.dineInOrderLifecycle.input.createOrder.numberOfGuests", value);
        this.requestUpdate();
    }
    handleCreateOrderNumberOfGuestsChange(e) {
        const value = e.target.value;
        this.setCreateOrderNumberOfGuests(value);
    }
    setCreateOrderClosedAt(value) {
        this.createOrderClosedAt = value;
        setState("ui.dineInOrderLifecycle.input.createOrder.closedAt", value);
        this.requestUpdate();
    }
    handleCreateOrderClosedAtChange(e) {
        const value = e.target.value;
        this.setCreateOrderClosedAt(value);
    }
    setCreateOrderCancelledAt(value) {
        this.createOrderCancelledAt = value;
        setState("ui.dineInOrderLifecycle.input.createOrder.cancelledAt", value);
        this.requestUpdate();
    }
    handleCreateOrderCancelledAtChange(e) {
        const value = e.target.value;
        this.setCreateOrderCancelledAt(value);
    }
    setCreateOrderCancellationReason(value) {
        this.createOrderCancellationReason = value;
        setState("ui.dineInOrderLifecycle.input.createOrder.cancellationReason", value);
        this.requestUpdate();
    }
    handleCreateOrderCancellationReasonChange(e) {
        const value = e.target.value;
        this.setCreateOrderCancellationReason(value);
    }
    // ── State setters: addOrderItem ──
    setAddOrderItemQuantity(value) {
        this.addOrderItemQuantity = value;
        setState("ui.dineInOrderLifecycle.input.addOrderItem.quantity", value);
        this.requestUpdate();
    }
    handleAddOrderItemQuantityChange(e) {
        const value = e.target.value;
        this.setAddOrderItemQuantity(value);
    }
    setAddOrderItemUnitPrice(value) {
        this.addOrderItemUnitPrice = value;
        setState("ui.dineInOrderLifecycle.input.addOrderItem.unitPrice", value);
        this.requestUpdate();
    }
    handleAddOrderItemUnitPriceChange(e) {
        const value = e.target.value;
        this.setAddOrderItemUnitPrice(value);
    }
    setAddOrderItemTotalPrice(value) {
        this.addOrderItemTotalPrice = value;
        setState("ui.dineInOrderLifecycle.input.addOrderItem.totalPrice", value);
        this.requestUpdate();
    }
    handleAddOrderItemTotalPriceChange(e) {
        const value = e.target.value;
        this.setAddOrderItemTotalPrice(value);
    }
    setAddOrderItemObservations(value) {
        this.addOrderItemObservations = value;
        setState("ui.dineInOrderLifecycle.input.addOrderItem.observations", value);
        this.requestUpdate();
    }
    handleAddOrderItemObservationsChange(e) {
        const value = e.target.value;
        this.setAddOrderItemObservations(value);
    }
    setAddOrderItemStatus(value) {
        this.addOrderItemStatus = value;
        setState("ui.dineInOrderLifecycle.input.addOrderItem.status", value);
        this.requestUpdate();
    }
    handleAddOrderItemStatusChange(e) {
        const value = e.target.value;
        this.setAddOrderItemStatus(value);
    }
    // ── State setters: createKitchenTicket ──
    setCreateKitchenTicketStatus(value) {
        this.createKitchenTicketStatus = value;
        setState("ui.dineInOrderLifecycle.input.createKitchenTicket.status", value);
        this.requestUpdate();
    }
    handleCreateKitchenTicketStatusChange(e) {
        const value = e.target.value;
        this.setCreateKitchenTicketStatus(value);
    }
    // ── State setters: updateOrderStatus ──
    setUpdateOrderStatusStatus(value) {
        this.updateOrderStatusStatus = value;
        setState("ui.dineInOrderLifecycle.input.updateOrderStatus.status", value);
        this.requestUpdate();
    }
    handleUpdateOrderStatusStatusChange(e) {
        const value = e.target.value;
        this.setUpdateOrderStatusStatus(value);
    }
    setUpdateOrderStatusClosedAt(value) {
        this.updateOrderStatusClosedAt = value;
        setState("ui.dineInOrderLifecycle.input.updateOrderStatus.closedAt", value);
        this.requestUpdate();
    }
    handleUpdateOrderStatusClosedAtChange(e) {
        const value = e.target.value;
        this.setUpdateOrderStatusClosedAt(value);
    }
    setUpdateOrderStatusCancelledAt(value) {
        this.updateOrderStatusCancelledAt = value;
        setState("ui.dineInOrderLifecycle.input.updateOrderStatus.cancelledAt", value);
        this.requestUpdate();
    }
    handleUpdateOrderStatusCancelledAtChange(e) {
        const value = e.target.value;
        this.setUpdateOrderStatusCancelledAt(value);
    }
    setUpdateOrderStatusCancellationReason(value) {
        this.updateOrderStatusCancellationReason = value;
        setState("ui.dineInOrderLifecycle.input.updateOrderStatus.cancellationReason", value);
        this.requestUpdate();
    }
    handleUpdateOrderStatusCancellationReasonChange(e) {
        const value = e.target.value;
        this.setUpdateOrderStatusCancellationReason(value);
    }
    // ── State setters: updateTableStatus ──
    setUpdateTableStatusStatus(value) {
        this.updateTableStatusStatus = value;
        setState("ui.dineInOrderLifecycle.input.updateTableStatus.status", value);
        this.requestUpdate();
    }
    handleUpdateTableStatusStatusChange(e) {
        const value = e.target.value;
        this.setUpdateTableStatusStatus(value);
    }
    setUpdateTableStatusCurrentChargesTotal(value) {
        this.updateTableStatusCurrentChargesTotal = value;
        setState("ui.dineInOrderLifecycle.input.updateTableStatus.currentChargesTotal", value);
        this.requestUpdate();
    }
    handleUpdateTableStatusCurrentChargesTotalChange(e) {
        const value = e.target.value;
        this.setUpdateTableStatusCurrentChargesTotal(value);
    }
    setUpdateTableStatusOpenedAt(value) {
        this.updateTableStatusOpenedAt = value;
        setState("ui.dineInOrderLifecycle.input.updateTableStatus.openedAt", value);
        this.requestUpdate();
    }
    handleUpdateTableStatusOpenedAtChange(e) {
        const value = e.target.value;
        this.setUpdateTableStatusOpenedAt(value);
    }
    setUpdateTableStatusClosedAt(value) {
        this.updateTableStatusClosedAt = value;
        setState("ui.dineInOrderLifecycle.input.updateTableStatus.closedAt", value);
        this.requestUpdate();
    }
    handleUpdateTableStatusClosedAtChange(e) {
        const value = e.target.value;
        this.setUpdateTableStatusClosedAt(value);
    }
    // ── Command actions ──
    async createOrder() {
        this.createOrderState = "loading";
        setState("ui.dineInOrderLifecycle.action.createOrder.status", "loading");
        this.requestUpdate();
        const params = {
            orderType: this.createOrderOrderType,
            status: this.createOrderStatus,
            totalAmount: Number(this.createOrderTotalAmount),
            notes: this.createOrderNotes || undefined,
            customerName: this.createOrderCustomerName || undefined,
            customerPhone: this.createOrderCustomerPhone || undefined,
            numberOfGuests: this.createOrderNumberOfGuests ? Number(this.createOrderNumberOfGuests) : undefined,
            closedAt: this.createOrderClosedAt || undefined,
            cancelledAt: this.createOrderCancelledAt || undefined,
            cancellationReason: this.createOrderCancellationReason || undefined,
        };
        const options = { mode: "blocking" };
        const response = await execBff("cafeFlow.dineInOrderLifecycle.createOrder", params, options);
        if (response.ok) {
            this.createOrderState = "success";
            setState("ui.dineInOrderLifecycle.action.createOrder.status", "success");
        }
        else {
            this.createOrderState = "error";
            setState("ui.dineInOrderLifecycle.action.createOrder.status", "error");
        }
        this.requestUpdate();
    }
    handleCreateOrderClick() {
        runBlockingUiAction(async () => {
            await this.createOrder();
        });
    }
    async addOrderItem() {
        this.addOrderItemState = "loading";
        setState("ui.dineInOrderLifecycle.action.addOrderItem.status", "loading");
        this.requestUpdate();
        const params = {
            quantity: Number(this.addOrderItemQuantity),
            unitPrice: Number(this.addOrderItemUnitPrice),
            totalPrice: Number(this.addOrderItemTotalPrice),
            observations: this.addOrderItemObservations || undefined,
            status: this.addOrderItemStatus,
        };
        const options = { mode: "blocking" };
        const response = await execBff("cafeFlow.dineInOrderLifecycle.addOrderItem", params, options);
        if (response.ok) {
            this.addOrderItemState = "success";
            setState("ui.dineInOrderLifecycle.action.addOrderItem.status", "success");
        }
        else {
            this.addOrderItemState = "error";
            setState("ui.dineInOrderLifecycle.action.addOrderItem.status", "error");
        }
        this.requestUpdate();
    }
    handleAddOrderItemClick() {
        runBlockingUiAction(async () => {
            await this.addOrderItem();
        });
    }
    async createKitchenTicket() {
        this.createKitchenTicketState = "loading";
        setState("ui.dineInOrderLifecycle.action.createKitchenTicket.status", "loading");
        this.requestUpdate();
        const params = {
            status: this.createKitchenTicketStatus,
        };
        const options = { mode: "blocking" };
        const response = await execBff("cafeFlow.dineInOrderLifecycle.createKitchenTicket", params, options);
        if (response.ok) {
            this.createKitchenTicketState = "success";
            setState("ui.dineInOrderLifecycle.action.createKitchenTicket.status", "success");
        }
        else {
            this.createKitchenTicketState = "error";
            setState("ui.dineInOrderLifecycle.action.createKitchenTicket.status", "error");
        }
        this.requestUpdate();
    }
    handleCreateKitchenTicketClick() {
        runBlockingUiAction(async () => {
            await this.createKitchenTicket();
        });
    }
    async updateOrderStatus() {
        this.updateOrderStatusState = "loading";
        setState("ui.dineInOrderLifecycle.action.updateOrderStatus.status", "loading");
        this.requestUpdate();
        const params = {
            status: this.updateOrderStatusStatus,
            closedAt: this.updateOrderStatusClosedAt || undefined,
            cancelledAt: this.updateOrderStatusCancelledAt || undefined,
            cancellationReason: this.updateOrderStatusCancellationReason || undefined,
        };
        const options = { mode: "blocking" };
        const response = await execBff("cafeFlow.dineInOrderLifecycle.updateOrderStatus", params, options);
        if (response.ok) {
            this.updateOrderStatusState = "success";
            setState("ui.dineInOrderLifecycle.action.updateOrderStatus.status", "success");
        }
        else {
            this.updateOrderStatusState = "error";
            setState("ui.dineInOrderLifecycle.action.updateOrderStatus.status", "error");
        }
        this.requestUpdate();
    }
    handleUpdateOrderStatusClick() {
        runBlockingUiAction(async () => {
            await this.updateOrderStatus();
        });
    }
    async updateTableStatus() {
        this.updateTableStatusState = "loading";
        setState("ui.dineInOrderLifecycle.action.updateTableStatus.status", "loading");
        this.requestUpdate();
        const params = {
            status: this.updateTableStatusStatus,
            currentChargesTotal: Number(this.updateTableStatusCurrentChargesTotal),
            openedAt: this.updateTableStatusOpenedAt || undefined,
            closedAt: this.updateTableStatusClosedAt || undefined,
        };
        const options = { mode: "blocking" };
        const response = await execBff("cafeFlow.dineInOrderLifecycle.updateTableStatus", params, options);
        if (response.ok) {
            this.updateTableStatusState = "success";
            setState("ui.dineInOrderLifecycle.action.updateTableStatus.status", "success");
        }
        else {
            this.updateTableStatusState = "error";
            setState("ui.dineInOrderLifecycle.action.updateTableStatus.status", "error");
        }
        this.requestUpdate();
    }
    handleUpdateTableStatusClick() {
        runBlockingUiAction(async () => {
            await this.updateTableStatus();
        });
    }
    // ── Lifecycle ──
    connectedCallback() {
        super.connectedCallback();
        this.status = getState("ui.dineInOrderLifecycle.status") ?? "";
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
}
__decorate([
    property()
], CafeFlowDineInOrderLifecycleBase.prototype, "status", void 0);
__decorate([
    property()
], CafeFlowDineInOrderLifecycleBase.prototype, "createOrderState", void 0);
__decorate([
    property()
], CafeFlowDineInOrderLifecycleBase.prototype, "createOrderOrderType", void 0);
__decorate([
    property()
], CafeFlowDineInOrderLifecycleBase.prototype, "createOrderStatus", void 0);
__decorate([
    property()
], CafeFlowDineInOrderLifecycleBase.prototype, "createOrderTotalAmount", void 0);
__decorate([
    property()
], CafeFlowDineInOrderLifecycleBase.prototype, "createOrderNotes", void 0);
__decorate([
    property()
], CafeFlowDineInOrderLifecycleBase.prototype, "createOrderCustomerName", void 0);
__decorate([
    property()
], CafeFlowDineInOrderLifecycleBase.prototype, "createOrderCustomerPhone", void 0);
__decorate([
    property()
], CafeFlowDineInOrderLifecycleBase.prototype, "createOrderNumberOfGuests", void 0);
__decorate([
    property()
], CafeFlowDineInOrderLifecycleBase.prototype, "createOrderClosedAt", void 0);
__decorate([
    property()
], CafeFlowDineInOrderLifecycleBase.prototype, "createOrderCancelledAt", void 0);
__decorate([
    property()
], CafeFlowDineInOrderLifecycleBase.prototype, "createOrderCancellationReason", void 0);
__decorate([
    property()
], CafeFlowDineInOrderLifecycleBase.prototype, "addOrderItemState", void 0);
__decorate([
    property()
], CafeFlowDineInOrderLifecycleBase.prototype, "addOrderItemQuantity", void 0);
__decorate([
    property()
], CafeFlowDineInOrderLifecycleBase.prototype, "addOrderItemUnitPrice", void 0);
__decorate([
    property()
], CafeFlowDineInOrderLifecycleBase.prototype, "addOrderItemTotalPrice", void 0);
__decorate([
    property()
], CafeFlowDineInOrderLifecycleBase.prototype, "addOrderItemObservations", void 0);
__decorate([
    property()
], CafeFlowDineInOrderLifecycleBase.prototype, "addOrderItemStatus", void 0);
__decorate([
    property()
], CafeFlowDineInOrderLifecycleBase.prototype, "createKitchenTicketState", void 0);
__decorate([
    property()
], CafeFlowDineInOrderLifecycleBase.prototype, "createKitchenTicketStatus", void 0);
__decorate([
    property()
], CafeFlowDineInOrderLifecycleBase.prototype, "updateOrderStatusState", void 0);
__decorate([
    property()
], CafeFlowDineInOrderLifecycleBase.prototype, "updateOrderStatusStatus", void 0);
__decorate([
    property()
], CafeFlowDineInOrderLifecycleBase.prototype, "updateOrderStatusClosedAt", void 0);
__decorate([
    property()
], CafeFlowDineInOrderLifecycleBase.prototype, "updateOrderStatusCancelledAt", void 0);
__decorate([
    property()
], CafeFlowDineInOrderLifecycleBase.prototype, "updateOrderStatusCancellationReason", void 0);
__decorate([
    property()
], CafeFlowDineInOrderLifecycleBase.prototype, "updateTableStatusState", void 0);
__decorate([
    property()
], CafeFlowDineInOrderLifecycleBase.prototype, "updateTableStatusStatus", void 0);
__decorate([
    property()
], CafeFlowDineInOrderLifecycleBase.prototype, "updateTableStatusCurrentChargesTotal", void 0);
__decorate([
    property()
], CafeFlowDineInOrderLifecycleBase.prototype, "updateTableStatusOpenedAt", void 0);
__decorate([
    property()
], CafeFlowDineInOrderLifecycleBase.prototype, "updateTableStatusClosedAt", void 0);
