/// <mls fileReference="_102050_/l2/cafeFlow/web/shared/browseMenuForPos.ts" enhancement="_blank"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
const message_pt = {
    'browseMenuForPos.page.title': 'Consultar cardápio no POS',
    'browseMenuForPos.section.menu.title': 'Consultar cardápio no POS',
    'browseMenuForPos.organism.menu.title': 'Cardápio no POS',
    'browseMenuForPos.intent.list.title': 'Itens do cardápio',
    'browseMenuForPos.filter.menuItemId.label': 'ID do item',
    'browseMenuForPos.filter.menuCategoryId.label': 'ID da categoria',
    'browseMenuForPos.filter.name.label': 'Nome do item',
    'browseMenuForPos.filter.status.label': 'Status',
    'browseMenuForPos.filter.createdAt.label': 'Criado em',
    'browseMenuForPos.filter.updatedAt.label': 'Atualizado em',
    'browseMenuForPos.column.menuItemId.label': 'ID do item',
    'browseMenuForPos.column.menuCategoryId.label': 'ID da categoria',
    'browseMenuForPos.column.name.label': 'Nome',
    'browseMenuForPos.column.description.label': 'Descrição',
    'browseMenuForPos.column.price.label': 'Preço',
    'browseMenuForPos.column.status.label': 'Status',
    'browseMenuForPos.column.createdAt.label': 'Criado em',
    'browseMenuForPos.column.updatedAt.label': 'Atualizado em',
    'browseMenuForPos.toolbar.search.label': 'Buscar',
};
const message_en = {
    'browseMenuForPos.page.title': 'Browse menu at POS',
    'browseMenuForPos.section.menu.title': 'Browse menu at POS',
    'browseMenuForPos.organism.menu.title': 'POS Menu',
    'browseMenuForPos.intent.list.title': 'Menu items',
    'browseMenuForPos.filter.menuItemId.label': 'Item ID',
    'browseMenuForPos.filter.menuCategoryId.label': 'Category ID',
    'browseMenuForPos.filter.name.label': 'Item name',
    'browseMenuForPos.filter.status.label': 'Status',
    'browseMenuForPos.filter.createdAt.label': 'Created at',
    'browseMenuForPos.filter.updatedAt.label': 'Updated at',
    'browseMenuForPos.column.menuItemId.label': 'Item ID',
    'browseMenuForPos.column.menuCategoryId.label': 'Category ID',
    'browseMenuForPos.column.name.label': 'Name',
    'browseMenuForPos.column.description.label': 'Description',
    'browseMenuForPos.column.price.label': 'Price',
    'browseMenuForPos.column.status.label': 'Status',
    'browseMenuForPos.column.createdAt.label': 'Created at',
    'browseMenuForPos.column.updatedAt.label': 'Updated at',
    'browseMenuForPos.toolbar.search.label': 'Search',
};
export class CafeFlowBrowseMenuForPosBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.browseMenuForPosState = 'idle';
        this.browseMenuForPosMenuItemId = '';
        this.browseMenuForPosMenuCategoryId = '';
        this.browseMenuForPosName = '';
        this.browseMenuForPosStatus = '';
        this.browseMenuForPosCreatedAt = '';
        this.browseMenuForPosUpdatedAt = '';
        this.browseMenuForPosData = [];
        this.handleBrowseMenuForPosClick = (event) => {
            event.preventDefault();
            runBlockingUiAction(async () => {
                await this.loadBrowseMenuForPos();
            });
        };
        this.handleBrowseMenuForPosMenuItemIdChange = (event) => {
            const target = event.target;
            this.setBrowseMenuForPosMenuItemId(target.value);
        };
        this.handleBrowseMenuForPosMenuCategoryIdChange = (event) => {
            const target = event.target;
            this.setBrowseMenuForPosMenuCategoryId(target.value);
        };
        this.handleBrowseMenuForPosNameChange = (event) => {
            const target = event.target;
            this.setBrowseMenuForPosName(target.value);
        };
        this.handleBrowseMenuForPosStatusChange = (event) => {
            const target = event.target;
            this.setBrowseMenuForPosStatus(target.value);
        };
        this.handleBrowseMenuForPosCreatedAtChange = (event) => {
            const target = event.target;
            this.setBrowseMenuForPosCreatedAt(target.value);
        };
        this.handleBrowseMenuForPosUpdatedAtChange = (event) => {
            const target = event.target;
            this.setBrowseMenuForPosUpdatedAt(target.value);
        };
    }
    get msg() {
        const lang = this.__lang ?? 'pt';
        return lang === 'en' ? message_en : message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        this.status = getState('ui.browseMenuForPos.status') ?? '';
        this.browseMenuForPosState =
            getState('ui.browseMenuForPos.action.browseMenuForPos.status') ??
                'idle';
        this.browseMenuForPosMenuItemId =
            getState('ui.browseMenuForPos.input.browseMenuForPos.menuItemId') ?? '';
        this.browseMenuForPosMenuCategoryId =
            getState('ui.browseMenuForPos.input.browseMenuForPos.menuCategoryId') ?? '';
        this.browseMenuForPosName = getState('ui.browseMenuForPos.input.browseMenuForPos.name') ?? '';
        this.browseMenuForPosStatus = getState('ui.browseMenuForPos.input.browseMenuForPos.status') ?? '';
        this.browseMenuForPosCreatedAt =
            getState('ui.browseMenuForPos.input.browseMenuForPos.createdAt') ?? '';
        this.browseMenuForPosUpdatedAt =
            getState('ui.browseMenuForPos.input.browseMenuForPos.updatedAt') ?? '';
        this.browseMenuForPosData =
            getState('ui.browseMenuForPos.data.browseMenuForPos') ?? [];
        this.loadBrowseMenuForPos();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
    // ── Query action: browseMenuForPos ──────────────────────────────────
    async loadBrowseMenuForPos() {
        this.browseMenuForPosState = 'loading';
        setState('ui.browseMenuForPos.action.browseMenuForPos.status', 'loading');
        this.requestUpdate();
        const params = {
            menuItemId: this.browseMenuForPosMenuItemId || undefined,
            menuCategoryId: this.browseMenuForPosMenuCategoryId || undefined,
            name: this.browseMenuForPosName || undefined,
            status: this.browseMenuForPosStatus || undefined,
            createdAt: this.browseMenuForPosCreatedAt || undefined,
            updatedAt: this.browseMenuForPosUpdatedAt || undefined,
        };
        const options = { mode: 'silent' };
        try {
            const response = await execBff('cafeFlow.browseMenuForPos.browseMenuForPos', params, options);
            if (response.ok) {
                const data = response.data ?? [];
                this.browseMenuForPosData = data;
                setState('ui.browseMenuForPos.data.browseMenuForPos', data);
                this.browseMenuForPosState = 'success';
                setState('ui.browseMenuForPos.action.browseMenuForPos.status', 'success');
            }
            else {
                this.browseMenuForPosState = 'error';
                setState('ui.browseMenuForPos.action.browseMenuForPos.status', 'error');
            }
        }
        catch {
            this.browseMenuForPosState = 'error';
            setState('ui.browseMenuForPos.action.browseMenuForPos.status', 'error');
        }
        this.requestUpdate();
    }
    // ── State setters ───────────────────────────────────────────────────
    setBrowseMenuForPosMenuItemId(value) {
        this.browseMenuForPosMenuItemId = value;
        setState('ui.browseMenuForPos.input.browseMenuForPos.menuItemId', value);
        this.requestUpdate();
    }
    setBrowseMenuForPosMenuCategoryId(value) {
        this.browseMenuForPosMenuCategoryId = value;
        setState('ui.browseMenuForPos.input.browseMenuForPos.menuCategoryId', value);
        this.requestUpdate();
    }
    setBrowseMenuForPosName(value) {
        this.browseMenuForPosName = value;
        setState('ui.browseMenuForPos.input.browseMenuForPos.name', value);
        this.requestUpdate();
    }
    setBrowseMenuForPosStatus(value) {
        this.browseMenuForPosStatus = value;
        setState('ui.browseMenuForPos.input.browseMenuForPos.status', value);
        this.requestUpdate();
    }
    setBrowseMenuForPosCreatedAt(value) {
        this.browseMenuForPosCreatedAt = value;
        setState('ui.browseMenuForPos.input.browseMenuForPos.createdAt', value);
        this.requestUpdate();
    }
    setBrowseMenuForPosUpdatedAt(value) {
        this.browseMenuForPosUpdatedAt = value;
        setState('ui.browseMenuForPos.input.browseMenuForPos.updatedAt', value);
        this.requestUpdate();
    }
}
__decorate([
    property({ type: String })
], CafeFlowBrowseMenuForPosBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowBrowseMenuForPosBase.prototype, "browseMenuForPosState", void 0);
__decorate([
    property({ type: String })
], CafeFlowBrowseMenuForPosBase.prototype, "browseMenuForPosMenuItemId", void 0);
__decorate([
    property({ type: String })
], CafeFlowBrowseMenuForPosBase.prototype, "browseMenuForPosMenuCategoryId", void 0);
__decorate([
    property({ type: String })
], CafeFlowBrowseMenuForPosBase.prototype, "browseMenuForPosName", void 0);
__decorate([
    property({ type: String })
], CafeFlowBrowseMenuForPosBase.prototype, "browseMenuForPosStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowBrowseMenuForPosBase.prototype, "browseMenuForPosCreatedAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowBrowseMenuForPosBase.prototype, "browseMenuForPosUpdatedAt", void 0);
__decorate([
    property({ type: Array })
], CafeFlowBrowseMenuForPosBase.prototype, "browseMenuForPosData", void 0);
