/// <mls fileReference="_102050_/l2/cafeFlow/web/shared/aiSalesSummary.ts" enhancement="_blank"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
const message_pt = {
    'aiSalesSummary.section.main.title': 'Assistente IA: resumo de vendas do dia',
    'aiSalesSummary.organism.main.title': 'Resumo de vendas por IA',
    'aiSalesSummary.intent.filters.title': 'Filtros do resumo',
    'aiSalesSummary.intent.results.title': 'Resultados do resumo',
    'aiSalesSummary.field.dailyShiftId.label': 'Turno diário',
    'aiSalesSummary.field.status.label': 'Status do pedido',
    'aiSalesSummary.field.closedAt.label': 'Data de fechamento',
    'aiSalesSummary.action.run.label': 'Gerar resumo',
    'aiSalesSummary.col.dailyShiftId.label': 'Turno diário',
    'aiSalesSummary.col.status.label': 'Status',
    'aiSalesSummary.col.totalAmount.label': 'Total',
    'aiSalesSummary.col.closedAt.label': 'Fechado em',
};
const message_en = {
    'aiSalesSummary.section.main.title': 'AI Assistant: daily sales summary',
    'aiSalesSummary.organism.main.title': 'AI sales summary',
    'aiSalesSummary.intent.filters.title': 'Summary filters',
    'aiSalesSummary.intent.results.title': 'Summary results',
    'aiSalesSummary.field.dailyShiftId.label': 'Daily shift',
    'aiSalesSummary.field.status.label': 'Order status',
    'aiSalesSummary.field.closedAt.label': 'Closing date',
    'aiSalesSummary.action.run.label': 'Generate summary',
    'aiSalesSummary.col.dailyShiftId.label': 'Daily shift',
    'aiSalesSummary.col.status.label': 'Status',
    'aiSalesSummary.col.totalAmount.label': 'Total',
    'aiSalesSummary.col.closedAt.label': 'Closed at',
};
export class CafeFlowAiSalesSummaryBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.aiSalesSummaryState = 'idle';
        this.aiSalesSummaryDailyShiftId = '';
        this.aiSalesSummaryStatus = '';
        this.aiSalesSummaryClosedAt = '';
        this.aiSalesSummaryData = [];
        this.handleAiSalesSummaryClick = () => {
            runBlockingUiAction(async () => {
                await this.loadAiSalesSummary();
            });
        };
        this.handleAiSalesSummaryDailyShiftIdChange = (e) => {
            const target = e.target;
            this.setAiSalesSummaryDailyShiftId(target.value);
        };
        this.handleAiSalesSummaryStatusChange = (e) => {
            const target = e.target;
            this.setAiSalesSummaryStatus(target.value);
        };
        this.handleAiSalesSummaryClosedAtChange = (e) => {
            const target = e.target;
            this.setAiSalesSummaryClosedAt(target.value);
        };
    }
    get msg() {
        const lang = this.__lang ?? 'pt';
        return lang === 'en' ? message_en : message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        this.status = getState('ui.aiSalesSummary.status') ?? '';
        this.aiSalesSummaryState = getState('ui.aiSalesSummary.action.aiSalesSummary.status') ?? 'idle';
        this.aiSalesSummaryDailyShiftId = getState('ui.aiSalesSummary.input.aiSalesSummary.dailyShiftId') ?? '';
        this.aiSalesSummaryStatus = getState('ui.aiSalesSummary.input.aiSalesSummary.status') ?? '';
        this.aiSalesSummaryClosedAt = getState('ui.aiSalesSummary.input.aiSalesSummary.closedAt') ?? '';
        this.aiSalesSummaryData = getState('ui.aiSalesSummary.data.aiSalesSummary') ?? [];
        this.loadAiSalesSummary();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
    // ── Query: aiSalesSummary ──────────────────────────────────────────
    async loadAiSalesSummary() {
        this.aiSalesSummaryState = 'loading';
        setState('ui.aiSalesSummary.action.aiSalesSummary.status', 'loading');
        this.requestUpdate();
        const params = {
            dailyShiftId: this.aiSalesSummaryDailyShiftId || undefined,
            status: this.aiSalesSummaryStatus || undefined,
            closedAt: this.aiSalesSummaryClosedAt || undefined,
        };
        const options = { mode: 'silent' };
        try {
            const response = await execBff('cafeFlow.aiSalesSummary.aiSalesSummary', params, options);
            if (response.ok) {
                this.aiSalesSummaryData = response.data ?? [];
                setState('ui.aiSalesSummary.data.aiSalesSummary', this.aiSalesSummaryData);
                this.aiSalesSummaryState = 'success';
                setState('ui.aiSalesSummary.action.aiSalesSummary.status', 'success');
            }
            else {
                this.aiSalesSummaryState = 'error';
                setState('ui.aiSalesSummary.action.aiSalesSummary.status', 'error');
            }
        }
        catch {
            this.aiSalesSummaryState = 'error';
            setState('ui.aiSalesSummary.action.aiSalesSummary.status', 'error');
        }
        this.requestUpdate();
    }
    // ── State setters ──────────────────────────────────────────────────
    setAiSalesSummaryDailyShiftId(value) {
        this.aiSalesSummaryDailyShiftId = value;
        setState('ui.aiSalesSummary.input.aiSalesSummary.dailyShiftId', value);
        this.requestUpdate();
    }
    setAiSalesSummaryStatus(value) {
        this.aiSalesSummaryStatus = value;
        setState('ui.aiSalesSummary.input.aiSalesSummary.status', value);
        this.requestUpdate();
    }
    setAiSalesSummaryClosedAt(value) {
        this.aiSalesSummaryClosedAt = value;
        setState('ui.aiSalesSummary.input.aiSalesSummary.closedAt', value);
        this.requestUpdate();
    }
}
__decorate([
    property()
], CafeFlowAiSalesSummaryBase.prototype, "status", void 0);
__decorate([
    property()
], CafeFlowAiSalesSummaryBase.prototype, "aiSalesSummaryState", void 0);
__decorate([
    property()
], CafeFlowAiSalesSummaryBase.prototype, "aiSalesSummaryDailyShiftId", void 0);
__decorate([
    property()
], CafeFlowAiSalesSummaryBase.prototype, "aiSalesSummaryStatus", void 0);
__decorate([
    property()
], CafeFlowAiSalesSummaryBase.prototype, "aiSalesSummaryClosedAt", void 0);
__decorate([
    property()
], CafeFlowAiSalesSummaryBase.prototype, "aiSalesSummaryData", void 0);
