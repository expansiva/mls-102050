/// <mls fileReference="_102050_/l2/cafeFlow/web/shared/manageTables.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "manageTables.section.title": "Gerenciar mesas",
    "manageTables.organism.title": "Gerenciar mesas",
    "manageTables.form.title": "Dados da mesa",
    "manageTables.field.tableId": "ID da mesa",
    "manageTables.field.number": "Número da mesa",
    "manageTables.field.status": "Situação",
    "manageTables.action.submit": "Salvar mesas",
    "manageTables.status.title": "Status da operação"
};
const message_en = {
    "manageTables.section.title": "Manage tables",
    "manageTables.organism.title": "Manage tables",
    "manageTables.form.title": "Table data",
    "manageTables.field.tableId": "Table ID",
    "manageTables.field.number": "Table number",
    "manageTables.field.status": "Status",
    "manageTables.action.submit": "Save tables",
    "manageTables.status.title": "Operation status"
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowManageTablesBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.manageTablesState = 'idle';
        this.manageTablesTableId = '';
        this.manageTablesNumber = '';
        this.manageTablesStatus = '';
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || messages['en'];
    }
    connectedCallback() {
        super.connectedCallback();
        this.status = getState('ui.manageTables.status') ?? '';
        this.manageTablesState = getState('ui.manageTables.action.manageTables.status') ?? 'idle';
        this.manageTablesTableId = getState('ui.manageTables.input.manageTables.tableId') ?? '';
        this.manageTablesNumber = getState('ui.manageTables.input.manageTables.number') ?? '';
        this.manageTablesStatus = getState('ui.manageTables.input.manageTables.status') ?? '';
        subscribe([
            'ui.manageTables.status',
            'ui.manageTables.action.manageTables.status',
            'ui.manageTables.input.manageTables.tableId',
            'ui.manageTables.input.manageTables.number',
            'ui.manageTables.input.manageTables.status'
        ], this);
    }
    disconnectedCallback() {
        unsubscribe([
            'ui.manageTables.status',
            'ui.manageTables.action.manageTables.status',
            'ui.manageTables.input.manageTables.tableId',
            'ui.manageTables.input.manageTables.number',
            'ui.manageTables.input.manageTables.status'
        ], this);
        super.disconnectedCallback();
    }
    stateChanged(stateKey, value) {
        switch (stateKey) {
            case 'ui.manageTables.status':
                this.status = value;
                break;
            case 'ui.manageTables.action.manageTables.status':
                this.manageTablesState = value;
                break;
            case 'ui.manageTables.input.manageTables.tableId':
                this.manageTablesTableId = value;
                break;
            case 'ui.manageTables.input.manageTables.number':
                this.manageTablesNumber = value;
                break;
            case 'ui.manageTables.input.manageTables.status':
                this.manageTablesStatus = value;
                break;
            default:
                break;
        }
    }
    setManageTablesTableId(value) {
        this.manageTablesTableId = value;
        setState('ui.manageTables.input.manageTables.tableId', value);
        this.requestUpdate();
    }
    handleManageTablesTableIdChange(event) {
        const target = event.target;
        this.setManageTablesTableId(target?.value ?? '');
    }
    setManageTablesNumber(value) {
        this.manageTablesNumber = value;
        setState('ui.manageTables.input.manageTables.number', value);
        this.requestUpdate();
    }
    handleManageTablesNumberChange(event) {
        const target = event.target;
        this.setManageTablesNumber(target?.value ?? '');
    }
    setManageTablesStatus(value) {
        this.manageTablesStatus = value;
        setState('ui.manageTables.input.manageTables.status', value);
        this.requestUpdate();
    }
    handleManageTablesStatusChange(event) {
        const target = event.target;
        this.setManageTablesStatus(target?.value ?? '');
    }
    async manageTables() {
        setState('ui.manageTables.action.manageTables.status', 'loading');
        const params = {
            tableId: this.manageTablesTableId || undefined,
            number: this.manageTablesNumber,
            status: (this.manageTablesStatus || 'available')
        };
        const options = { mode: 'blocking' };
        try {
            const response = await execBff('cafeFlow.manageTables.manageTables', params, options);
            if (!response.ok) {
                setState('ui.manageTables.action.manageTables.status', 'error');
                return;
            }
            setState('ui.manageTables.action.manageTables.status', 'success');
        }
        catch (error) {
            setState('ui.manageTables.action.manageTables.status', 'error');
        }
    }
    async handleManageTablesClick() {
        await runBlockingUiAction(async () => {
            await this.manageTables();
        });
    }
}
__decorate([
    property()
], CafeFlowManageTablesBase.prototype, "status", void 0);
__decorate([
    property()
], CafeFlowManageTablesBase.prototype, "manageTablesState", void 0);
__decorate([
    property()
], CafeFlowManageTablesBase.prototype, "manageTablesTableId", void 0);
__decorate([
    property()
], CafeFlowManageTablesBase.prototype, "manageTablesNumber", void 0);
__decorate([
    property()
], CafeFlowManageTablesBase.prototype, "manageTablesStatus", void 0);
