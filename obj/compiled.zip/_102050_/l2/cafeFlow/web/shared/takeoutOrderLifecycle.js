/// <mls fileReference="_102050_/l2/cafeFlow/web/shared/takeoutOrderLifecycle.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    'takeoutOrderLifecycle.section.main.title': 'Ciclo de pedido (takeout)',
    'takeoutOrderLifecycle.organism.createOrder.title': 'Criar pedido',
    'takeoutOrderLifecycle.organism.addOrderItem.title': 'Adicionar item ao pedido',
    'takeoutOrderLifecycle.organism.createKitchenTicket.title': 'Criar ticket de cozinha',
    'takeoutOrderLifecycle.organism.updateOrderStatus.title': 'Atualizar status do pedido',
    'takeoutOrderLifecycle.organism.review.title': 'Revisão',
    'takeoutOrderLifecycle.intention.createOrder.title': 'Criar pedido',
    'takeoutOrderLifecycle.intention.addOrderItem.title': 'Adicionar item ao pedido',
    'takeoutOrderLifecycle.intention.createKitchenTicket.title': 'Criar ticket de cozinha',
    'takeoutOrderLifecycle.intention.updateOrderStatus.title': 'Atualizar status do pedido',
    'takeoutOrderLifecycle.intention.review.title': 'Resumo do ciclo do pedido',
    'takeoutOrderLifecycle.field.createOrder.orderType': 'Tipo do pedido',
    'takeoutOrderLifecycle.field.createOrder.status': 'Status do pedido',
    'takeoutOrderLifecycle.field.createOrder.totalAmount': 'Valor total',
    'takeoutOrderLifecycle.field.createOrder.notes': 'Observações',
    'takeoutOrderLifecycle.field.createOrder.customerName': 'Nome do cliente',
    'takeoutOrderLifecycle.field.createOrder.customerPhone': 'Telefone do cliente',
    'takeoutOrderLifecycle.field.createOrder.numberOfGuests': 'Número de pessoas',
    'takeoutOrderLifecycle.field.createOrder.closedAt': 'Fechado em',
    'takeoutOrderLifecycle.field.createOrder.cancelledAt': 'Cancelado em',
    'takeoutOrderLifecycle.field.createOrder.cancellationReason': 'Motivo do cancelamento',
    'takeoutOrderLifecycle.action.createOrder.submit': 'Criar pedido',
    'takeoutOrderLifecycle.field.addOrderItem.quantity': 'Quantidade',
    'takeoutOrderLifecycle.field.addOrderItem.unitPrice': 'Preço unitário',
    'takeoutOrderLifecycle.field.addOrderItem.totalPrice': 'Preço total',
    'takeoutOrderLifecycle.field.addOrderItem.observations': 'Observações do item',
    'takeoutOrderLifecycle.field.addOrderItem.status': 'Status do item',
    'takeoutOrderLifecycle.action.addOrderItem.submit': 'Adicionar item',
    'takeoutOrderLifecycle.field.createKitchenTicket.status': 'Status do ticket',
    'takeoutOrderLifecycle.action.createKitchenTicket.submit': 'Criar ticket',
    'takeoutOrderLifecycle.field.updateOrderStatus.status': 'Status do pedido',
    'takeoutOrderLifecycle.field.updateOrderStatus.closedAt': 'Fechado em',
    'takeoutOrderLifecycle.field.updateOrderStatus.cancelledAt': 'Cancelado em',
    'takeoutOrderLifecycle.field.updateOrderStatus.cancellationReason': 'Motivo do cancelamento',
    'takeoutOrderLifecycle.action.updateOrderStatus.submit': 'Atualizar status',
};
const message_en = {
    'takeoutOrderLifecycle.section.main.title': 'Takeout order lifecycle',
    'takeoutOrderLifecycle.organism.createOrder.title': 'Create order',
    'takeoutOrderLifecycle.organism.addOrderItem.title': 'Add order item',
    'takeoutOrderLifecycle.organism.createKitchenTicket.title': 'Create kitchen ticket',
    'takeoutOrderLifecycle.organism.updateOrderStatus.title': 'Update order status',
    'takeoutOrderLifecycle.organism.review.title': 'Review',
    'takeoutOrderLifecycle.intention.createOrder.title': 'Create order',
    'takeoutOrderLifecycle.intention.addOrderItem.title': 'Add order item',
    'takeoutOrderLifecycle.intention.createKitchenTicket.title': 'Create kitchen ticket',
    'takeoutOrderLifecycle.intention.updateOrderStatus.title': 'Update order status',
    'takeoutOrderLifecycle.intention.review.title': 'Order lifecycle summary',
    'takeoutOrderLifecycle.field.createOrder.orderType': 'Order type',
    'takeoutOrderLifecycle.field.createOrder.status': 'Order status',
    'takeoutOrderLifecycle.field.createOrder.totalAmount': 'Total amount',
    'takeoutOrderLifecycle.field.createOrder.notes': 'Notes',
    'takeoutOrderLifecycle.field.createOrder.customerName': 'Customer name',
    'takeoutOrderLifecycle.field.createOrder.customerPhone': 'Customer phone',
    'takeoutOrderLifecycle.field.createOrder.numberOfGuests': 'Number of guests',
    'takeoutOrderLifecycle.field.createOrder.closedAt': 'Closed at',
    'takeoutOrderLifecycle.field.createOrder.cancelledAt': 'Cancelled at',
    'takeoutOrderLifecycle.field.createOrder.cancellationReason': 'Cancellation reason',
    'takeoutOrderLifecycle.action.createOrder.submit': 'Create order',
    'takeoutOrderLifecycle.field.addOrderItem.quantity': 'Quantity',
    'takeoutOrderLifecycle.field.addOrderItem.unitPrice': 'Unit price',
    'takeoutOrderLifecycle.field.addOrderItem.totalPrice': 'Total price',
    'takeoutOrderLifecycle.field.addOrderItem.observations': 'Item notes',
    'takeoutOrderLifecycle.field.addOrderItem.status': 'Item status',
    'takeoutOrderLifecycle.action.addOrderItem.submit': 'Add item',
    'takeoutOrderLifecycle.field.createKitchenTicket.status': 'Ticket status',
    'takeoutOrderLifecycle.action.createKitchenTicket.submit': 'Create ticket',
    'takeoutOrderLifecycle.field.updateOrderStatus.status': 'Order status',
    'takeoutOrderLifecycle.field.updateOrderStatus.closedAt': 'Closed at',
    'takeoutOrderLifecycle.field.updateOrderStatus.cancelledAt': 'Cancelled at',
    'takeoutOrderLifecycle.field.updateOrderStatus.cancellationReason': 'Cancellation reason',
    'takeoutOrderLifecycle.action.updateOrderStatus.submit': 'Update status',
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowTakeoutOrderLifecycleBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.createOrderState = 'idle';
        this.createOrderOrderType = '';
        this.createOrderStatus = '';
        this.createOrderTotalAmount = '';
        this.createOrderNotes = '';
        this.createOrderCustomerName = '';
        this.createOrderCustomerPhone = '';
        this.createOrderNumberOfGuests = '';
        this.createOrderClosedAt = '';
        this.createOrderCancelledAt = '';
        this.createOrderCancellationReason = '';
        this.addOrderItemState = 'idle';
        this.addOrderItemQuantity = '';
        this.addOrderItemUnitPrice = '';
        this.addOrderItemTotalPrice = '';
        this.addOrderItemObservations = '';
        this.addOrderItemStatus = '';
        this.createKitchenTicketState = 'idle';
        this.createKitchenTicketStatus = '';
        this.updateOrderStatusState = 'idle';
        this.updateOrderStatusStatus = '';
        this.updateOrderStatusClosedAt = '';
        this.updateOrderStatusCancelledAt = '';
        this.updateOrderStatusCancellationReason = '';
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || messages['en'];
    }
    connectedCallback() {
        super.connectedCallback();
        const status = getState('ui.takeoutOrderLifecycle.status');
        this.status = (status !== undefined ? status : '');
        const createOrderState = getState('ui.takeoutOrderLifecycle.action.createOrder.status');
        this.createOrderState =
            (createOrderState !== undefined
                ? createOrderState
                : 'idle');
        const createOrderOrderType = getState('ui.takeoutOrderLifecycle.input.createOrder.orderType');
        this.createOrderOrderType = (createOrderOrderType !== undefined
            ? createOrderOrderType
            : '');
        const createOrderStatus = getState('ui.takeoutOrderLifecycle.input.createOrder.status');
        this.createOrderStatus = (createOrderStatus !== undefined
            ? createOrderStatus
            : '');
        const createOrderTotalAmount = getState('ui.takeoutOrderLifecycle.input.createOrder.totalAmount');
        this.createOrderTotalAmount =
            (createOrderTotalAmount !== undefined
                ? createOrderTotalAmount
                : '');
        const createOrderNotes = getState('ui.takeoutOrderLifecycle.input.createOrder.notes');
        this.createOrderNotes = (createOrderNotes !== undefined ? createOrderNotes : '');
        const createOrderCustomerName = getState('ui.takeoutOrderLifecycle.input.createOrder.customerName');
        this.createOrderCustomerName =
            (createOrderCustomerName !== undefined ? createOrderCustomerName : '');
        const createOrderCustomerPhone = getState('ui.takeoutOrderLifecycle.input.createOrder.customerPhone');
        this.createOrderCustomerPhone =
            (createOrderCustomerPhone !== undefined ? createOrderCustomerPhone : '');
        const createOrderNumberOfGuests = getState('ui.takeoutOrderLifecycle.input.createOrder.numberOfGuests');
        this.createOrderNumberOfGuests =
            (createOrderNumberOfGuests !== undefined
                ? createOrderNumberOfGuests
                : '');
        const createOrderClosedAt = getState('ui.takeoutOrderLifecycle.input.createOrder.closedAt');
        this.createOrderClosedAt = (createOrderClosedAt !== undefined ? createOrderClosedAt : '');
        const createOrderCancelledAt = getState('ui.takeoutOrderLifecycle.input.createOrder.cancelledAt');
        this.createOrderCancelledAt =
            (createOrderCancelledAt !== undefined ? createOrderCancelledAt : '');
        const createOrderCancellationReason = getState('ui.takeoutOrderLifecycle.input.createOrder.cancellationReason');
        this.createOrderCancellationReason =
            (createOrderCancellationReason !== undefined ? createOrderCancellationReason : '');
        const addOrderItemState = getState('ui.takeoutOrderLifecycle.action.addOrderItem.status');
        this.addOrderItemState =
            (addOrderItemState !== undefined
                ? addOrderItemState
                : 'idle');
        const addOrderItemQuantity = getState('ui.takeoutOrderLifecycle.input.addOrderItem.quantity');
        this.addOrderItemQuantity =
            (addOrderItemQuantity !== undefined
                ? addOrderItemQuantity
                : '');
        const addOrderItemUnitPrice = getState('ui.takeoutOrderLifecycle.input.addOrderItem.unitPrice');
        this.addOrderItemUnitPrice =
            (addOrderItemUnitPrice !== undefined
                ? addOrderItemUnitPrice
                : '');
        const addOrderItemTotalPrice = getState('ui.takeoutOrderLifecycle.input.addOrderItem.totalPrice');
        this.addOrderItemTotalPrice =
            (addOrderItemTotalPrice !== undefined
                ? addOrderItemTotalPrice
                : '');
        const addOrderItemObservations = getState('ui.takeoutOrderLifecycle.input.addOrderItem.observations');
        this.addOrderItemObservations =
            (addOrderItemObservations !== undefined ? addOrderItemObservations : '');
        const addOrderItemStatus = getState('ui.takeoutOrderLifecycle.input.addOrderItem.status');
        this.addOrderItemStatus = (addOrderItemStatus !== undefined
            ? addOrderItemStatus
            : '');
        const createKitchenTicketState = getState('ui.takeoutOrderLifecycle.action.createKitchenTicket.status');
        this.createKitchenTicketState =
            (createKitchenTicketState !== undefined
                ? createKitchenTicketState
                : 'idle');
        const createKitchenTicketStatus = getState('ui.takeoutOrderLifecycle.input.createKitchenTicket.status');
        this.createKitchenTicketStatus = (createKitchenTicketStatus !== undefined
            ? createKitchenTicketStatus
            : '');
        const updateOrderStatusState = getState('ui.takeoutOrderLifecycle.action.updateOrderStatus.status');
        this.updateOrderStatusState =
            (updateOrderStatusState !== undefined
                ? updateOrderStatusState
                : 'idle');
        const updateOrderStatusStatus = getState('ui.takeoutOrderLifecycle.input.updateOrderStatus.status');
        this.updateOrderStatusStatus = (updateOrderStatusStatus !== undefined
            ? updateOrderStatusStatus
            : '');
        const updateOrderStatusClosedAt = getState('ui.takeoutOrderLifecycle.input.updateOrderStatus.closedAt');
        this.updateOrderStatusClosedAt =
            (updateOrderStatusClosedAt !== undefined ? updateOrderStatusClosedAt : '');
        const updateOrderStatusCancelledAt = getState('ui.takeoutOrderLifecycle.input.updateOrderStatus.cancelledAt');
        this.updateOrderStatusCancelledAt =
            (updateOrderStatusCancelledAt !== undefined ? updateOrderStatusCancelledAt : '');
        const updateOrderStatusCancellationReason = getState('ui.takeoutOrderLifecycle.input.updateOrderStatus.cancellationReason');
        this.updateOrderStatusCancellationReason =
            (updateOrderStatusCancellationReason !== undefined
                ? updateOrderStatusCancellationReason
                : '');
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
    setCreateOrderOrderType(value) {
        this.createOrderOrderType = value;
        setState('ui.takeoutOrderLifecycle.input.createOrder.orderType', value);
        this.requestUpdate();
    }
    handleCreateOrderOrderTypeChange(event) {
        const value = event.target.value;
        this.setCreateOrderOrderType(value);
    }
    setCreateOrderStatus(value) {
        this.createOrderStatus = value;
        setState('ui.takeoutOrderLifecycle.input.createOrder.status', value);
        this.requestUpdate();
    }
    handleCreateOrderStatusChange(event) {
        const value = event.target.value;
        this.setCreateOrderStatus(value);
    }
    setCreateOrderTotalAmount(value) {
        this.createOrderTotalAmount = value;
        setState('ui.takeoutOrderLifecycle.input.createOrder.totalAmount', value);
        this.requestUpdate();
    }
    handleCreateOrderTotalAmountChange(event) {
        const value = Number(event.target.value);
        this.setCreateOrderTotalAmount(value);
    }
    setCreateOrderNotes(value) {
        this.createOrderNotes = value;
        setState('ui.takeoutOrderLifecycle.input.createOrder.notes', value);
        this.requestUpdate();
    }
    handleCreateOrderNotesChange(event) {
        const value = event.target.value;
        this.setCreateOrderNotes(value);
    }
    setCreateOrderCustomerName(value) {
        this.createOrderCustomerName = value;
        setState('ui.takeoutOrderLifecycle.input.createOrder.customerName', value);
        this.requestUpdate();
    }
    handleCreateOrderCustomerNameChange(event) {
        const value = event.target.value;
        this.setCreateOrderCustomerName(value);
    }
    setCreateOrderCustomerPhone(value) {
        this.createOrderCustomerPhone = value;
        setState('ui.takeoutOrderLifecycle.input.createOrder.customerPhone', value);
        this.requestUpdate();
    }
    handleCreateOrderCustomerPhoneChange(event) {
        const value = event.target.value;
        this.setCreateOrderCustomerPhone(value);
    }
    setCreateOrderNumberOfGuests(value) {
        this.createOrderNumberOfGuests = value;
        setState('ui.takeoutOrderLifecycle.input.createOrder.numberOfGuests', value);
        this.requestUpdate();
    }
    handleCreateOrderNumberOfGuestsChange(event) {
        const value = Number(event.target.value);
        this.setCreateOrderNumberOfGuests(value);
    }
    setCreateOrderClosedAt(value) {
        this.createOrderClosedAt = value;
        setState('ui.takeoutOrderLifecycle.input.createOrder.closedAt', value);
        this.requestUpdate();
    }
    handleCreateOrderClosedAtChange(event) {
        const value = event.target.value;
        this.setCreateOrderClosedAt(value);
    }
    setCreateOrderCancelledAt(value) {
        this.createOrderCancelledAt = value;
        setState('ui.takeoutOrderLifecycle.input.createOrder.cancelledAt', value);
        this.requestUpdate();
    }
    handleCreateOrderCancelledAtChange(event) {
        const value = event.target.value;
        this.setCreateOrderCancelledAt(value);
    }
    setCreateOrderCancellationReason(value) {
        this.createOrderCancellationReason = value;
        setState('ui.takeoutOrderLifecycle.input.createOrder.cancellationReason', value);
        this.requestUpdate();
    }
    handleCreateOrderCancellationReasonChange(event) {
        const value = event.target.value;
        this.setCreateOrderCancellationReason(value);
    }
    setAddOrderItemQuantity(value) {
        this.addOrderItemQuantity = value;
        setState('ui.takeoutOrderLifecycle.input.addOrderItem.quantity', value);
        this.requestUpdate();
    }
    handleAddOrderItemQuantityChange(event) {
        const value = Number(event.target.value);
        this.setAddOrderItemQuantity(value);
    }
    setAddOrderItemUnitPrice(value) {
        this.addOrderItemUnitPrice = value;
        setState('ui.takeoutOrderLifecycle.input.addOrderItem.unitPrice', value);
        this.requestUpdate();
    }
    handleAddOrderItemUnitPriceChange(event) {
        const value = Number(event.target.value);
        this.setAddOrderItemUnitPrice(value);
    }
    setAddOrderItemTotalPrice(value) {
        this.addOrderItemTotalPrice = value;
        setState('ui.takeoutOrderLifecycle.input.addOrderItem.totalPrice', value);
        this.requestUpdate();
    }
    handleAddOrderItemTotalPriceChange(event) {
        const value = Number(event.target.value);
        this.setAddOrderItemTotalPrice(value);
    }
    setAddOrderItemObservations(value) {
        this.addOrderItemObservations = value;
        setState('ui.takeoutOrderLifecycle.input.addOrderItem.observations', value);
        this.requestUpdate();
    }
    handleAddOrderItemObservationsChange(event) {
        const value = event.target.value;
        this.setAddOrderItemObservations(value);
    }
    setAddOrderItemStatus(value) {
        this.addOrderItemStatus = value;
        setState('ui.takeoutOrderLifecycle.input.addOrderItem.status', value);
        this.requestUpdate();
    }
    handleAddOrderItemStatusChange(event) {
        const value = event.target.value;
        this.setAddOrderItemStatus(value);
    }
    setCreateKitchenTicketStatus(value) {
        this.createKitchenTicketStatus = value;
        setState('ui.takeoutOrderLifecycle.input.createKitchenTicket.status', value);
        this.requestUpdate();
    }
    handleCreateKitchenTicketStatusChange(event) {
        const value = event.target.value;
        this.setCreateKitchenTicketStatus(value);
    }
    setUpdateOrderStatusStatus(value) {
        this.updateOrderStatusStatus = value;
        setState('ui.takeoutOrderLifecycle.input.updateOrderStatus.status', value);
        this.requestUpdate();
    }
    handleUpdateOrderStatusStatusChange(event) {
        const value = event.target.value;
        this.setUpdateOrderStatusStatus(value);
    }
    setUpdateOrderStatusClosedAt(value) {
        this.updateOrderStatusClosedAt = value;
        setState('ui.takeoutOrderLifecycle.input.updateOrderStatus.closedAt', value);
        this.requestUpdate();
    }
    handleUpdateOrderStatusClosedAtChange(event) {
        const value = event.target.value;
        this.setUpdateOrderStatusClosedAt(value);
    }
    setUpdateOrderStatusCancelledAt(value) {
        this.updateOrderStatusCancelledAt = value;
        setState('ui.takeoutOrderLifecycle.input.updateOrderStatus.cancelledAt', value);
        this.requestUpdate();
    }
    handleUpdateOrderStatusCancelledAtChange(event) {
        const value = event.target.value;
        this.setUpdateOrderStatusCancelledAt(value);
    }
    setUpdateOrderStatusCancellationReason(value) {
        this.updateOrderStatusCancellationReason = value;
        setState('ui.takeoutOrderLifecycle.input.updateOrderStatus.cancellationReason', value);
        this.requestUpdate();
    }
    handleUpdateOrderStatusCancellationReasonChange(event) {
        const value = event.target.value;
        this.setUpdateOrderStatusCancellationReason(value);
    }
    async createOrder() {
        this.createOrderState = 'loading';
        setState('ui.takeoutOrderLifecycle.action.createOrder.status', 'loading');
        const params = {
            orderType: this.createOrderOrderType,
            status: this.createOrderStatus,
            totalAmount: this.createOrderTotalAmount,
            notes: this.createOrderNotes,
            customerName: this.createOrderCustomerName,
            customerPhone: this.createOrderCustomerPhone,
            numberOfGuests: this.createOrderNumberOfGuests,
            closedAt: this.createOrderClosedAt,
            cancelledAt: this.createOrderCancelledAt,
            cancellationReason: this.createOrderCancellationReason,
        };
        try {
            const options = { mode: 'blocking' };
            const response = await execBff('cafeFlow.takeoutOrderLifecycle.createOrder', params, options);
            if (response.ok) {
                this.createOrderState = 'success';
                setState('ui.takeoutOrderLifecycle.action.createOrder.status', 'success');
                return;
            }
            this.createOrderState = 'error';
            setState('ui.takeoutOrderLifecycle.action.createOrder.status', 'error');
            throw new Error(response.error?.message || 'Failed to create order');
        }
        catch (error) {
            this.createOrderState = 'error';
            setState('ui.takeoutOrderLifecycle.action.createOrder.status', 'error');
            throw error;
        }
    }
    async handleCreateOrderClick() {
        await runBlockingUiAction(async () => {
            await this.createOrder();
        });
    }
    async addOrderItem() {
        this.addOrderItemState = 'loading';
        setState('ui.takeoutOrderLifecycle.action.addOrderItem.status', 'loading');
        const params = {
            quantity: this.addOrderItemQuantity,
            unitPrice: this.addOrderItemUnitPrice,
            totalPrice: this.addOrderItemTotalPrice,
            observations: this.addOrderItemObservations,
            status: this.addOrderItemStatus,
        };
        try {
            const options = { mode: 'blocking' };
            const response = await execBff('cafeFlow.takeoutOrderLifecycle.addOrderItem', params, options);
            if (response.ok) {
                this.addOrderItemState = 'success';
                setState('ui.takeoutOrderLifecycle.action.addOrderItem.status', 'success');
                return;
            }
            this.addOrderItemState = 'error';
            setState('ui.takeoutOrderLifecycle.action.addOrderItem.status', 'error');
            throw new Error(response.error?.message || 'Failed to add order item');
        }
        catch (error) {
            this.addOrderItemState = 'error';
            setState('ui.takeoutOrderLifecycle.action.addOrderItem.status', 'error');
            throw error;
        }
    }
    async handleAddOrderItemClick() {
        await runBlockingUiAction(async () => {
            await this.addOrderItem();
        });
    }
    async createKitchenTicket() {
        this.createKitchenTicketState = 'loading';
        setState('ui.takeoutOrderLifecycle.action.createKitchenTicket.status', 'loading');
        const params = {
            status: this.createKitchenTicketStatus,
        };
        try {
            const options = { mode: 'blocking' };
            const response = await execBff('cafeFlow.takeoutOrderLifecycle.createKitchenTicket', params, options);
            if (response.ok) {
                this.createKitchenTicketState = 'success';
                setState('ui.takeoutOrderLifecycle.action.createKitchenTicket.status', 'success');
                return;
            }
            this.createKitchenTicketState = 'error';
            setState('ui.takeoutOrderLifecycle.action.createKitchenTicket.status', 'error');
            throw new Error(response.error?.message || 'Failed to create kitchen ticket');
        }
        catch (error) {
            this.createKitchenTicketState = 'error';
            setState('ui.takeoutOrderLifecycle.action.createKitchenTicket.status', 'error');
            throw error;
        }
    }
    async handleCreateKitchenTicketClick() {
        await runBlockingUiAction(async () => {
            await this.createKitchenTicket();
        });
    }
    async updateOrderStatus() {
        this.updateOrderStatusState = 'loading';
        setState('ui.takeoutOrderLifecycle.action.updateOrderStatus.status', 'loading');
        const params = {
            status: this.updateOrderStatusStatus,
            closedAt: this.updateOrderStatusClosedAt,
            cancelledAt: this.updateOrderStatusCancelledAt,
            cancellationReason: this.updateOrderStatusCancellationReason,
        };
        try {
            const options = { mode: 'blocking' };
            const response = await execBff('cafeFlow.takeoutOrderLifecycle.updateOrderStatus', params, options);
            if (response.ok) {
                this.updateOrderStatusState = 'success';
                setState('ui.takeoutOrderLifecycle.action.updateOrderStatus.status', 'success');
                return;
            }
            this.updateOrderStatusState = 'error';
            setState('ui.takeoutOrderLifecycle.action.updateOrderStatus.status', 'error');
            throw new Error(response.error?.message || 'Failed to update order status');
        }
        catch (error) {
            this.updateOrderStatusState = 'error';
            setState('ui.takeoutOrderLifecycle.action.updateOrderStatus.status', 'error');
            throw error;
        }
    }
    async handleUpdateOrderStatusClick() {
        await runBlockingUiAction(async () => {
            await this.updateOrderStatus();
        });
    }
}
__decorate([
    property()
], CafeFlowTakeoutOrderLifecycleBase.prototype, "status", void 0);
__decorate([
    property()
], CafeFlowTakeoutOrderLifecycleBase.prototype, "createOrderState", void 0);
__decorate([
    property()
], CafeFlowTakeoutOrderLifecycleBase.prototype, "createOrderOrderType", void 0);
__decorate([
    property()
], CafeFlowTakeoutOrderLifecycleBase.prototype, "createOrderStatus", void 0);
__decorate([
    property()
], CafeFlowTakeoutOrderLifecycleBase.prototype, "createOrderTotalAmount", void 0);
__decorate([
    property()
], CafeFlowTakeoutOrderLifecycleBase.prototype, "createOrderNotes", void 0);
__decorate([
    property()
], CafeFlowTakeoutOrderLifecycleBase.prototype, "createOrderCustomerName", void 0);
__decorate([
    property()
], CafeFlowTakeoutOrderLifecycleBase.prototype, "createOrderCustomerPhone", void 0);
__decorate([
    property()
], CafeFlowTakeoutOrderLifecycleBase.prototype, "createOrderNumberOfGuests", void 0);
__decorate([
    property()
], CafeFlowTakeoutOrderLifecycleBase.prototype, "createOrderClosedAt", void 0);
__decorate([
    property()
], CafeFlowTakeoutOrderLifecycleBase.prototype, "createOrderCancelledAt", void 0);
__decorate([
    property()
], CafeFlowTakeoutOrderLifecycleBase.prototype, "createOrderCancellationReason", void 0);
__decorate([
    property()
], CafeFlowTakeoutOrderLifecycleBase.prototype, "addOrderItemState", void 0);
__decorate([
    property()
], CafeFlowTakeoutOrderLifecycleBase.prototype, "addOrderItemQuantity", void 0);
__decorate([
    property()
], CafeFlowTakeoutOrderLifecycleBase.prototype, "addOrderItemUnitPrice", void 0);
__decorate([
    property()
], CafeFlowTakeoutOrderLifecycleBase.prototype, "addOrderItemTotalPrice", void 0);
__decorate([
    property()
], CafeFlowTakeoutOrderLifecycleBase.prototype, "addOrderItemObservations", void 0);
__decorate([
    property()
], CafeFlowTakeoutOrderLifecycleBase.prototype, "addOrderItemStatus", void 0);
__decorate([
    property()
], CafeFlowTakeoutOrderLifecycleBase.prototype, "createKitchenTicketState", void 0);
__decorate([
    property()
], CafeFlowTakeoutOrderLifecycleBase.prototype, "createKitchenTicketStatus", void 0);
__decorate([
    property()
], CafeFlowTakeoutOrderLifecycleBase.prototype, "updateOrderStatusState", void 0);
__decorate([
    property()
], CafeFlowTakeoutOrderLifecycleBase.prototype, "updateOrderStatusStatus", void 0);
__decorate([
    property()
], CafeFlowTakeoutOrderLifecycleBase.prototype, "updateOrderStatusClosedAt", void 0);
__decorate([
    property()
], CafeFlowTakeoutOrderLifecycleBase.prototype, "updateOrderStatusCancelledAt", void 0);
__decorate([
    property()
], CafeFlowTakeoutOrderLifecycleBase.prototype, "updateOrderStatusCancellationReason", void 0);
