/// <mls fileReference="_102050_/l2/cafeFlow/web/shared/manageMenuCategories.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "manageMenuCategories.section.main.title": "Gerenciar categorias do cardápio",
    "manageMenuCategories.organism.form.title": "Gerenciar categorias",
    "manageMenuCategories.intention.commandForm.title": "Atualizar categoria do cardápio",
    "manageMenuCategories.field.menuCategoryId.label": "ID da categoria",
    "manageMenuCategories.field.name.label": "Nome",
    "manageMenuCategories.field.description.label": "Descrição",
    "manageMenuCategories.field.status.label": "Status",
    "manageMenuCategories.action.submit.label": "Salvar alterações"
};
const message_en = {
    "manageMenuCategories.section.main.title": "Manage menu categories",
    "manageMenuCategories.organism.form.title": "Manage categories",
    "manageMenuCategories.intention.commandForm.title": "Update menu category",
    "manageMenuCategories.field.menuCategoryId.label": "Category ID",
    "manageMenuCategories.field.name.label": "Name",
    "manageMenuCategories.field.description.label": "Description",
    "manageMenuCategories.field.status.label": "Status",
    "manageMenuCategories.action.submit.label": "Save changes"
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowManageMenuCategoriesBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.manageMenuCategoriesState = 'idle';
        this.manageMenuCategoriesMenuCategoryId = '';
        this.manageMenuCategoriesName = '';
        this.manageMenuCategoriesDescription = '';
        this.manageMenuCategoriesStatus = '';
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || messages['en'];
    }
    connectedCallback() {
        super.connectedCallback();
        const statusState = getState('ui.manageMenuCategories.status');
        if (statusState !== undefined) {
            this.status = statusState;
        }
        const manageMenuCategoriesStateState = getState('ui.manageMenuCategories.action.manageMenuCategories.status');
        if (manageMenuCategoriesStateState !== undefined) {
            this.manageMenuCategoriesState = manageMenuCategoriesStateState;
        }
        const manageMenuCategoriesMenuCategoryIdState = getState('ui.manageMenuCategories.input.manageMenuCategories.menuCategoryId');
        if (manageMenuCategoriesMenuCategoryIdState !== undefined) {
            this.manageMenuCategoriesMenuCategoryId = manageMenuCategoriesMenuCategoryIdState;
        }
        const manageMenuCategoriesNameState = getState('ui.manageMenuCategories.input.manageMenuCategories.name');
        if (manageMenuCategoriesNameState !== undefined) {
            this.manageMenuCategoriesName = manageMenuCategoriesNameState;
        }
        const manageMenuCategoriesDescriptionState = getState('ui.manageMenuCategories.input.manageMenuCategories.description');
        if (manageMenuCategoriesDescriptionState !== undefined) {
            this.manageMenuCategoriesDescription = manageMenuCategoriesDescriptionState;
        }
        const manageMenuCategoriesStatusState = getState('ui.manageMenuCategories.input.manageMenuCategories.status');
        if (manageMenuCategoriesStatusState !== undefined) {
            this.manageMenuCategoriesStatus = manageMenuCategoriesStatusState;
        }
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
    setManageMenuCategoriesMenuCategoryId(value) {
        this.manageMenuCategoriesMenuCategoryId = value;
        setState('ui.manageMenuCategories.input.manageMenuCategories.menuCategoryId', value);
    }
    handleManageMenuCategoriesMenuCategoryIdChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setManageMenuCategoriesMenuCategoryId(value);
    }
    setManageMenuCategoriesName(value) {
        this.manageMenuCategoriesName = value;
        setState('ui.manageMenuCategories.input.manageMenuCategories.name', value);
    }
    handleManageMenuCategoriesNameChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setManageMenuCategoriesName(value);
    }
    setManageMenuCategoriesDescription(value) {
        this.manageMenuCategoriesDescription = value;
        setState('ui.manageMenuCategories.input.manageMenuCategories.description', value);
    }
    handleManageMenuCategoriesDescriptionChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setManageMenuCategoriesDescription(value);
    }
    setManageMenuCategoriesStatus(value) {
        this.manageMenuCategoriesStatus = value;
        setState('ui.manageMenuCategories.input.manageMenuCategories.status', value);
    }
    handleManageMenuCategoriesStatusChange(event) {
        const target = event.target;
        const value = (target?.value ?? '');
        this.setManageMenuCategoriesStatus(value);
    }
    async manageMenuCategories() {
        this.manageMenuCategoriesState = 'loading';
        setState('ui.manageMenuCategories.action.manageMenuCategories.status', 'loading');
        const params = {
            menuCategoryId: this.manageMenuCategoriesMenuCategoryId,
            name: this.manageMenuCategoriesName,
            description: this.manageMenuCategoriesDescription,
            status: this.manageMenuCategoriesStatus
        };
        const options = { mode: 'blocking' };
        const response = await execBff('cafeFlow.manageMenuCategories.manageMenuCategories', params, options);
        if (response.ok) {
            this.manageMenuCategoriesState = 'success';
            setState('ui.manageMenuCategories.action.manageMenuCategories.status', 'success');
            return;
        }
        this.manageMenuCategoriesState = 'error';
        setState('ui.manageMenuCategories.action.manageMenuCategories.status', 'error');
        throw new Error(response.error?.message || 'Failed to manage menu categories');
    }
    handleManageMenuCategoriesClick(event) {
        event?.preventDefault();
        runBlockingUiAction(async () => {
            await this.manageMenuCategories();
        });
    }
}
__decorate([
    property()
], CafeFlowManageMenuCategoriesBase.prototype, "status", void 0);
__decorate([
    property()
], CafeFlowManageMenuCategoriesBase.prototype, "manageMenuCategoriesState", void 0);
__decorate([
    property()
], CafeFlowManageMenuCategoriesBase.prototype, "manageMenuCategoriesMenuCategoryId", void 0);
__decorate([
    property()
], CafeFlowManageMenuCategoriesBase.prototype, "manageMenuCategoriesName", void 0);
__decorate([
    property()
], CafeFlowManageMenuCategoriesBase.prototype, "manageMenuCategoriesDescription", void 0);
__decorate([
    property()
], CafeFlowManageMenuCategoriesBase.prototype, "manageMenuCategoriesStatus", void 0);
