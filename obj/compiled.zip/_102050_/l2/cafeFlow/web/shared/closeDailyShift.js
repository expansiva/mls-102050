/// <mls fileReference="_102050_/l2/cafeFlow/web/shared/closeDailyShift.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "closeDailyShift.section.main": "Fechar turno diário (fechamento de caixa)",
    "closeDailyShift.update.title": "Atualizar status do turno diário",
    "closeDailyShift.record.title": "Registrar movimento de fechamento do caixa",
    "closeDailyShift.summary.title": "Resumo do fechamento do turno",
    "closeDailyShift.action.updateDailyShiftStatus": "Atualizar status",
    "closeDailyShift.action.recordClosingCashMovement": "Registrar movimento",
    "field.dailyShiftId": "ID do turno",
    "field.shiftDate": "Data do turno",
    "field.status": "Status do turno",
    "field.openedAt": "Abertura do turno",
    "field.closedAt": "Fechamento do turno",
    "field.openingCashBalance": "Saldo inicial em caixa",
    "field.closingCashBalance": "Saldo final em caixa",
    "field.totalSales": "Total de vendas",
    "field.totalPayments": "Total de pagamentos",
    "field.closingNotes": "Observações de fechamento"
};
const message_en = {
    "closeDailyShift.section.main": "Close daily shift (cash closing)",
    "closeDailyShift.update.title": "Update daily shift status",
    "closeDailyShift.record.title": "Record closing cash movement",
    "closeDailyShift.summary.title": "Daily shift closing summary",
    "closeDailyShift.action.updateDailyShiftStatus": "Update status",
    "closeDailyShift.action.recordClosingCashMovement": "Record movement",
    "field.dailyShiftId": "Shift ID",
    "field.shiftDate": "Shift date",
    "field.status": "Shift status",
    "field.openedAt": "Shift opening",
    "field.closedAt": "Shift closing",
    "field.openingCashBalance": "Opening cash balance",
    "field.closingCashBalance": "Closing cash balance",
    "field.totalSales": "Total sales",
    "field.totalPayments": "Total payments",
    "field.closingNotes": "Closing notes"
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowCloseDailyShiftBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.updateDailyShiftStatusState = "idle";
        this.updateDailyShiftStatusDailyShiftId = '';
        this.updateDailyShiftStatusShiftDate = '';
        this.updateDailyShiftStatusStatus = '';
        this.updateDailyShiftStatusOpenedAt = '';
        this.updateDailyShiftStatusClosedAt = '';
        this.updateDailyShiftStatusOpeningCashBalance = '';
        this.updateDailyShiftStatusClosingCashBalance = '';
        this.updateDailyShiftStatusTotalSales = '';
        this.updateDailyShiftStatusTotalPayments = '';
        this.updateDailyShiftStatusClosingNotes = '';
        this.recordClosingCashMovementState = "idle";
        this.recordClosingCashMovementShiftDate = '';
        this.recordClosingCashMovementStatus = '';
        this.recordClosingCashMovementOpenedAt = '';
        this.recordClosingCashMovementClosedAt = '';
        this.recordClosingCashMovementOpeningCashBalance = '';
        this.recordClosingCashMovementClosingCashBalance = '';
        this.recordClosingCashMovementTotalSales = '';
        this.recordClosingCashMovementTotalPayments = '';
        this.recordClosingCashMovementClosingNotes = '';
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || messages['en'];
    }
    // ── State setters: updateDailyShiftStatus inputs ──
    setUpdateDailyShiftStatusDailyShiftId(value) {
        this.updateDailyShiftStatusDailyShiftId = value;
        setState('ui.closeDailyShift.input.updateDailyShiftStatus.dailyShiftId', value);
        this.requestUpdate();
    }
    handleUpdateDailyShiftStatusDailyShiftIdChange(e) {
        const target = e.target;
        this.setUpdateDailyShiftStatusDailyShiftId(target.value);
    }
    setUpdateDailyShiftStatusShiftDate(value) {
        this.updateDailyShiftStatusShiftDate = value;
        setState('ui.closeDailyShift.input.updateDailyShiftStatus.shiftDate', value);
        this.requestUpdate();
    }
    handleUpdateDailyShiftStatusShiftDateChange(e) {
        const target = e.target;
        this.setUpdateDailyShiftStatusShiftDate(target.value);
    }
    setUpdateDailyShiftStatusStatus(value) {
        this.updateDailyShiftStatusStatus = value;
        setState('ui.closeDailyShift.input.updateDailyShiftStatus.status', value);
        this.requestUpdate();
    }
    handleUpdateDailyShiftStatusStatusChange(e) {
        const target = e.target;
        this.setUpdateDailyShiftStatusStatus(target.value);
    }
    setUpdateDailyShiftStatusOpenedAt(value) {
        this.updateDailyShiftStatusOpenedAt = value;
        setState('ui.closeDailyShift.input.updateDailyShiftStatus.openedAt', value);
        this.requestUpdate();
    }
    handleUpdateDailyShiftStatusOpenedAtChange(e) {
        const target = e.target;
        this.setUpdateDailyShiftStatusOpenedAt(target.value);
    }
    setUpdateDailyShiftStatusClosedAt(value) {
        this.updateDailyShiftStatusClosedAt = value;
        setState('ui.closeDailyShift.input.updateDailyShiftStatus.closedAt', value);
        this.requestUpdate();
    }
    handleUpdateDailyShiftStatusClosedAtChange(e) {
        const target = e.target;
        this.setUpdateDailyShiftStatusClosedAt(target.value);
    }
    setUpdateDailyShiftStatusOpeningCashBalance(value) {
        this.updateDailyShiftStatusOpeningCashBalance = value;
        setState('ui.closeDailyShift.input.updateDailyShiftStatus.openingCashBalance', value);
        this.requestUpdate();
    }
    handleUpdateDailyShiftStatusOpeningCashBalanceChange(e) {
        const target = e.target;
        this.setUpdateDailyShiftStatusOpeningCashBalance(target.value);
    }
    setUpdateDailyShiftStatusClosingCashBalance(value) {
        this.updateDailyShiftStatusClosingCashBalance = value;
        setState('ui.closeDailyShift.input.updateDailyShiftStatus.closingCashBalance', value);
        this.requestUpdate();
    }
    handleUpdateDailyShiftStatusClosingCashBalanceChange(e) {
        const target = e.target;
        this.setUpdateDailyShiftStatusClosingCashBalance(target.value);
    }
    setUpdateDailyShiftStatusTotalSales(value) {
        this.updateDailyShiftStatusTotalSales = value;
        setState('ui.closeDailyShift.input.updateDailyShiftStatus.totalSales', value);
        this.requestUpdate();
    }
    handleUpdateDailyShiftStatusTotalSalesChange(e) {
        const target = e.target;
        this.setUpdateDailyShiftStatusTotalSales(target.value);
    }
    setUpdateDailyShiftStatusTotalPayments(value) {
        this.updateDailyShiftStatusTotalPayments = value;
        setState('ui.closeDailyShift.input.updateDailyShiftStatus.totalPayments', value);
        this.requestUpdate();
    }
    handleUpdateDailyShiftStatusTotalPaymentsChange(e) {
        const target = e.target;
        this.setUpdateDailyShiftStatusTotalPayments(target.value);
    }
    setUpdateDailyShiftStatusClosingNotes(value) {
        this.updateDailyShiftStatusClosingNotes = value;
        setState('ui.closeDailyShift.input.updateDailyShiftStatus.closingNotes', value);
        this.requestUpdate();
    }
    handleUpdateDailyShiftStatusClosingNotesChange(e) {
        const target = e.target;
        this.setUpdateDailyShiftStatusClosingNotes(target.value);
    }
    // ── State setters: recordClosingCashMovement inputs ──
    setRecordClosingCashMovementShiftDate(value) {
        this.recordClosingCashMovementShiftDate = value;
        setState('ui.closeDailyShift.input.recordClosingCashMovement.shiftDate', value);
        this.requestUpdate();
    }
    handleRecordClosingCashMovementShiftDateChange(e) {
        const target = e.target;
        this.setRecordClosingCashMovementShiftDate(target.value);
    }
    setRecordClosingCashMovementStatus(value) {
        this.recordClosingCashMovementStatus = value;
        setState('ui.closeDailyShift.input.recordClosingCashMovement.status', value);
        this.requestUpdate();
    }
    handleRecordClosingCashMovementStatusChange(e) {
        const target = e.target;
        this.setRecordClosingCashMovementStatus(target.value);
    }
    setRecordClosingCashMovementOpenedAt(value) {
        this.recordClosingCashMovementOpenedAt = value;
        setState('ui.closeDailyShift.input.recordClosingCashMovement.openedAt', value);
        this.requestUpdate();
    }
    handleRecordClosingCashMovementOpenedAtChange(e) {
        const target = e.target;
        this.setRecordClosingCashMovementOpenedAt(target.value);
    }
    setRecordClosingCashMovementClosedAt(value) {
        this.recordClosingCashMovementClosedAt = value;
        setState('ui.closeDailyShift.input.recordClosingCashMovement.closedAt', value);
        this.requestUpdate();
    }
    handleRecordClosingCashMovementClosedAtChange(e) {
        const target = e.target;
        this.setRecordClosingCashMovementClosedAt(target.value);
    }
    setRecordClosingCashMovementOpeningCashBalance(value) {
        this.recordClosingCashMovementOpeningCashBalance = value;
        setState('ui.closeDailyShift.input.recordClosingCashMovement.openingCashBalance', value);
        this.requestUpdate();
    }
    handleRecordClosingCashMovementOpeningCashBalanceChange(e) {
        const target = e.target;
        this.setRecordClosingCashMovementOpeningCashBalance(target.value);
    }
    setRecordClosingCashMovementClosingCashBalance(value) {
        this.recordClosingCashMovementClosingCashBalance = value;
        setState('ui.closeDailyShift.input.recordClosingCashMovement.closingCashBalance', value);
        this.requestUpdate();
    }
    handleRecordClosingCashMovementClosingCashBalanceChange(e) {
        const target = e.target;
        this.setRecordClosingCashMovementClosingCashBalance(target.value);
    }
    setRecordClosingCashMovementTotalSales(value) {
        this.recordClosingCashMovementTotalSales = value;
        setState('ui.closeDailyShift.input.recordClosingCashMovement.totalSales', value);
        this.requestUpdate();
    }
    handleRecordClosingCashMovementTotalSalesChange(e) {
        const target = e.target;
        this.setRecordClosingCashMovementTotalSales(target.value);
    }
    setRecordClosingCashMovementTotalPayments(value) {
        this.recordClosingCashMovementTotalPayments = value;
        setState('ui.closeDailyShift.input.recordClosingCashMovement.totalPayments', value);
        this.requestUpdate();
    }
    handleRecordClosingCashMovementTotalPaymentsChange(e) {
        const target = e.target;
        this.setRecordClosingCashMovementTotalPayments(target.value);
    }
    setRecordClosingCashMovementClosingNotes(value) {
        this.recordClosingCashMovementClosingNotes = value;
        setState('ui.closeDailyShift.input.recordClosingCashMovement.closingNotes', value);
        this.requestUpdate();
    }
    handleRecordClosingCashMovementClosingNotesChange(e) {
        const target = e.target;
        this.setRecordClosingCashMovementClosingNotes(target.value);
    }
    // ── Command: updateDailyShiftStatus ──
    async updateDailyShiftStatus() {
        this.updateDailyShiftStatusState = 'loading';
        setState('ui.closeDailyShift.action.updateDailyShiftStatus.status', 'loading');
        this.requestUpdate();
        const params = {
            dailyShiftId: this.updateDailyShiftStatusDailyShiftId || undefined,
            shiftDate: this.updateDailyShiftStatusShiftDate,
            status: this.updateDailyShiftStatusStatus,
            openedAt: this.updateDailyShiftStatusOpenedAt,
            closedAt: this.updateDailyShiftStatusClosedAt || undefined,
            openingCashBalance: this.updateDailyShiftStatusOpeningCashBalance
                ? Number(this.updateDailyShiftStatusOpeningCashBalance)
                : undefined,
            closingCashBalance: this.updateDailyShiftStatusClosingCashBalance
                ? Number(this.updateDailyShiftStatusClosingCashBalance)
                : undefined,
            totalSales: this.updateDailyShiftStatusTotalSales
                ? Number(this.updateDailyShiftStatusTotalSales)
                : undefined,
            totalPayments: this.updateDailyShiftStatusTotalPayments
                ? Number(this.updateDailyShiftStatusTotalPayments)
                : undefined,
            closingNotes: this.updateDailyShiftStatusClosingNotes || undefined,
        };
        const options = { mode: 'blocking' };
        const response = await execBff('cafeFlow.closeDailyShift.updateDailyShiftStatus', params, options);
        if (response.ok) {
            this.updateDailyShiftStatusState = 'success';
            setState('ui.closeDailyShift.action.updateDailyShiftStatus.status', 'success');
        }
        else {
            this.updateDailyShiftStatusState = 'error';
            setState('ui.closeDailyShift.action.updateDailyShiftStatus.status', 'error');
        }
        this.requestUpdate();
    }
    handleUpdateDailyShiftStatusClick(e) {
        e.preventDefault();
        runBlockingUiAction(async () => {
            await this.updateDailyShiftStatus();
        });
    }
    // ── Command: recordClosingCashMovement ──
    async recordClosingCashMovement() {
        this.recordClosingCashMovementState = 'loading';
        setState('ui.closeDailyShift.action.recordClosingCashMovement.status', 'loading');
        this.requestUpdate();
        const params = {
            shiftDate: this.recordClosingCashMovementShiftDate,
            status: this.recordClosingCashMovementStatus,
            openedAt: this.recordClosingCashMovementOpenedAt,
            closedAt: this.recordClosingCashMovementClosedAt || undefined,
            openingCashBalance: this.recordClosingCashMovementOpeningCashBalance
                ? Number(this.recordClosingCashMovementOpeningCashBalance)
                : undefined,
            closingCashBalance: this.recordClosingCashMovementClosingCashBalance
                ? Number(this.recordClosingCashMovementClosingCashBalance)
                : undefined,
            totalSales: this.recordClosingCashMovementTotalSales
                ? Number(this.recordClosingCashMovementTotalSales)
                : undefined,
            totalPayments: this.recordClosingCashMovementTotalPayments
                ? Number(this.recordClosingCashMovementTotalPayments)
                : undefined,
            closingNotes: this.recordClosingCashMovementClosingNotes || undefined,
        };
        const options = { mode: 'blocking' };
        const response = await execBff('cafeFlow.closeDailyShift.recordClosingCashMovement', params, options);
        if (response.ok) {
            this.recordClosingCashMovementState = 'success';
            setState('ui.closeDailyShift.action.recordClosingCashMovement.status', 'success');
        }
        else {
            this.recordClosingCashMovementState = 'error';
            setState('ui.closeDailyShift.action.recordClosingCashMovement.status', 'error');
        }
        this.requestUpdate();
    }
    handleRecordClosingCashMovementClick(e) {
        e.preventDefault();
        runBlockingUiAction(async () => {
            await this.recordClosingCashMovement();
        });
    }
    // ── Lifecycle ──
    connectedCallback() {
        super.connectedCallback();
        this.status = getState('ui.closeDailyShift.status') || '';
        this.updateDailyShiftStatusState =
            getState('ui.closeDailyShift.action.updateDailyShiftStatus.status') || 'idle';
        this.updateDailyShiftStatusDailyShiftId =
            getState('ui.closeDailyShift.input.updateDailyShiftStatus.dailyShiftId') || '';
        this.updateDailyShiftStatusShiftDate =
            getState('ui.closeDailyShift.input.updateDailyShiftStatus.shiftDate') || '';
        this.updateDailyShiftStatusStatus =
            getState('ui.closeDailyShift.input.updateDailyShiftStatus.status') || '';
        this.updateDailyShiftStatusOpenedAt =
            getState('ui.closeDailyShift.input.updateDailyShiftStatus.openedAt') || '';
        this.updateDailyShiftStatusClosedAt =
            getState('ui.closeDailyShift.input.updateDailyShiftStatus.closedAt') || '';
        this.updateDailyShiftStatusOpeningCashBalance =
            getState('ui.closeDailyShift.input.updateDailyShiftStatus.openingCashBalance') || '';
        this.updateDailyShiftStatusClosingCashBalance =
            getState('ui.closeDailyShift.input.updateDailyShiftStatus.closingCashBalance') || '';
        this.updateDailyShiftStatusTotalSales =
            getState('ui.closeDailyShift.input.updateDailyShiftStatus.totalSales') || '';
        this.updateDailyShiftStatusTotalPayments =
            getState('ui.closeDailyShift.input.updateDailyShiftStatus.totalPayments') || '';
        this.updateDailyShiftStatusClosingNotes =
            getState('ui.closeDailyShift.input.updateDailyShiftStatus.closingNotes') || '';
        this.recordClosingCashMovementState =
            getState('ui.closeDailyShift.action.recordClosingCashMovement.status') || 'idle';
        this.recordClosingCashMovementShiftDate =
            getState('ui.closeDailyShift.input.recordClosingCashMovement.shiftDate') || '';
        this.recordClosingCashMovementStatus =
            getState('ui.closeDailyShift.input.recordClosingCashMovement.status') || '';
        this.recordClosingCashMovementOpenedAt =
            getState('ui.closeDailyShift.input.recordClosingCashMovement.openedAt') || '';
        this.recordClosingCashMovementClosedAt =
            getState('ui.closeDailyShift.input.recordClosingCashMovement.closedAt') || '';
        this.recordClosingCashMovementOpeningCashBalance =
            getState('ui.closeDailyShift.input.recordClosingCashMovement.openingCashBalance') || '';
        this.recordClosingCashMovementClosingCashBalance =
            getState('ui.closeDailyShift.input.recordClosingCashMovement.closingCashBalance') || '';
        this.recordClosingCashMovementTotalSales =
            getState('ui.closeDailyShift.input.recordClosingCashMovement.totalSales') || '';
        this.recordClosingCashMovementTotalPayments =
            getState('ui.closeDailyShift.input.recordClosingCashMovement.totalPayments') || '';
        this.recordClosingCashMovementClosingNotes =
            getState('ui.closeDailyShift.input.recordClosingCashMovement.closingNotes') || '';
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
}
__decorate([
    property({ type: String })
], CafeFlowCloseDailyShiftBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowCloseDailyShiftBase.prototype, "updateDailyShiftStatusState", void 0);
__decorate([
    property({ type: String })
], CafeFlowCloseDailyShiftBase.prototype, "updateDailyShiftStatusDailyShiftId", void 0);
__decorate([
    property({ type: String })
], CafeFlowCloseDailyShiftBase.prototype, "updateDailyShiftStatusShiftDate", void 0);
__decorate([
    property({ type: String })
], CafeFlowCloseDailyShiftBase.prototype, "updateDailyShiftStatusStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowCloseDailyShiftBase.prototype, "updateDailyShiftStatusOpenedAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowCloseDailyShiftBase.prototype, "updateDailyShiftStatusClosedAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowCloseDailyShiftBase.prototype, "updateDailyShiftStatusOpeningCashBalance", void 0);
__decorate([
    property({ type: String })
], CafeFlowCloseDailyShiftBase.prototype, "updateDailyShiftStatusClosingCashBalance", void 0);
__decorate([
    property({ type: String })
], CafeFlowCloseDailyShiftBase.prototype, "updateDailyShiftStatusTotalSales", void 0);
__decorate([
    property({ type: String })
], CafeFlowCloseDailyShiftBase.prototype, "updateDailyShiftStatusTotalPayments", void 0);
__decorate([
    property({ type: String })
], CafeFlowCloseDailyShiftBase.prototype, "updateDailyShiftStatusClosingNotes", void 0);
__decorate([
    property({ type: String })
], CafeFlowCloseDailyShiftBase.prototype, "recordClosingCashMovementState", void 0);
__decorate([
    property({ type: String })
], CafeFlowCloseDailyShiftBase.prototype, "recordClosingCashMovementShiftDate", void 0);
__decorate([
    property({ type: String })
], CafeFlowCloseDailyShiftBase.prototype, "recordClosingCashMovementStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowCloseDailyShiftBase.prototype, "recordClosingCashMovementOpenedAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowCloseDailyShiftBase.prototype, "recordClosingCashMovementClosedAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowCloseDailyShiftBase.prototype, "recordClosingCashMovementOpeningCashBalance", void 0);
__decorate([
    property({ type: String })
], CafeFlowCloseDailyShiftBase.prototype, "recordClosingCashMovementClosingCashBalance", void 0);
__decorate([
    property({ type: String })
], CafeFlowCloseDailyShiftBase.prototype, "recordClosingCashMovementTotalSales", void 0);
__decorate([
    property({ type: String })
], CafeFlowCloseDailyShiftBase.prototype, "recordClosingCashMovementTotalPayments", void 0);
__decorate([
    property({ type: String })
], CafeFlowCloseDailyShiftBase.prototype, "recordClosingCashMovementClosingNotes", void 0);
