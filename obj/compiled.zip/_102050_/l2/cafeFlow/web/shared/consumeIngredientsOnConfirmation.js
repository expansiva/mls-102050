/// <mls fileReference="_102050_/l2/cafeFlow/web/shared/consumeIngredientsOnConfirmation.ts" enhancement="_blank"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
const message_pt = {
    'consumeIngredientsOnConfirmation.section.main.title': 'Baixar estoque por consumo de ingredientes',
    'consumeIngredientsOnConfirmation.organism.createStockConsumption.title': 'Registrar consumo de estoque',
    'consumeIngredientsOnConfirmation.intent.createStockConsumption.form.title': 'Registrar consumo de estoque',
    'consumeIngredientsOnConfirmation.field.quantity.label': 'Quantidade consumida',
    'consumeIngredientsOnConfirmation.field.status.label': 'Situação do consumo',
    'consumeIngredientsOnConfirmation.field.consumedAt.label': 'Data e hora do consumo',
    'consumeIngredientsOnConfirmation.action.createStockConsumption.label': 'Registrar consumo',
};
const message_en = {
    'consumeIngredientsOnConfirmation.section.main.title': 'Deduct stock by ingredient consumption',
    'consumeIngredientsOnConfirmation.organism.createStockConsumption.title': 'Register stock consumption',
    'consumeIngredientsOnConfirmation.intent.createStockConsumption.form.title': 'Register stock consumption',
    'consumeIngredientsOnConfirmation.field.quantity.label': 'Consumed quantity',
    'consumeIngredientsOnConfirmation.field.status.label': 'Consumption status',
    'consumeIngredientsOnConfirmation.field.consumedAt.label': 'Consumption date and time',
    'consumeIngredientsOnConfirmation.action.createStockConsumption.label': 'Register consumption',
};
export class CafeFlowConsumeIngredientsOnConfirmationBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.createStockConsumptionState = 'idle';
        this.createStockConsumptionQuantity = '';
        this.createStockConsumptionStatus = '';
        this.createStockConsumptionConsumedAt = '';
    }
    get msg() {
        const lang = this.__lang ?? 'pt';
        return lang === 'en' ? message_en : message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        this.status = getState('ui.consumeIngredientsOnConfirmation.status') ?? '';
        this.createStockConsumptionState = getState('ui.consumeIngredientsOnConfirmation.action.createStockConsumption.status') ?? 'idle';
        this.createStockConsumptionQuantity = getState('ui.consumeIngredientsOnConfirmation.input.createStockConsumption.quantity') ?? '';
        this.createStockConsumptionStatus = getState('ui.consumeIngredientsOnConfirmation.input.createStockConsumption.status') ?? '';
        this.createStockConsumptionConsumedAt = getState('ui.consumeIngredientsOnConfirmation.input.createStockConsumption.consumedAt') ?? '';
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
    // --- State setters ---
    setCreateStockConsumptionQuantity(value) {
        this.createStockConsumptionQuantity = value;
        setState('ui.consumeIngredientsOnConfirmation.input.createStockConsumption.quantity', value);
        this.requestUpdate();
    }
    handleCreateStockConsumptionQuantityChange(e) {
        const target = e.target;
        const raw = target.value;
        const parsed = raw === '' ? '' : Number(raw);
        this.setCreateStockConsumptionQuantity(parsed);
    }
    setCreateStockConsumptionStatus(value) {
        this.createStockConsumptionStatus = value;
        setState('ui.consumeIngredientsOnConfirmation.input.createStockConsumption.status', value);
        this.requestUpdate();
    }
    handleCreateStockConsumptionStatusChange(e) {
        const target = e.target;
        this.setCreateStockConsumptionStatus(target.value);
    }
    setCreateStockConsumptionConsumedAt(value) {
        this.createStockConsumptionConsumedAt = value;
        setState('ui.consumeIngredientsOnConfirmation.input.createStockConsumption.consumedAt', value);
        this.requestUpdate();
    }
    handleCreateStockConsumptionConsumedAtChange(e) {
        const target = e.target;
        this.setCreateStockConsumptionConsumedAt(target.value);
    }
    // --- Command: createStockConsumption ---
    async createStockConsumption() {
        this.createStockConsumptionState = 'loading';
        setState('ui.consumeIngredientsOnConfirmation.action.createStockConsumption.status', 'loading');
        this.requestUpdate();
        const params = {
            quantity: Number(this.createStockConsumptionQuantity),
            status: this.createStockConsumptionStatus,
            consumedAt: this.createStockConsumptionConsumedAt,
        };
        const options = { mode: 'blocking' };
        try {
            const response = await execBff('cafeFlow.consumeIngredientsOnConfirmation.createStockConsumption', params, options);
            if (response.ok) {
                this.createStockConsumptionState = 'success';
                setState('ui.consumeIngredientsOnConfirmation.action.createStockConsumption.status', 'success');
            }
            else {
                this.createStockConsumptionState = 'error';
                setState('ui.consumeIngredientsOnConfirmation.action.createStockConsumption.status', 'error');
            }
        }
        catch {
            this.createStockConsumptionState = 'error';
            setState('ui.consumeIngredientsOnConfirmation.action.createStockConsumption.status', 'error');
        }
        this.requestUpdate();
    }
    handleCreateStockConsumptionClick() {
        void runBlockingUiAction(async () => {
            await this.createStockConsumption();
        });
    }
}
__decorate([
    property({ type: String })
], CafeFlowConsumeIngredientsOnConfirmationBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowConsumeIngredientsOnConfirmationBase.prototype, "createStockConsumptionState", void 0);
__decorate([
    property({ type: String })
], CafeFlowConsumeIngredientsOnConfirmationBase.prototype, "createStockConsumptionQuantity", void 0);
__decorate([
    property({ type: String })
], CafeFlowConsumeIngredientsOnConfirmationBase.prototype, "createStockConsumptionStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowConsumeIngredientsOnConfirmationBase.prototype, "createStockConsumptionConsumedAt", void 0);
