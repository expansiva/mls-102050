/// <mls fileReference="_102050_/l2/cafeFlow/web/contracts/generateShiftCloseReport.test.ts" enhancement="_blank"/>
export {};
