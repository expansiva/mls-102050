/// <mls fileReference="_102050_/l2/cafeFlow/web/contracts/closeDailyShift.test.ts" enhancement="_blank"/>
export {};
