/// <mls fileReference="_102050_/l2/cafeFlow/web/contracts/recordPayment.ts" enhancement="_blank"/>
export {};
