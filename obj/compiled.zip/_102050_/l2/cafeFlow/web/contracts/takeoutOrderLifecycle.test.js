/// <mls fileReference="_102050_/l2/cafeFlow/web/contracts/takeoutOrderLifecycle.test.ts" enhancement="_blank"/>
export {};
