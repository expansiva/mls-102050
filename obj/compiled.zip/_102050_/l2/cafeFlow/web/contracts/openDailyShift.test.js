/// <mls fileReference="_102050_/l2/cafeFlow/web/contracts/openDailyShift.test.ts" enhancement="_blank"/>
export {};
