/// <mls fileReference="_102050_/l2/cafeFlow/web/contracts/manageInventoryItems.test.ts" enhancement="_blank"/>
export {};
