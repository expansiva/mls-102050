/// <mls fileReference="_102050_/l2/cafeFlow/web/contracts/consumeIngredientsOnConfirmation.test.ts" enhancement="_blank"/>
export {};
