/// <mls fileReference="_102050_/l2/cafeFlow/web/contracts/dineInOrderLifecycle.ts" enhancement="_blank"/>
export {};
