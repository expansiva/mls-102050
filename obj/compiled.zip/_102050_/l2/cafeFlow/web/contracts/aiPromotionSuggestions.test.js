/// <mls fileReference="_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.test.ts" enhancement="_blank"/>
export {};
