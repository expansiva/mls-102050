/// <mls fileReference="_102050_/l2/cafeFlow/web/contracts/aiPromotionSuggestions.ts" enhancement="_blank"/>
export {};
