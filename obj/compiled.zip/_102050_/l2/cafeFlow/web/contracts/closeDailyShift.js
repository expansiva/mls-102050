/// <mls fileReference="_102050_/l2/cafeFlow/web/contracts/closeDailyShift.ts" enhancement="_blank"/>
export {};
