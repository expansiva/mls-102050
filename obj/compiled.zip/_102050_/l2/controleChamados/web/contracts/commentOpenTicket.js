/// <mls fileReference="_102050_/l2/controleChamados/web/contracts/commentOpenTicket.ts" enhancement="_blank"/>
export const qryLocateTicketRoute = 'controleChamados.commentOpenTicket.qryLocateTicket';
export const cmdRecordCommentRoute = 'controleChamados.commentOpenTicket.cmdRecordComment';
